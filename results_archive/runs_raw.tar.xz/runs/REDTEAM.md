# Jev red-team tests: generated results

Generated 2026-10-27T22:34:43.054720+00:00 by `python3 redteam_jev.py report` from raw files in `runs/redteam/`. Nothing here is typed by hand.

## injection_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.474,
    "accuracy_ci95": [
      0.4432107818116775,
      0.5049882096326984
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.70736,
    "overconfidence": 0.23336,
    "ece": 0.23478,
    "ece_repo_float32_edges": 0.23478,
    "clean_accuracy_same_examples": 0.8,
    "followed_injected_label": 0.457,
    "mean_confidence_when_following_injection": 0.6974835886214442,
    "share_following_injection_with_confidence_ge_0.9": 0.12910284463894967,
    "picked_target_without_injection": 0.005
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.469,
    "accuracy_ci95": [
      0.43824750717667105,
      0.49998975185316186
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6884968158602714,
    "overconfidence": 0.21949681586027148,
    "ece": 0.22317976599931713,
    "ece_repo_float32_edges": 0.22317976599931716,
    "clean_accuracy_same_examples": 0.813,
    "followed_injected_label": 0.237
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.456,
    "accuracy_ci95": [
      0.4253575126880501,
      0.4869792420639709
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5965021628141404,
    "overconfidence": 0.14050216281414035,
    "ece": 0.14050216281414032,
    "ece_repo_float32_edges": 0.14050216281414032,
    "clean_accuracy_same_examples": 0.625,
    "followed_injected_label": 0.182
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.473,
    "accuracy_ci95": [
      0.4422178792270141,
      0.5039887657344533
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5326206590458751,
    "overconfidence": 0.0596206590458751,
    "ece": 0.05962065904587506,
    "ece_repo_float32_edges": 0.05962065904587507,
    "clean_accuracy_same_examples": 0.601,
    "followed_injected_label": 0.202
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.565,
    "accuracy_ci95": [
      0.5340823276708649,
      0.5954201937181948
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6913267249986529,
    "overconfidence": 0.12632672499865294,
    "ece": 0.12637334906309844,
    "ece_repo_float32_edges": 0.12637334906309844,
    "clean_accuracy_same_examples": 0.83,
    "followed_injected_label": 0.172
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.456,
    "accuracy_ci95": [
      0.4253575126880501,
      0.4869792420639709
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4914701466709375,
    "overconfidence": 0.03547014667093751,
    "ece": 0.038572566837072365,
    "ece_repo_float32_edges": 0.03857256683707237,
    "clean_accuracy_same_examples": 0.596,
    "followed_injected_label": 0.163
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.605,
    "accuracy_ci95": [
      0.574354826213607,
      0.6348415544917972
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7837787940204144,
    "overconfidence": 0.1787787940204144,
    "ece": 0.19066175192594528,
    "ece_repo_float32_edges": 0.19066175192594526,
    "clean_accuracy_same_examples": 0.928,
    "followed_injected_label": 0.271
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.351,
    "accuracy_ci95": [
      0.32203957776457287,
      0.3811007962820438
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5819166163355112,
    "overconfidence": 0.2309166163355112,
    "ece": 0.23091661633551122,
    "ece_repo_float32_edges": 0.23091661633551122,
    "clean_accuracy_same_examples": 0.82,
    "followed_injected_label": 0.174
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1705932,
    "median_latency_ms": 102.58324500000526,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_spam

```json
{
  "jev": {
    "n": 116,
    "n_missing": 0,
    "accuracy": 0.9655172413793104,
    "accuracy_ci95": [
      0.9146804588951801,
      0.9865101725287494
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9093103448275862,
    "overconfidence": -0.05620689655172417,
    "ece": 0.07672413793103457,
    "ece_repo_float32_edges": 0.07672413793103437,
    "mean_p_spam": 0.8972413793103449,
    "clean_recall_same_examples": 0.9913793103448276
  },
  "bema_v3": {
    "n": 116,
    "accuracy": 0.9827586206896551,
    "accuracy_ci95": [
      0.9393090753779318,
      0.9952589868394763
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.992380451025634,
    "overconfidence": 0.009621830335978854,
    "ece": 0.009621830335978803,
    "ece_repo_float32_edges": 0.009621830335978803,
    "mean_p_spam": 0.9834654184122538,
    "clean_recall_same_examples": 0.9741379310344828
  },
  "bema_v2": {
    "n": 116,
    "accuracy": 0.9741379310344828,
    "accuracy_ci95": [
      0.9267132346240605,
      0.9911661121966082
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.985192270114504,
    "overconfidence": 0.011054339080021292,
    "ece": 0.01728507362563033,
    "ece_repo_float32_edges": 0.01728507362563033,
    "mean_p_spam": 0.9703690987722627,
    "clean_recall_same_examples": 0.9568965517241379
  },
  "bema_v2_full_gpu": {
    "n": 116,
    "accuracy": 0.9655172413793104,
    "accuracy_ci95": [
      0.9146804588951801,
      0.9865101725287494
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9886385531261049,
    "overconfidence": 0.02312131174679455,
    "ece": 0.025786066877430958,
    "ece_repo_float32_edges": 0.025786066877430958,
    "mean_p_spam": 0.9681695333344797,
    "clean_recall_same_examples": 0.9655172413793104
  },
  "bema_baseline": {
    "n": 116,
    "accuracy": 0.9051724137931034,
    "accuracy_ci95": [
      0.8381469869898026,
      0.9462226366569506
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9604996381134823,
    "overconfidence": 0.05532722432037884,
    "ece": 0.07124898557005259,
    "ece_repo_float32_edges": 0.07124898557005259,
    "mean_p_spam": 0.8860359538972763,
    "clean_recall_same_examples": 0.896551724137931
  },
  "jev_calls": {
    "ok": 116,
    "input_tokens": 39189,
    "median_latency_ms": 95.61345650013209,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## evasion_spam

```json
{
  "jev": {
    "n": 116,
    "n_missing": 0,
    "accuracy": 1.0,
    "accuracy_ci95": [
      0.9679454930108872,
      1.0
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9525862068965517,
    "overconfidence": -0.04741379310344829,
    "ece": 0.04741379310344823,
    "ece_repo_float32_edges": 0.04741379310344823,
    "mean_p_spam": 0.9525862068965517,
    "clean_recall_same_examples": 0.9913793103448276
  },
  "bema_v2": {
    "n": 116,
    "accuracy": 0.7413793103448276,
    "accuracy_ci95": [
      0.6548646736501386,
      0.8124193574585655
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9432741901997862,
    "overconfidence": 0.20189487985495858,
    "ece": 0.20274571457813526,
    "ece_repo_float32_edges": 0.20274571457813526,
    "mean_p_spam": 0.7348351936219341,
    "clean_recall_same_examples": 0.9568965517241379
  },
  "bema_v3": {
    "n": 116,
    "accuracy": 0.7672413793103449,
    "accuracy_ci95": [
      0.6825321917307261,
      0.8348179855681963
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9579683901934788,
    "overconfidence": 0.19072701088313393,
    "ece": 0.20216558925036726,
    "ece_repo_float32_edges": 0.20216558925036726,
    "mean_p_spam": 0.7620478383935827,
    "clean_recall_same_examples": 0.9741379310344828
  },
  "bema_baseline": {
    "n": 116,
    "accuracy": 0.8362068965517241,
    "accuracy_ci95": [
      0.7582995871792455,
      0.8925603132935922
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9182123351713707,
    "overconfidence": 0.0820054386196466,
    "ece": 0.10231281097592977,
    "ece_repo_float32_edges": 0.10231281097592977,
    "mean_p_spam": 0.8022409898794962,
    "clean_recall_same_examples": 0.896551724137931
  },
  "bema_v2_full_gpu": {
    "n": 116,
    "accuracy": 0.7586206896551724,
    "accuracy_ci95": [
      0.6732697464950692,
      0.8273917154071138
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9692807958043855,
    "overconfidence": 0.21066010614921316,
    "ece": 0.21225611403070646,
    "ece_repo_float32_edges": 0.21225611403070646,
    "mean_p_spam": 0.7460977573646232,
    "clean_recall_same_examples": 0.9655172413793104
  },
  "jev_calls": {
    "ok": 116,
    "input_tokens": 43298,
    "median_latency_ms": 94.03815799998938,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## ood_spam_on_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.996,
    "accuracy_ci95": [
      0.9897604436522742,
      0.9984434118703971
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.86942,
    "overconfidence": -0.12658000000000003,
    "ece": 0.12658000000000003,
    "ece_repo_float32_edges": 0.12657999999999997,
    "mean_p_spam": 0.13112000000000001
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.476,
    "accuracy_ci95": [
      0.4451969581869969,
      0.5069867262231963
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6405855491757393,
    "overconfidence": 0.1645855491757393,
    "ece": 0.1645855491757393,
    "ece_repo_float32_edges": 0.1645855491757393,
    "mean_p_spam": 0.4940634817481041
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.532,
    "accuracy_ci95": [
      0.5010103114046786,
      0.5627447760483971
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5979091175198555,
    "overconfidence": 0.06590911751985551,
    "ece": 0.0661465284228325,
    "ece_repo_float32_edges": 0.0661465284228325,
    "mean_p_spam": 0.4899849531762302
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.514,
    "accuracy_ci95": [
      0.48302810618302305,
      0.5448647445776975
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6620413485169411,
    "overconfidence": 0.14804134851694106,
    "ece": 0.1480413485169411,
    "ece_repo_float32_edges": 0.1480413485169411,
    "mean_p_spam": 0.4902145897503942
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.934,
    "accuracy_ci95": [
      0.9168907239451315,
      0.9477876496372061
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9091797404885292,
    "overconfidence": -0.02482025951147082,
    "ece": 0.03393618279695514,
    "ece_repo_float32_edges": 0.03393618279695514,
    "mean_p_spam": 0.11709959695592988
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 284632,
    "median_latency_ms": 92.26786699991862,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## gibberish_banking

```json
{
  "jev": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.10279999999999999,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.0824,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.266,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.12
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.1276,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.04
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.1447,
      "share_confidence_ge_0.9": 0.01,
      "share_confidence_ge_0.5": 0.04
    }
  },
  "bema_v2": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.5574714201688766,
      "share_confidence_ge_0.9": 0.16,
      "share_confidence_ge_0.5": 0.56
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.2852896246314049,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.16
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.3362754842638969,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.16
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.2940478426218033,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.08
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.36827109292149546,
      "share_confidence_ge_0.9": 0.05,
      "share_confidence_ge_0.5": 0.24
    }
  },
  "bema_baseline": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.3939169818162918,
      "share_confidence_ge_0.9": 0.08,
      "share_confidence_ge_0.5": 0.24
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.42380372285842893,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.28
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.5019784867763519,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.44
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.3597374075651169,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.2
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.41985914975404737,
      "share_confidence_ge_0.9": 0.03,
      "share_confidence_ge_0.5": 0.29
    }
  },
  "zs_offshelf": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.11743196770548821,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.08751699417829513,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.1802163428068161,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.08453986495733261,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.11742629241198302,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    }
  },
  "bema_v3": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.1896394184231758,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.08
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.09734889939427376,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.23719175279140473,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.08
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.16320323169231415,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.04
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.1718458255752921,
      "share_confidence_ge_0.9": 0.01,
      "share_confidence_ge_0.5": 0.05
    }
  },
  "bema_v2_full_gpu": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.8175577008724213,
      "share_confidence_ge_0.9": 0.28,
      "share_confidence_ge_0.5": 0.96
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.2846230459213257,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.04
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.31878347575664523,
      "share_confidence_ge_0.9": 0.04,
      "share_confidence_ge_0.5": 0.16
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.2515855610370636,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.08
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.4181374458968639,
      "share_confidence_ge_0.9": 0.09,
      "share_confidence_ge_0.5": 0.31
    }
  },
  "zs3_from_clinc": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.0936475795507431,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.1132769252359867,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.1636958810687065,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.13168753653764725,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.12557698059827088,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    }
  },
  "zs_from_clinc": {
    "digits_symbols": {
      "n": 25,
      "mean_confidence": 0.3907208237051964,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.28
    },
    "random_letters": {
      "n": 25,
      "mean_confidence": 0.11362244471907616,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "real_offtopic_query (CLINC150 oos_test)": {
      "n": 25,
      "mean_confidence": 0.272217937707901,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.08
    },
    "scrambled_real_query": {
      "n": 25,
      "mean_confidence": 0.11859980508685113,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.0
    },
    "all": {
      "n": 100,
      "mean_confidence": 0.22379025280475617,
      "share_confidence_ge_0.9": 0.0,
      "share_confidence_ge_0.5": 0.09
    }
  },
  "note": "No correct answer exists for these inputs (the 77-intent question has no 'none' option), so a calibrated model's confidence should be low; 1/77 = 0.013 is a uniform guess.",
  "jev_calls": {
    "ok": 100,
    "input_tokens": 169084,
    "median_latency_ms": 104.35317899998608,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## order_shuffle_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.799,
    "accuracy_ci95": [
      0.7730388132545092,
      0.8226727851351658
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.8734299999999999,
    "overconfidence": 0.07442999999999989,
    "ece": 0.07628999999999993,
    "ece_repo_float32_edges": 0.07628999999999998,
    "clean_accuracy_same_examples": 0.8,
    "same_answer_as_original_order": 0.95,
    "mean_abs_change_in_p_gold": 0.032380000000000006
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.813,
    "accuracy_ci95": [
      0.7876522640280523,
      0.835952185122343
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.8441815786063671,
    "overconfidence": 0.031181578606367166,
    "ece": 0.036378882139921215,
    "ece_repo_float32_edges": 0.036378882139921215,
    "clean_accuracy_same_examples": 0.813,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.596,
    "accuracy_ci95": [
      0.5652754707472443,
      0.6259897916119823
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5967255310937762,
    "overconfidence": 0.000725531093776266,
    "ece": 0.023855041213333594,
    "ece_repo_float32_edges": 0.023855041213333598,
    "clean_accuracy_same_examples": 0.596,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.625,
    "accuracy_ci95": [
      0.594569604368661,
      0.6544737059949155
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7195729937106371,
    "overconfidence": 0.0945729937106371,
    "ece": 0.0970957229882479,
    "ece_repo_float32_edges": 0.0970957229882479,
    "clean_accuracy_same_examples": 0.625,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.601,
    "accuracy_ci95": [
      0.5703182459971236,
      0.6309087487766462
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6586520772352815,
    "overconfidence": 0.05765207723528154,
    "ece": 0.05844845492392777,
    "ece_repo_float32_edges": 0.058448454923927765,
    "clean_accuracy_same_examples": 0.601,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.928,
    "accuracy_ci95": [
      0.9102882162639245,
      0.9424360784209613
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9354059181809425,
    "overconfidence": 0.0074059181809424945,
    "ece": 0.02228577798604966,
    "ece_repo_float32_edges": 0.02228577798604966,
    "clean_accuracy_same_examples": 0.928,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.83,
    "accuracy_ci95": [
      0.8054659348348435,
      0.8520084045249984
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.8323595410734415,
    "overconfidence": 0.0023595410734414957,
    "ece": 0.019787779137492193,
    "ece_repo_float32_edges": 0.019787779137492193,
    "clean_accuracy_same_examples": 0.83,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.82,
    "accuracy_ci95": [
      0.7949777668912537,
      0.842573107639502
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7924646461308003,
    "overconfidence": -0.027535353869199697,
    "ece": 0.0613443310856819,
    "ece_repo_float32_edges": 0.061344331085681894,
    "clean_accuracy_same_examples": 0.82,
    "note": "BEMA has a fixed output layer, so option order cannot affect it"
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1689632,
    "median_latency_ms": 103.10792249993028,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## repeat_banking

```json
{
  "jev": {
    "n_queries": 200,
    "calls": 1000,
    "share_same_answer_all_repeats": 0.97,
    "share_identical_probabilities_all_repeats": 0.485,
    "mean_confidence_spread_max_minus_min": 0.0223,
    "distinct_gold_intents_covered": 15
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1689260,
    "median_latency_ms": 105.80238099998951,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## question_count

```json
{
  "jev": {
    "1": {
      "calls": 60,
      "median_latency_ms": 96.19828150005105,
      "p90_latency_ms": 129.05930000010812,
      "mean_input_tokens": 302.3333333333333,
      "all_questions_answered": true
    },
    "2": {
      "calls": 60,
      "median_latency_ms": 93.03473900001791,
      "p90_latency_ms": 123.67354899993188,
      "mean_input_tokens": 320.3333333333333,
      "all_questions_answered": true
    },
    "4": {
      "calls": 60,
      "median_latency_ms": 99.04904500001521,
      "p90_latency_ms": 146.8861119999474,
      "mean_input_tokens": 353.3333333333333,
      "all_questions_answered": true
    },
    "8": {
      "calls": 60,
      "median_latency_ms": 94.9717055000292,
      "p90_latency_ms": 134.82437400011804,
      "mean_input_tokens": 410.3333333333333,
      "all_questions_answered": true
    },
    "16": {
      "calls": 60,
      "median_latency_ms": 104.73331850005252,
      "p90_latency_ms": 134.19534900003782,
      "mean_input_tokens": 533.3333333333334,
      "all_questions_answered": true
    },
    "latency_ratio_16_vs_1": 1.088723383275791,
    "median_paired_ratio_16_vs_1_same_message": 1.11871193178987,
    "scope_note": "60 short SMS texts, yes/no questions only, one call at a time; input tokens rise with the number of questions"
  },
  "jev_calls": {
    "ok": 300,
    "input_tokens": 115180,
    "median_latency_ms": 97.37181200011946,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## score_amazon_clean

```json
{
  "jev": {
    "n": 1517,
    "n_missing": 0,
    "pearson_r_expected_stars": 0.9204438569786791,
    "mae_stars_expected": 0.3542579386481825,
    "exact_star_accuracy_argmax": 0.7528015820698748,
    "within_one_star_argmax": 0.9690177982860909,
    "ece_argmax": 0.058094924192485145
  },
  "bema_v2_full_gpu": {
    "n": 1517,
    "pearson_r_expected_stars": 0.8208694647691138,
    "mae_stars_expected": 0.5157737260047118,
    "exact_star_accuracy_rounded": 0.6381015161502966,
    "within_one_star_rounded": 0.9235332893869479
  },
  "bema_baseline": {
    "n": 1517,
    "pearson_r_expected_stars": 0.5351059055276922,
    "mae_stars_expected": 0.7467573764651091,
    "exact_star_accuracy_rounded": 0.5603164139749506,
    "within_one_star_rounded": 0.8246539222148979
  },
  "bema_v2": {
    "n": 1517,
    "pearson_r_expected_stars": 0.8000647002850413,
    "mae_stars_expected": 0.5408927980974936,
    "exact_star_accuracy_rounded": 0.6196440342781806,
    "within_one_star_rounded": 0.9143045484508899
  },
  "bema_v3": {
    "n": 1517,
    "pearson_r_expected_stars": 0.8975744655045146,
    "mae_stars_expected": 0.3608285487729543,
    "exact_star_accuracy_rounded": 0.7600527356624918,
    "within_one_star_rounded": 0.959789057350033
  },
  "gold_distribution": {
    "1": 162,
    "2": 82,
    "3": 119,
    "4": 222,
    "5": 932
  },
  "note": "BEMA reads only the first 64 tokens of each review (its trained input length); Jev reads the whole review. Jev's expected stars divide by the sum of its returned probabilities, which is 0.99 on a few rows because Jev rounds to 2 decimals.",
  "jev_calls": {
    "ok": 1517,
    "input_tokens": 648851,
    "median_latency_ms": 113.90382400009003,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## score_amazon_swap2

```json
{
  "jev": {
    "n": 1517,
    "n_missing": 0,
    "pearson_r_expected_stars": 0.9200135972331689,
    "mae_stars_expected": 0.36061045524460156,
    "exact_star_accuracy_argmax": 0.7554383651944627,
    "within_one_star_argmax": 0.969676994067238,
    "ece_argmax": 0.051397495056031604
  },
  "bema_v3": {
    "n": 1517,
    "pearson_r_expected_stars": 0.8882415090549872,
    "mae_stars_expected": 0.37431188468958254,
    "exact_star_accuracy_rounded": 0.7534607778510217,
    "within_one_star_rounded": 0.9571522742254449
  },
  "bema_v2_full_gpu": {
    "n": 1517,
    "pearson_r_expected_stars": 0.8077816520491287,
    "mae_stars_expected": 0.5339543294105077,
    "exact_star_accuracy_rounded": 0.6249176005273567,
    "within_one_star_rounded": 0.918918918918919
  },
  "bema_v2": {
    "n": 1517,
    "pearson_r_expected_stars": 0.7883831638994686,
    "mae_stars_expected": 0.5609373842011806,
    "exact_star_accuracy_rounded": 0.6064601186552406,
    "within_one_star_rounded": 0.9096901779828609
  },
  "bema_baseline": {
    "n": 1517,
    "pearson_r_expected_stars": 0.5170020976871257,
    "mae_stars_expected": 0.7587246529232458,
    "exact_star_accuracy_rounded": 0.5576796308503625,
    "within_one_star_rounded": 0.8246539222148979
  },
  "gold_distribution": {
    "1": 162,
    "2": 82,
    "3": 119,
    "4": 222,
    "5": 932
  },
  "note": "BEMA reads only the first 64 tokens of each review (its trained input length); Jev reads the whole review. Jev's expected stars divide by the sum of its returned probabilities, which is 0.99 on a few rows because Jev rounds to 2 decimals.",
  "jev_calls": {
    "ok": 1517,
    "input_tokens": 652230,
    "median_latency_ms": 117.56405099981748,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## clinc150_clean

```json
{
  "jev": {
    "n": 5500,
    "accuracy": 0.9085454545454545,
    "accuracy_ci95": [
      0.9006395978348731,
      0.9158810148270775
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.9165927272727273,
    "overconfidence": 0.008047272727272792,
    "ece": 0.017087272727272756,
    "ece_repo_float32_edges": 0.01708727272727279,
    "in_scope_accuracy": 0.9077777777777778,
    "oos_recall": 0.912,
    "false_oos_rate_on_in_scope": 0.034,
    "n_in_scope": 4500,
    "n_oos": 1000,
    "n_missing": 0
  },
  "zs3_from_banking": {
    "n": 5500,
    "accuracy": 0.5570909090909091,
    "accuracy_ci95": [
      0.5439279307122523,
      0.5701741931755325
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.520871620665897,
    "overconfidence": -0.0362192884250121,
    "ece": 0.043838538657535196,
    "ece_repo_float32_edges": 0.043838538657535196,
    "in_scope_accuracy": 0.6804444444444444,
    "oos_recall": 0.002,
    "false_oos_rate_on_in_scope": 0.0006666666666666666,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "bema_clinc150": {
    "n": 5500,
    "accuracy": 0.7145454545454546,
    "accuracy_ci95": [
      0.7024631746248053,
      0.7263282463547682
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7503661269816485,
    "overconfidence": 0.03582067243619391,
    "ece": 0.04362840042331004,
    "ece_repo_float32_edges": 0.04362840042331004,
    "in_scope_accuracy": 0.8386666666666667,
    "oos_recall": 0.156,
    "false_oos_rate_on_in_scope": 0.004,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_from_banking": {
    "n": 5500,
    "accuracy": 0.5661818181818182,
    "accuracy_ci95": [
      0.5530423092151783,
      0.5792289426802156
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6146313922947103,
    "overconfidence": 0.04844957411289208,
    "ece": 0.04844957411289217,
    "ece_repo_float32_edges": 0.04844957411289218,
    "in_scope_accuracy": 0.6915555555555556,
    "oos_recall": 0.002,
    "false_oos_rate_on_in_scope": 0.0,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_offshelf": {
    "n": 5500,
    "accuracy": 0.5596363636363636,
    "accuracy_ci95": [
      0.5464795068305641,
      0.5727099728993512
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5510734701038085,
    "overconfidence": -0.008562893532555127,
    "ece": 0.023136103872887136,
    "ece_repo_float32_edges": 0.023136103872887136,
    "in_scope_accuracy": 0.6837777777777778,
    "oos_recall": 0.001,
    "false_oos_rate_on_in_scope": 0.0,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_offshelf_bge_base": {
    "n": 5500,
    "accuracy": 0.5878181818181818,
    "accuracy_ci95": [
      0.5747526210960061,
      0.6007611554574972
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.608059735440395,
    "overconfidence": 0.02024155362221325,
    "ece": 0.03160071622377094,
    "ece_repo_float32_edges": 0.03160071622377094,
    "in_scope_accuracy": 0.7184444444444444,
    "oos_recall": 0.0,
    "false_oos_rate_on_in_scope": 0.0,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "jev_calls": {
    "ok": 5500,
    "input_tokens": 13915632,
    "median_latency_ms": 190.52225050018023,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## clinc150_swap2

```json
{
  "jev": {
    "n": 5500,
    "accuracy": 0.8721818181818182,
    "accuracy_ci95": [
      0.8630972841418554,
      0.880746816489659
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.8842927272727272,
    "overconfidence": 0.012110909090909061,
    "ece": 0.018103636363636395,
    "ece_repo_float32_edges": 0.0181036363636364,
    "in_scope_accuracy": 0.8648888888888889,
    "oos_recall": 0.905,
    "false_oos_rate_on_in_scope": 0.059555555555555556,
    "n_in_scope": 4500,
    "n_oos": 1000,
    "n_missing": 0
  },
  "bema_clinc150": {
    "n": 5500,
    "accuracy": 0.4465454545454545,
    "accuracy_ci95": [
      0.4334489543963063,
      0.45971657291895246
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.557192429125309,
    "overconfidence": 0.11064697457985445,
    "ece": 0.11064697457985441,
    "ece_repo_float32_edges": 0.11064697457985442,
    "in_scope_accuracy": 0.49644444444444447,
    "oos_recall": 0.222,
    "false_oos_rate_on_in_scope": 0.044444444444444446,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_offshelf": {
    "n": 5500,
    "accuracy": 0.39690909090909093,
    "accuracy_ci95": [
      0.3840552040770289,
      0.4099068843166845
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.38176388379592785,
    "overconfidence": -0.015145207113163084,
    "ece": 0.027849447110159825,
    "ece_repo_float32_edges": 0.027849447110159825,
    "in_scope_accuracy": 0.4851111111111111,
    "oos_recall": 0.0,
    "false_oos_rate_on_in_scope": 0.00022222222222222223,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs3_from_banking": {
    "n": 5500,
    "accuracy": 0.3967272727272727,
    "accuracy_ci95": [
      0.3838745251354719,
      0.4097241806980893
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.3555855637446723,
    "overconfidence": -0.04114170898260039,
    "ece": 0.04710648145831444,
    "ece_repo_float32_edges": 0.04710648145831444,
    "in_scope_accuracy": 0.48444444444444446,
    "oos_recall": 0.002,
    "false_oos_rate_on_in_scope": 0.0024444444444444444,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_from_banking": {
    "n": 5500,
    "accuracy": 0.39127272727272727,
    "accuracy_ci95": [
      0.3784550253548987,
      0.404242203674097
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4278741883296858,
    "overconfidence": 0.03660146105695855,
    "ece": 0.037229858001524764,
    "ece_repo_float32_edges": 0.037229858001524764,
    "in_scope_accuracy": 0.478,
    "oos_recall": 0.001,
    "false_oos_rate_on_in_scope": 0.0,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "zs_offshelf_bge_base": {
    "n": 5500,
    "accuracy": 0.42872727272727273,
    "accuracy_ci95": [
      0.4157023528701768,
      0.4418516835501683
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4448031595112248,
    "overconfidence": 0.016075886783952054,
    "ece": 0.020666413581506768,
    "ece_repo_float32_edges": 0.02066641358150677,
    "in_scope_accuracy": 0.524,
    "oos_recall": 0.0,
    "false_oos_rate_on_in_scope": 0.00044444444444444447,
    "n_in_scope": 4500,
    "n_oos": 1000
  },
  "jev_calls": {
    "ok": 5500,
    "input_tokens": 13926553,
    "median_latency_ms": 187.34676600001876,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_control_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.8,
    "accuracy_ci95": [
      0.7740810351387634,
      0.8236229097338202
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.8773,
    "overconfidence": 0.07729999999999992,
    "ece": 0.07814,
    "ece_repo_float32_edges": 0.07813999999999993,
    "clean_accuracy_same_examples": 0.8
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.455,
    "accuracy_ci95": [
      0.4243668457592273,
      0.48597756250988505
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6177605954557657,
    "overconfidence": 0.16276059545576566,
    "ece": 0.16276059545576577,
    "ece_repo_float32_edges": 0.16276059545576577,
    "clean_accuracy_same_examples": 0.82
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.574,
    "accuracy_ci95": [
      0.5431257346038579,
      0.6043079051313792
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5729329000040889,
    "overconfidence": -0.001067099995911036,
    "ece": 0.02635606568306685,
    "ece_repo_float32_edges": 0.02635606568306685,
    "clean_accuracy_same_examples": 0.601
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.715,
    "accuracy_ci95": [
      0.686240270603642,
      0.7421142232217094
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7295264605209232,
    "overconfidence": 0.014526460520923212,
    "ece": 0.025882763616740717,
    "ece_repo_float32_edges": 0.025882763616740717,
    "clean_accuracy_same_examples": 0.83
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.556,
    "accuracy_ci95": [
      0.52504916226501,
      0.5865222407778723
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.636763524837792,
    "overconfidence": 0.08076352483779192,
    "ece": 0.08441621481627226,
    "ece_repo_float32_edges": 0.08441621481627223,
    "clean_accuracy_same_examples": 0.625
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.68,
    "accuracy_ci95": [
      0.650446375688877,
      0.7081759912346732
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7040918885022401,
    "overconfidence": 0.02409188850224009,
    "ece": 0.041123325839638694,
    "ece_repo_float32_edges": 0.041123325839638694,
    "clean_accuracy_same_examples": 0.813
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.584,
    "accuracy_ci95": [
      0.5531860719507685,
      0.6141710326135549
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5485626148581505,
    "overconfidence": -0.035437385141849465,
    "ece": 0.03694602105021478,
    "ece_repo_float32_edges": 0.03694602105021478,
    "clean_accuracy_same_examples": 0.596
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.826,
    "accuracy_ci95": [
      0.8012673035282363,
      0.8482376498999711
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7915837953984738,
    "overconfidence": -0.03441620460152617,
    "ece": 0.03919767066836357,
    "ece_repo_float32_edges": 0.03919767066836356,
    "clean_accuracy_same_examples": 0.928
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1704632,
    "median_latency_ms": 98.30493050026234,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_prefix_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.62,
    "accuracy_ci95": [
      0.5895108840773737,
      0.6495706938716597
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.71943,
    "overconfidence": 0.09943000000000002,
    "ece": 0.09943000000000003,
    "ece_repo_float32_edges": 0.09943000000000005,
    "clean_accuracy_same_examples": 0.8,
    "followed_injected_label": 0.277,
    "mean_confidence_when_following_injection": 0.66028880866426,
    "share_following_injection_with_confidence_ge_0.9": 0.10469314079422383,
    "picked_target_without_injection": 0.005
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.392,
    "accuracy_ci95": [
      0.3622102249574891,
      0.4226163548883808
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5707737312316895,
    "overconfidence": 0.1787737312316895,
    "ece": 0.17877373123168944,
    "ece_repo_float32_edges": 0.17877373123168944,
    "clean_accuracy_same_examples": 0.625,
    "followed_injected_label": 0.278
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.411,
    "accuracy_ci95": [
      0.3809022195679717,
      0.44177894345316165
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4712738127633929,
    "overconfidence": 0.06027381276339294,
    "ece": 0.07261636898666622,
    "ece_repo_float32_edges": 0.07261636898666622,
    "clean_accuracy_same_examples": 0.596,
    "followed_injected_label": 0.217
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.491,
    "accuracy_ci95": [
      0.46010903290475313,
      0.5219598487490692
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7704323547631502,
    "overconfidence": 0.2794323547631502,
    "ece": 0.289939119681716,
    "ece_repo_float32_edges": 0.289939119681716,
    "clean_accuracy_same_examples": 0.928,
    "followed_injected_label": 0.373
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.377,
    "accuracy_ci95": [
      0.3474870931733662,
      0.40745428942887446
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6452262495607137,
    "overconfidence": 0.2682262495607137,
    "ece": 0.2694188119322061,
    "ece_repo_float32_edges": 0.2694188119322061,
    "clean_accuracy_same_examples": 0.83,
    "followed_injected_label": 0.325
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.34,
    "accuracy_ci95": [
      0.31130188208435167,
      0.3699226806502704
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6618743592128158,
    "overconfidence": 0.32187435921281576,
    "ece": 0.32635709542781116,
    "ece_repo_float32_edges": 0.3263570954278111,
    "clean_accuracy_same_examples": 0.813,
    "followed_injected_label": 0.336
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.218,
    "accuracy_ci95": [
      0.19351481439641632,
      0.24464347742335513
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5597458284795285,
    "overconfidence": 0.3417458284795285,
    "ece": 0.34174582847952845,
    "ece_repo_float32_edges": 0.34174582847952845,
    "clean_accuracy_same_examples": 0.82,
    "followed_injected_label": 0.242
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.387,
    "accuracy_ci95": [
      0.35729917386067067,
      0.4175656735706561
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5008671406432986,
    "overconfidence": 0.11386714064329861,
    "ece": 0.12443248104304074,
    "ece_repo_float32_edges": 0.12443248104304074,
    "clean_accuracy_same_examples": 0.601,
    "followed_injected_label": 0.321
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1704925,
    "median_latency_ms": 99.60339400004159,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_casual_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.326,
    "accuracy_ci95": [
      0.29766113121857135,
      0.35567058075533015
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.73497,
    "overconfidence": 0.40897,
    "ece": 0.40955,
    "ece_repo_float32_edges": 0.40955,
    "clean_accuracy_same_examples": 0.8,
    "followed_injected_label": 0.635,
    "mean_confidence_when_following_injection": 0.7538740157480315,
    "share_following_injection_with_confidence_ge_0.9": 0.24881889763779527,
    "picked_target_without_injection": 0.005
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.439,
    "accuracy_ci95": [
      0.4085331919057744,
      0.4699336726368002
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6280442595779896,
    "overconfidence": 0.1890442595779896,
    "ece": 0.1890442595779896,
    "ece_repo_float32_edges": 0.1890442595779896,
    "clean_accuracy_same_examples": 0.82,
    "followed_injected_label": 0.223
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.509,
    "accuracy_ci95": [
      0.4780401512509307,
      0.5398909670952468
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7210735536068678,
    "overconfidence": 0.21207355360686775,
    "ece": 0.21326605613529684,
    "ece_repo_float32_edges": 0.21326605613529684,
    "clean_accuracy_same_examples": 0.83,
    "followed_injected_label": 0.257
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.596,
    "accuracy_ci95": [
      0.5652754707472443,
      0.6259897916119823
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.797572723403573,
    "overconfidence": 0.20157272340357302,
    "ece": 0.20880793552100654,
    "ece_repo_float32_edges": 0.20880793552100657,
    "clean_accuracy_same_examples": 0.928,
    "followed_injected_label": 0.28
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.508,
    "accuracy_ci95": [
      0.4770429302488735,
      0.5388958416143953
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7345759645849467,
    "overconfidence": 0.22657596458494667,
    "ece": 0.2265759645849466,
    "ece_repo_float32_edges": 0.2265759645849466,
    "clean_accuracy_same_examples": 0.813,
    "followed_injected_label": 0.265
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.384,
    "accuracy_ci95": [
      0.35435414121081066,
      0.41453366677179027
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5643105530589819,
    "overconfidence": 0.18031055305898191,
    "ece": 0.1803105530589819,
    "ece_repo_float32_edges": 0.18031055305898186,
    "clean_accuracy_same_examples": 0.601,
    "followed_injected_label": 0.335
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.439,
    "accuracy_ci95": [
      0.4085331919057744,
      0.4699336726368002
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.48949790131300686,
    "overconfidence": 0.050497901313006854,
    "ece": 0.05579890570789575,
    "ece_repo_float32_edges": 0.05579890570789575,
    "clean_accuracy_same_examples": 0.596,
    "followed_injected_label": 0.172
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.438,
    "accuracy_ci95": [
      0.4075446562007944,
      0.46892986185887153
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6269530909955502,
    "overconfidence": 0.1889530909955502,
    "ece": 0.18975716200470924,
    "ece_repo_float32_edges": 0.18975716200470924,
    "clean_accuracy_same_examples": 0.625,
    "followed_injected_label": 0.252
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1700923,
    "median_latency_ms": 103.26950099988608,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_defended_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.778,
    "accuracy_ci95": [
      0.7512053589189334,
      0.8026669633296608
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.84839,
    "overconfidence": 0.07038999999999995,
    "ece": 0.07419000000000002,
    "ece_repo_float32_edges": 0.07418999999999998,
    "clean_accuracy_same_examples": 0.8,
    "followed_injected_label": 0.027,
    "mean_confidence_when_following_injection": 0.6674074074074073,
    "share_following_injection_with_confidence_ge_0.9": 0.18518518518518517,
    "picked_target_without_injection": 0.005
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.351,
    "accuracy_ci95": [
      0.32203957776457287,
      0.3811007962820438
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5819166163355112,
    "overconfidence": 0.2309166163355112,
    "ece": 0.23091661633551122,
    "ece_repo_float32_edges": 0.23091661633551122,
    "clean_accuracy_same_examples": 0.82,
    "followed_injected_label": 0.174
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.473,
    "accuracy_ci95": [
      0.4422178792270141,
      0.5039887657344533
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5326206590458751,
    "overconfidence": 0.0596206590458751,
    "ece": 0.05962065904587506,
    "ece_repo_float32_edges": 0.05962065904587507,
    "clean_accuracy_same_examples": 0.601,
    "followed_injected_label": 0.202
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.565,
    "accuracy_ci95": [
      0.5340823276708649,
      0.5954201937181948
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6913267249986529,
    "overconfidence": 0.12632672499865294,
    "ece": 0.12637334906309844,
    "ece_repo_float32_edges": 0.12637334906309844,
    "clean_accuracy_same_examples": 0.83,
    "followed_injected_label": 0.172
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.456,
    "accuracy_ci95": [
      0.4253575126880501,
      0.4869792420639709
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5965021628141404,
    "overconfidence": 0.14050216281414035,
    "ece": 0.14050216281414032,
    "ece_repo_float32_edges": 0.14050216281414032,
    "clean_accuracy_same_examples": 0.625,
    "followed_injected_label": 0.182
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.456,
    "accuracy_ci95": [
      0.4253575126880501,
      0.4869792420639709
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4914701466709375,
    "overconfidence": 0.03547014667093751,
    "ece": 0.038572566837072365,
    "ece_repo_float32_edges": 0.03857256683707237,
    "clean_accuracy_same_examples": 0.596,
    "followed_injected_label": 0.163
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.469,
    "accuracy_ci95": [
      0.43824750717667105,
      0.49998975185316186
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6884968158602714,
    "overconfidence": 0.21949681586027148,
    "ece": 0.22317976599931713,
    "ece_repo_float32_edges": 0.22317976599931716,
    "clean_accuracy_same_examples": 0.813,
    "followed_injected_label": 0.237
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.605,
    "accuracy_ci95": [
      0.574354826213607,
      0.6348415544917972
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7837787940204144,
    "overconfidence": 0.1787787940204144,
    "ece": 0.19066175192594528,
    "ece_repo_float32_edges": 0.19066175192594526,
    "clean_accuracy_same_examples": 0.928,
    "followed_injected_label": 0.271
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1729932,
    "median_latency_ms": 102.49037599987787,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_oos_clinc

```json
{
  "jev": {
    "n": 1000,
    "accuracy": 0.805,
    "accuracy_ci95": [
      0.7792957710041268,
      0.8283699062829999
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.77308,
    "overconfidence": -0.03192000000000006,
    "ece": 0.061379999999999976,
    "ece_repo_float32_edges": 0.06017999999999995,
    "said_oos_with_note": 0.16,
    "said_oos_without_note_same_requests": 0.027,
    "clean_accuracy_same_requests": 0.92,
    "n_missing": 0
  },
  "bema_clinc150": {
    "n": 1000,
    "accuracy": 0.396,
    "accuracy_ci95": [
      0.3661414496046327,
      0.42665451617287165
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5705356498956681,
    "overconfidence": 0.17453564989566805,
    "ece": 0.17453564989566803,
    "ece_repo_float32_edges": 0.17453564989566803,
    "said_oos_with_note": 0.338
  },
  "zs3_from_banking": {
    "n": 1000,
    "accuracy": 0.396,
    "accuracy_ci95": [
      0.3661414496046327,
      0.42665451617287165
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.4976284997463226,
    "overconfidence": 0.1016284997463226,
    "ece": 0.11510646718740462,
    "ece_repo_float32_edges": 0.11510646718740461,
    "said_oos_with_note": 0.424
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.633,
    "accuracy_ci95": [
      0.6026706262327246,
      0.6623114559941208
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5224883398301899,
    "overconfidence": -0.11051166016981007,
    "ece": 0.11051166016981005,
    "ece_repo_float32_edges": 0.11051166016981007,
    "said_oos_with_note": 0.03
  },
  "zs_from_banking": {
    "n": 1000,
    "accuracy": 0.648,
    "accuracy_ci95": [
      0.6178838667887637,
      0.6769834126817108
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5795753790847957,
    "overconfidence": -0.06842462091520429,
    "ece": 0.07400107102468609,
    "ece_repo_float32_edges": 0.07400107102468609,
    "said_oos_with_note": 0.051
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 2543064,
    "median_latency_ms": 134.76569649992598,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## injection_casual_defended_banking

```json
{
  "jev": {
    "n": 1000,
    "n_missing": 0,
    "accuracy": 0.63,
    "accuracy_ci95": [
      0.5996317178851427,
      0.659373324892977
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.75539,
    "overconfidence": 0.12539,
    "ece": 0.12657000000000004,
    "ece_repo_float32_edges": 0.12656999999999993,
    "clean_accuracy_same_examples": 0.8,
    "followed_injected_label": 0.234,
    "mean_confidence_when_following_injection": 0.660042735042735,
    "share_following_injection_with_confidence_ge_0.9": 0.14102564102564102,
    "picked_target_without_injection": 0.005
  },
  "bema_v2_full_gpu": {
    "n": 1000,
    "accuracy": 0.509,
    "accuracy_ci95": [
      0.4780401512509307,
      0.5398909670952468
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7210735536068678,
    "overconfidence": 0.21207355360686775,
    "ece": 0.21326605613529684,
    "ece_repo_float32_edges": 0.21326605613529684,
    "clean_accuracy_same_examples": 0.83,
    "followed_injected_label": 0.257
  },
  "bema_v3": {
    "n": 1000,
    "accuracy": 0.596,
    "accuracy_ci95": [
      0.5652754707472443,
      0.6259897916119823
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.797572723403573,
    "overconfidence": 0.20157272340357302,
    "ece": 0.20880793552100654,
    "ece_repo_float32_edges": 0.20880793552100657,
    "clean_accuracy_same_examples": 0.928,
    "followed_injected_label": 0.28
  },
  "zs_offshelf": {
    "n": 1000,
    "accuracy": 0.384,
    "accuracy_ci95": [
      0.35435414121081066,
      0.41453366677179027
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.5643105530589819,
    "overconfidence": 0.18031055305898191,
    "ece": 0.1803105530589819,
    "ece_repo_float32_edges": 0.18031055305898186,
    "clean_accuracy_same_examples": 0.601,
    "followed_injected_label": 0.335
  },
  "zs3_from_clinc": {
    "n": 1000,
    "accuracy": 0.439,
    "accuracy_ci95": [
      0.4085331919057744,
      0.4699336726368002
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.48949790131300686,
    "overconfidence": 0.050497901313006854,
    "ece": 0.05579890570789575,
    "ece_repo_float32_edges": 0.05579890570789575,
    "clean_accuracy_same_examples": 0.596,
    "followed_injected_label": 0.172
  },
  "bema_baseline": {
    "n": 1000,
    "accuracy": 0.439,
    "accuracy_ci95": [
      0.4085331919057744,
      0.4699336726368002
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6280442595779896,
    "overconfidence": 0.1890442595779896,
    "ece": 0.1890442595779896,
    "ece_repo_float32_edges": 0.1890442595779896,
    "clean_accuracy_same_examples": 0.82,
    "followed_injected_label": 0.223
  },
  "bema_v2": {
    "n": 1000,
    "accuracy": 0.508,
    "accuracy_ci95": [
      0.4770429302488735,
      0.5388958416143953
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.7345759645849467,
    "overconfidence": 0.22657596458494667,
    "ece": 0.2265759645849466,
    "ece_repo_float32_edges": 0.2265759645849466,
    "clean_accuracy_same_examples": 0.813,
    "followed_injected_label": 0.265
  },
  "zs_from_clinc": {
    "n": 1000,
    "accuracy": 0.438,
    "accuracy_ci95": [
      0.4075446562007944,
      0.46892986185887153
    ],
    "ci_method": "Wilson score",
    "mean_confidence": 0.6269530909955502,
    "overconfidence": 0.1889530909955502,
    "ece": 0.18975716200470924,
    "ece_repo_float32_edges": 0.18975716200470924,
    "clean_accuracy_same_examples": 0.625,
    "followed_injected_label": 0.252
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1724923,
    "median_latency_ms": 112.69991900007881,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## repeat_banking_spread

```json
{
  "jev": {
    "n_queries": 200,
    "calls": 1000,
    "share_same_answer_all_repeats": 0.97,
    "share_identical_probabilities_all_repeats": 0.46,
    "mean_confidence_spread_max_minus_min": 0.023849999999999996,
    "distinct_gold_intents_covered": 69
  },
  "jev_calls": {
    "ok": 1000,
    "input_tokens": 1689950,
    "median_latency_ms": 105.24876799991034,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

## latency_sequential_banking

```json
{
  "jev": {
    "calls": 100,
    "median_latency_ms": 99.00380149974808,
    "p90_latency_ms": 133.55715999978202,
    "note": "one call at a time, same 100 clean BANKING77 queries as the LLM latency test"
  },
  "jev_calls": {
    "ok": 100,
    "input_tokens": 168878,
    "median_latency_ms": 99.00380149974808,
    "model_versions": [
      "jev-1.14.0"
    ]
  }
}
```

Red-team Jev cost: {'input_tokens': 47846700, 'usd': 2.0095614}
