"""Final probes: CIs (check E), spam confusion, repeat-based run-to-run variation, high-confidence accuracy."""
import json
from collections import defaultdict
import numpy as np
ROOT = "/home/claude/mit37/bema"
rj = lambda p: [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
m = json.load(open(f"{ROOT}/runs/audit/audit_metrics.json"))
rep = json.load(open(f"{ROOT}/runs/report.json"))
out = {}
out["E"] = {"reported": rep["tasks"]["banking77"]["clean"]["jev"]["accuracy_ci95"],
            "numpy_bootstrap_10k_seed2026": m["core"]["E_banking_clean_ci_numpy_bootstrap"],
            "python_bootstrap_4k_seed12345": m["core"]["E_banking_clean_ci_python_bootstrap"],
            "wilson": m["core"]["E_banking_clean_ci_wilson"]}
out["spam_confusion"] = {c: m["core"]["tasks"]["spam"][c]["confusion"] for c in m["core"]["tasks"]["spam"]}
out["spam_clean_dedup"] = m["core"]["spam_clean_dedup"]
CATS = json.load(open(f"{ROOT}/runs/inputs/categories.json"))
items = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/repeat_banking.jsonl")}
acc_by_round = defaultdict(list)
for r in rj(f"{ROOT}/runs/redteam/jev/repeat_banking.jsonl"):
    it = items[r["key"]]
    acc_by_round[it["meta"]["repeat"]].append(float(r["response"]["answers"]["intent"]["choice"] == it["gold"]))
out["repeat_accuracy_per_round_200q"] = {k: float(np.mean(v)) for k, v in sorted(acc_by_round.items())}
inp = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")}
hi = defaultdict(list)
for r in rj(f"{ROOT}/runs/jev/banking77_clean.jsonl"):
    a = r["response"]["answers"]["intent"]
    c = a["probabilities"][a["choice"]]
    y = float(a["choice"] == CATS[inp[r["idx"]]["label"]])
    if c >= 0.999: hi["1.0"].append(y)
    if c >= 0.9: hi[">=0.9"].append(y)
out["banking_clean_high_conf"] = {k: {"n": len(v), "accuracy": float(np.mean(v))} for k, v in hi.items()}
for n in ["score_amazon_clean"]:
    j = m["redteam"][n]["jev"]
    out[n + "_baselines"] = {"always_5_exact": j["baseline_always_5_exact"], "always_5_mae": j["baseline_always_5_mae"],
                             "jev_exact": j["exact_star_accuracy_argmax"], "jev_mae": j["mae_stars_expected"]}
for n in ["clinc150_clean", "clinc150_swap2"]:
    out[n + "_oos_precision"] = m["redteam"][n]["jev"]["oos_precision"]
out["question_count_paired_ratio_16_vs_1"] = m["redteam"]["question_count"]["jev"]["paired_median_ratio_16_vs_1"]
out["inj_defended_n_followed"] = m["redteam"]["injection_defended_banking"]["jev"]["n_followed"]
out["neither_gold_nor_target"] = {k: m["redteam"][k]["jev"].get("neither_gold_nor_target") for k in m["redteam"] if k.startswith("injection_") and k.endswith("banking")}
json.dump(out, open(f"{ROOT}/runs/audit/audit_extra2.json", "w"), indent=1)
print(json.dumps(out, indent=1))
