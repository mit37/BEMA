"""Independent audit, checks A (ground truth), B (typo regeneration), C (integrity).
Written from scratch; reads only raw files. Imports noise.py only for check B (as instructed)."""
import csv
import hashlib
import json
import random
import sys
from collections import Counter, defaultdict

ROOT = "/home/claude/mit37/bema"
sys.path.insert(0, ROOT)
OUT = {}


def rj(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def h(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()


cats = json.load(open(f"{ROOT}/runs/inputs/categories.json"))
raw_cats = json.load(open(f"{ROOT}/data/raw/banking_categories.json"))

# ---------------- A. ground truth ----------------
A = {}
A["categories_len"] = len(cats)
A["categories_unique"] = len(set(cats))
A["categories_equal_raw_banking_categories_json"] = cats == raw_cats
clean = rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")
with open(f"{ROOT}/data/raw/banking_test.csv", encoding="utf-8", newline="") as f:
    csv_rows = list(csv.DictReader(f))
A["banking_csv_rows"] = len(csv_rows)
A["banking_clean_rows"] = len(clean)
A["csv_categories_not_in_categories_json"] = sorted({r["category"] for r in csv_rows} - set(cats))
# positional match (inputs written in CSV order)
pos_text_mism = sum(1 for r, c in zip(clean, csv_rows) if r["text"] != c["text"])
pos_label_mism = sum(1 for r, c in zip(clean, csv_rows) if cats[r["label"]] != c["category"])
A["positional_text_mismatches"] = pos_text_mism
A["positional_label_mismatches"] = pos_label_mism
# text-keyed match (robust to order)
by_text = defaultdict(set)
for c in csv_rows:
    by_text[c["text"]].add(c["category"])
not_found = [r["idx"] for r in clean if r["text"] not in by_text]
text_label_mism = [r["idx"] for r in clean if r["text"] in by_text and cats[r["label"]] not in by_text[r["text"]]]
ambiguous = [t for t, s in by_text.items() if len(s) > 1]
A["text_not_found_in_csv"] = len(not_found)
A["text_keyed_label_mismatches"] = len(text_label_mism)
A["csv_texts_with_multiple_categories"] = len(ambiguous)
A["idx_contiguous"] = [r["idx"] for r in clean] == list(range(len(clean)))
A["label_distribution_min_max"] = [min(Counter(r["label"] for r in clean).values()),
                                   max(Counter(r["label"] for r in clean).values())]
A["n_distinct_labels_in_test"] = len({r["label"] for r in clean})

# spam ground truth by exact text
spam_raw = []
with open(f"{ROOT}/data/spam.csv", encoding="latin-1", newline="") as f:
    rd = csv.reader(f)
    next(rd)
    for row in rd:
        if len(row) >= 2 and row[0] in ("ham", "spam"):
            spam_raw.append((row[1], 1 if row[0] == "spam" else 0))
spam_by_text = defaultdict(set)
for t, y in spam_raw:
    spam_by_text[t].add(y)
spam_clean = rj(f"{ROOT}/runs/inputs/spam_clean.jsonl")
s_nf = [r["idx"] for r in spam_clean if r["text"] not in spam_by_text]
s_mism = [r["idx"] for r in spam_clean if r["text"] in spam_by_text and r["label"] not in spam_by_text[r["text"]]]
s_amb = [r["idx"] for r in spam_clean if len(spam_by_text.get(r["text"], ())) > 1]
A["spam_csv_rows"] = len(spam_raw)
A["spam_clean_rows"] = len(spam_clean)
A["spam_text_not_found"] = len(s_nf)
A["spam_label_mismatches"] = len(s_mism)
A["spam_ambiguous_text"] = len(s_amb)
A["spam_n_spam_in_test"] = sum(r["label"] for r in spam_clean)
# duplicates in test set (texts repeated within the 836 rows)
cnt = Counter(r["text"] for r in spam_clean)
A["spam_test_duplicate_texts"] = sum(v - 1 for v in cnt.values() if v > 1)
A["spam_test_distinct_texts"] = len(cnt)
# overlap with train is not checkable without the split; check overlap w/ whole csv counts
dup_in_csv = sum(1 for r in spam_clean if sum(1 for t, _ in spam_raw if t == r["text"]) > 1)
A["spam_test_rows_whose_text_appears_more_than_once_in_full_csv"] = dup_in_csv
OUT["A"] = A

# ---------------- B. typo regeneration ----------------
from noise import NOISE, perturb  # noqa: E402

B = {}
for task, conds in (("banking77", ["swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["swap2", "keyboard2", "mixed3"])):
    base = rj(f"{ROOT}/runs/inputs/{task}_clean.jsonl")
    base.sort(key=lambda r: r["idx"])
    for c in conds:
        seed = f"99-{c}" if task == "banking77" else f"99-spam-{c}"
        rnd = random.Random(seed)
        regen = [perturb(r["text"], NOISE[c], rnd) for r in base]
        frozen = rj(f"{ROOT}/runs/inputs/{task}_{c}.jsonl")
        fz = {r["idx"]: r for r in frozen}
        mism = sum(1 for r, t in zip(base, regen) if fz[r["idx"]]["text"] != t)
        lab = sum(1 for r in base if fz[r["idx"]]["label"] != r["label"])
        shabad = sum(1 for r in frozen if h(r["text"]) != r["text_sha256"])
        unchanged = sum(1 for r, t in zip(base, regen) if t == r["text"])
        B[f"{task}_{c}"] = {"n": len(frozen), "text_mismatches": mism, "label_mismatches_vs_clean": lab,
                            "sha_mismatches_in_input_file": shabad, "texts_identical_to_clean": unchanged}
OUT["B"] = B

# ---------------- C. integrity ----------------
C = {"core": {}, "redteam": {}}
models = Counter()
for task, conds in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    for c in conds:
        inp = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{c}.jsonl")}
        shabad_in = sum(1 for r in inp.values() if h(r["text"]) != r["text_sha256"])
        recs = rj(f"{ROOT}/runs/jev/{task}_{c}.jsonl")
        st = Counter(r["status"] for r in recs)
        ok = [r for r in recs if r["status"] == "ok"]
        per_idx = Counter(r["idx"] for r in ok)
        dup = sum(v - 1 for v in per_idx.values() if v > 1)
        missing = len(set(inp) - set(per_idx))
        extra = len(set(per_idx) - set(inp))
        sha_bad = sum(1 for r in ok if r["idx"] in inp and r["text_sha256"] != h(inp[r["idx"]]["text"]))
        attempts = Counter(r.get("attempts") for r in recs)
        for r in ok:
            models[r["response"].get("model")] += 1
        C["core"][f"{task}_{c}"] = {"records": len(recs), "status": dict(st), "dup_ok_records": dup,
                                    "missing_idx": missing, "extra_idx": extra, "sha_mismatch": sha_bad,
                                    "input_sha_mismatch": shabad_in, "attempts": dict(attempts)}
import glob, os  # noqa: E401,E402
for p in sorted(glob.glob(f"{ROOT}/runs/redteam/inputs/*.jsonl")):
    name = os.path.basename(p)[:-6]
    items = rj(p)
    inp = {it["key"]: it for it in items}
    shabad_in = sum(1 for it in items if h(it["state"]) != it["state_sha256"])
    dupkeys = len(items) - len(inp)
    recs = rj(f"{ROOT}/runs/redteam/jev/{name}.jsonl")
    st = Counter(r["status"] for r in recs)
    ok = [r for r in recs if r["status"] == "ok"]
    per = Counter(r["key"] for r in ok)
    dup = sum(v - 1 for v in per.values() if v > 1)
    missing = len(set(inp) - set(per))
    sha_bad = sum(1 for r in ok if r["key"] in inp and r["state_sha256"] != h(inp[r["key"]]["state"]))
    for r in ok:
        models[r["response"].get("model")] += 1
    C["redteam"][name] = {"items": len(items), "dup_input_keys": dupkeys, "records": len(recs), "status": dict(st),
                          "dup_ok_records": dup, "missing_keys": missing, "sha_mismatch": sha_bad,
                          "input_sha_mismatch": shabad_in}
C["response_model_values"] = dict(models)
OUT["C"] = C

json.dump(OUT, open(f"{ROOT}/runs/audit/abc_results.json", "w"), indent=2)
print(json.dumps(OUT, indent=1))
