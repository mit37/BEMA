"""Independent recomputation of every Jev metric (checks D, E, F).
Written from scratch; does not import bench_jev.py, redteam_jev.py or calib_utils.py.
Reads only raw files under runs/inputs, runs/jev, runs/redteam/{inputs,jev}, data/raw."""
import hashlib
import json
import math
import random
import statistics
from collections import Counter, defaultdict

import numpy as np

ROOT = "/home/claude/mit37/bema"
AUD = f"{ROOT}/runs/audit"


def rj(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def h(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()


CATS = json.load(open(f"{ROOT}/runs/inputs/categories.json"))
CATSET = set(CATS)


# ---------------------------------------------------------------- metric helpers
def bin_exact(c):
    """Spec bins on exact decimal edges: bin 0 = [0, 0.1], bin k = (k/10, (k+1)/10]."""
    c10 = round(float(c) * 10, 6)          # kill float noise like 0.30000000000000004
    return min(9, max(0, math.ceil(c10) - 1))


def ece_exact(conf, corr):
    conf, corr = np.asarray(conf, float), np.asarray(corr, float)
    b = np.array([bin_exact(c) for c in conf])
    tot = 0.0
    for k in range(10):
        m = b == k
        if m.any():
            tot += m.mean() * abs(corr[m].mean() - conf[m].mean())
    return float(tot)


def ece_float_edges(conf, corr, edges):
    """Same rule but with a supplied list of float edges (to reproduce edge artefacts)."""
    conf, corr = np.asarray(conf, float), np.asarray(corr, float)
    tot = 0.0
    for k in range(10):
        lo, hi = edges[k], edges[k + 1]
        m = (conf > lo) & (conf <= hi)
        if k == 0:
            m |= conf == lo
        if m.any():
            tot += m.mean() * abs(corr[m].mean() - conf[m].mean())
    return float(tot)


F32_EDGES = [float(x) for x in np.linspace(0, 1, 11, dtype=np.float32)]
F64_EDGES = [float(x) for x in np.linspace(0, 1, 11)]


def per_bin(conf, corr):
    conf, corr = np.asarray(conf, float), np.asarray(corr, float)
    b = np.array([bin_exact(c) for c in conf])
    out = []
    for k in range(10):
        m = b == k
        if m.any():
            out.append({"bin": k, "n": int(m.sum()), "acc": float(corr[m].mean()), "conf": float(conf[m].mean())})
    return out


def boot(values, B=10000, seed=2026):
    a = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(a), size=(B, len(a)))
    means = a[idx].mean(axis=1)
    return [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]


def wilson(k, n, z=1.959964):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    w = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [c - w, c + w]


def summ(corr, conf):
    corr, conf = list(map(float, corr)), list(map(float, conf))
    acc = sum(corr) / len(corr)
    mc = sum(conf) / len(conf)
    return {"n": len(corr), "accuracy": acc, "mean_confidence": mc, "overconfidence": mc - acc,
            "ece": ece_exact(conf, corr), "ece_float32_edges": ece_float_edges(conf, corr, F32_EDGES),
            "ece_float64_edges": ece_float_edges(conf, corr, F64_EDGES),
            "accuracy_ci95": boot(corr), "wilson_ci95": wilson(sum(corr), len(corr))}


def mean(x):
    x = list(x)
    return sum(x) / len(x) if x else None


def choice_of(resp):
    a = resp["answers"]["intent"]
    probs = {k: float(v) for k, v in a["probabilities"].items()}
    ch = a["choice"]
    return ch, probs[ch], probs, a.get("confidence")


def noul_of(resp, key="is_spam"):
    p = float(resp["answers"][key]["noul"])
    return (1 if p > 0.5 else 0), max(p, 1 - p), p


# ---------------------------------------------------------------- anomaly counters (check F)
FLAGS = defaultdict(Counter)


def inspect_choice(tag, resp, options):
    a = resp["answers"]["intent"]
    probs = a["probabilities"]
    ch = a["choice"]
    F = FLAGS[tag]
    F["n"] += 1
    if ch not in options:
        F["choice_not_in_options"] += 1
    if set(probs) != set(options):
        F["prob_keys_differ_from_options"] += 1
    s = sum(probs.values())
    F[f"prob_sum_{round(s, 2):.2f}"] += 0  # placeholder to keep keys stable
    if abs(s - 1) > 0.05:
        F["prob_sum_off_by_gt_0.05"] += 1
    if abs(s - 1) > 0.015:
        F["prob_sum_off_by_gt_0.015"] += 1
    mx = max(probs.values())
    if probs.get(ch, -1) < mx - 1e-12:
        F["choice_not_argmax"] += 1
    if sum(1 for v in probs.values() if abs(v - mx) < 1e-12) > 1:
        F["argmax_tie"] += 1
    if a.get("confidence") is not None and abs(float(a["confidence"]) - float(probs.get(ch, -1))) > 1e-9:
        F["confidence_field_ne_prob_of_choice"] += 1
    if any(round(v * 100, 6) != round(v * 100) for v in probs.values()):
        F["probs_not_2_decimals"] += 1
    if probs.get(ch, 0) == 0:
        F["prob_of_choice_is_zero"] += 1
    return s


PROB_SUMS = defaultdict(list)

# ================================================================ CORE (runs/report.json)
CORE = {"tasks": {}}
all_lat, tok_in, tok_out = [], 0, 0
core_ans = {}   # (task, cond) -> idx -> (pred, conf, correct)
for task, conds in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    CORE["tasks"][task] = {}
    for c in conds:
        inp = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{c}.jsonl")}
        recs = rj(f"{ROOT}/runs/jev/{task}_{c}.jsonl")
        ok = {}
        for r in recs:
            if r["status"] == "ok":
                assert r["idx"] not in ok, "duplicate"
                ok[r["idx"]] = r
        corr, conf, own, ans = [], [], [], {}
        for i in sorted(inp):
            if i not in ok:
                continue
            resp = ok[i]["response"]
            if task == "banking77":
                s = inspect_choice(f"core_{task}_{c}", resp, CATS)
                PROB_SUMS["banking77_core"].append(s)
                pred, cf, probs, jc = choice_of(resp)
                y = float(pred == CATS[inp[i]["label"]])
                own.append(float(jc))
            else:
                pred, cf, p = noul_of(resp)
                FLAGS[f"core_{task}_{c}"]["n"] += 1
                if p == 0.5:
                    FLAGS[f"core_{task}_{c}"]["p_exactly_0.5"] += 1
                if round(p * 100, 6) != round(p * 100):
                    FLAGS[f"core_{task}_{c}"]["p_not_2_decimals"] += 1
                y = float(pred == int(inp[i]["label"]))
            corr.append(y)
            conf.append(cf)
            ans[i] = (pred, cf, y)
            all_lat.append(float(ok[i]["latency_ms"]))
            tok_in += int(resp["usage"]["input_tokens"])
            tok_out += int(resp["usage"].get("output_tokens", 0) or 0)
        core_ans[(task, c)] = ans
        m = summ(corr, conf)
        m["n_missing"] = len(inp) - len(ans)
        m["n_failed_calls"] = len({r["idx"] for r in recs} - set(ok))
        if task == "banking77":
            m["ece_using_jev_confidence_field"] = ece_exact(own, corr)
            m["ece_using_jev_confidence_field_float32_edges"] = ece_float_edges(own, corr, F32_EDGES)
        m["bins"] = per_bin(conf, corr)
        CORE["tasks"][task][c] = m
    cl = CORE["tasks"][task]["clean"]
    for c in conds[1:]:
        r = CORE["tasks"][task][c]
        r["accuracy_drop_from_clean"] = cl["accuracy"] - r["accuracy"]
        r["confidence_drop_from_clean"] = cl["mean_confidence"] - r["mean_confidence"]
s = sorted(all_lat)
n = len(s)
CORE["jev_latency_ms"] = {"n": n, "median": statistics.median(s),
                          "p90_index_rule": s[int(0.9 * n)], "p99_index_rule": s[int(0.99 * n)],
                          "p90_numpy_linear": float(np.percentile(s, 90)), "p99_numpy_linear": float(np.percentile(s, 99)),
                          "p90_nearest_rank": s[math.ceil(0.9 * n) - 1], "p99_nearest_rank": s[math.ceil(0.99 * n) - 1]}
CORE["jev_cost"] = {"input_tokens": tok_in, "usd": tok_in / 1e6 * 0.042, "output_tokens": tok_out}

# spam duplicate-text sensitivity (check F)
spam_in = rj(f"{ROOT}/runs/inputs/spam_clean.jsonl")
seen, dedup = set(), []
for r in spam_in:
    if r["text"] in seen:
        continue
    seen.add(r["text"])
    dedup.append(r["idx"])
CORE["spam_clean_dedup"] = {"n": len(dedup), "accuracy": mean(core_ans[("spam", "clean")][i][2] for i in dedup)}
# spam per-class breakdown (accuracy hides the class balance)
for c in ["clean", "swap2", "keyboard2", "mixed3"]:
    lab = {r["idx"]: r["label"] for r in rj(f"{ROOT}/runs/inputs/spam_{c}.jsonl")}
    A = core_ans[("spam", c)]
    tp = sum(1 for i, (p, _, _) in A.items() if p == 1 and lab[i] == 1)
    fn = sum(1 for i, (p, _, _) in A.items() if p == 0 and lab[i] == 1)
    fp = sum(1 for i, (p, _, _) in A.items() if p == 1 and lab[i] == 0)
    tn = sum(1 for i, (p, _, _) in A.items() if p == 0 and lab[i] == 0)
    CORE["tasks"]["spam"][c]["confusion"] = {"tp": tp, "fn": fn, "fp": fp, "tn": tn,
                                              "recall": tp / (tp + fn), "precision": tp / (tp + fp) if tp + fp else None,
                                              "majority_class_baseline_accuracy": (tn + fp) / (tp + fn + fp + tn)}

# E. a second, independent CI method for banking clean: plain-python bootstrap, different seed
bc = [core_ans[("banking77", "clean")][i][2] for i in sorted(core_ans[("banking77", "clean")])]
rnd = random.Random(12345)
ms = sorted(sum(bc[rnd.randrange(len(bc))] for _ in range(len(bc))) / len(bc) for _ in range(4000))
CORE["E_banking_clean_ci_python_bootstrap"] = [ms[int(0.025 * 4000)], ms[int(0.975 * 4000) - 1]]
CORE["E_banking_clean_ci_numpy_bootstrap"] = CORE["tasks"]["banking77"]["clean"]["accuracy_ci95"]
CORE["E_banking_clean_ci_wilson"] = CORE["tasks"]["banking77"]["clean"]["wilson_ci95"]

# ================================================================ RED TEAM
RT = {}
banking_clean = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")}
spam_clean = {r["idx"]: r for r in spam_in}
clinc_raw = json.load(open(f"{ROOT}/data/raw/clinc150_data_full.json"))
clinc_rows = [(t, l) for t, l in clinc_raw["test"]] + [(t, "oos") for t, _ in clinc_raw["oos_test"]]
clinc_opts = sorted({l for _, l in clinc_raw["train"]}) + ["oos"]
CONSIST = defaultdict(Counter)   # input-meaning consistency checks


def load_rt(name):
    items = rj(f"{ROOT}/runs/redteam/inputs/{name}.jsonl")
    recs = {}
    for r in rj(f"{ROOT}/runs/redteam/jev/{name}.jsonl"):
        if r["status"] == "ok":
            assert r["key"] not in recs
            recs[r["key"]] = r
    return items, recs


def calls_block(recs):
    lat = [float(r["latency_ms"]) for r in recs.values()]
    return {"ok": len(recs), "input_tokens": sum(int(r["response"]["usage"]["input_tokens"]) for r in recs.values()),
            "median_latency_ms": statistics.median(lat),
            "model_versions": sorted({r["response"].get("model") for r in recs.values()})}


core_bank = core_ans[("banking77", "clean")]
core_bank_probs = {r["idx"]: r["response"]["answers"]["intent"]["probabilities"]
                   for r in rj(f"{ROOT}/runs/jev/banking77_clean.jsonl") if r["status"] == "ok"}
core_spam = core_ans[("spam", "clean")]

# ---- banking injection family
INJ = ["injection_banking", "injection_prefix_banking", "injection_casual_banking",
       "injection_defended_banking", "injection_casual_defended_banking", "injection_control_banking"]
targets_by_kind = {}
for name in INJ:
    items, recs = load_rt(name)
    CC = CONSIST[name]
    rows = []
    for it in items:
        i = it["meta"]["idx"]
        src = banking_clean[i]
        CC["n"] += 1
        if it["gold"] != CATS[src["label"]]:
            CC["gold_ne_core_label"] += 1
        if src["text"] not in it["state"]:
            CC["state_lacks_original_text"] += 1
        t = it["meta"].get("target")
        if t is not None:
            if t not in CATSET:
                CC["target_not_a_category"] += 1
            if t == it["gold"]:
                CC["target_equals_gold"] += 1
            if t.replace("_", " ") not in it["state"]:
                CC["target_not_named_in_state"] += 1
        if it["key"] not in recs:
            continue
        resp = recs[it["key"]]["response"]
        inspect_choice(f"rt_{name}", resp, CATS)
        pred, cf, probs, _ = choice_of(resp)
        rows.append((it, pred, cf))
    targets_by_kind[name] = {it["key"]: it["meta"].get("target") for it in items}
    corr = [float(p == it["gold"]) for it, p, _ in rows]
    m = summ(corr, [c for _, _, c in rows])
    m["n_missing"] = len(items) - len(rows)
    m["clean_accuracy_same_examples"] = mean(core_bank[it["meta"]["idx"]][2] for it, _, _ in rows)
    if items[0]["meta"].get("target") is not None:
        fol = [(it, p, c) for it, p, c in rows if p == it["meta"]["target"]]
        m["followed_injected_label"] = len(fol) / len(rows)
        m["n_followed"] = len(fol)
        m["mean_confidence_when_following_injection"] = mean(c for _, _, c in fol)
        m["share_following_injection_with_confidence_ge_0.9"] = mean(float(c >= 0.9) for _, _, c in fol)
        m["picked_target_without_injection"] = mean(float(core_bank[it["meta"]["idx"]][0] == it["meta"]["target"])
                                                    for it, _, _ in rows)
        m["neither_gold_nor_target"] = mean(float(p != it["gold"] and p != it["meta"]["target"]) for it, p, _ in rows)
    RT[name] = {"jev": m, "jev_calls": calls_block(recs)}
# same target across kinds?
base_t = targets_by_kind["injection_banking"]
for name in ["injection_prefix_banking", "injection_casual_banking", "injection_defended_banking",
             "injection_casual_defended_banking"]:
    CONSIST[name]["target_differs_from_injection_banking"] = sum(
        1 for k, t in targets_by_kind[name].items() if base_t.get(k) != t)
CONSIST["injection_control_banking"]["keys_differ_from_injection_banking"] = len(
    set(targets_by_kind["injection_control_banking"]) ^ set(base_t))

# ---- spam family
LEET = {"o": "0", "i": "1", "e": "3", "a": "4", "s": "5"}


def norm_evasion(t):
    t = t.lower()
    return "".join(LEET.get(ch, ch) for ch in t if not ch.isspace())


for name in ["injection_spam", "evasion_spam", "ood_spam_on_banking"]:
    items, recs = load_rt(name)
    CC = CONSIST[name]
    rows = []
    for it in items:
        i = it["meta"]["idx"]
        CC["n"] += 1
        if name == "ood_spam_on_banking":
            if it["state"] != banking_clean[i]["text"]:
                CC["state_ne_banking_text"] += 1
            if it["gold"] != 0:
                CC["gold_not_0"] += 1
        else:
            src = spam_clean[i]
            if src["label"] != 1:
                CC["source_not_spam"] += 1
            if it["gold"] != 1:
                CC["gold_not_1"] += 1
            if name == "injection_spam" and not it["state"].startswith(src["text"]):
                CC["state_not_prefixed_by_original"] += 1
            if name == "evasion_spam" and norm_evasion(it["state"]) != norm_evasion(src["text"]):
                CC["evasion_not_derivable_from_original"] += 1
        if it["key"] not in recs:
            continue
        pred, cf, p = noul_of(recs[it["key"]]["response"])
        rows.append((it, pred, cf, p))
    if name != "ood_spam_on_banking":
        CONSIST[name]["n_spam_in_spam_test"] = sum(1 for r in spam_in if r["label"] == 1)
        CONSIST[name]["covers_all_spam_test_rows"] = int(
            {it["meta"]["idx"] for it in items} == {r["idx"] for r in spam_in if r["label"] == 1})
    corr = [float(p == it["gold"]) for it, p, _, _ in rows]
    m = summ(corr, [c for _, _, c, _ in rows])
    m["n_missing"] = len(items) - len(rows)
    m["mean_p_spam"] = mean(q for *_, q in rows)
    m["n_correct"] = int(sum(corr))
    if name != "ood_spam_on_banking":
        m["clean_recall_same_examples"] = mean(float(core_spam[it["meta"]["idx"]][0] == 1) for it, *_ in rows)
    else:
        m["false_alarms"] = int(sum(1 for _, p, _, _ in rows if p == 1))
    RT[name] = {"jev": m, "jev_calls": calls_block(recs)}

# ---- gibberish
items, recs = load_rt("gibberish_banking")
g = defaultdict(list)
for it in items:
    k = it["meta"]["kind"]
    if k == "scrambled_real_query":
        if sorted(it["state"]) != sorted(banking_clean[it["meta"]["idx"]]["text"]):
            CONSIST["gibberish_banking"]["scrambled_not_permutation_of_source"] += 1
    if it["key"] in recs:
        inspect_choice("rt_gibberish_banking", recs[it["key"]]["response"], CATS)
        _, cf, _, _ = choice_of(recs[it["key"]]["response"])
        g[k].append(cf)
        g["all"].append(cf)
RT["gibberish_banking"] = {"jev": {k: {"n": len(v), "mean_confidence": mean(v),
                                       "share_confidence_ge_0.9": mean(float(c >= 0.9) for c in v),
                                       "share_confidence_ge_0.5": mean(float(c >= 0.5) for c in v),
                                       "max_confidence": max(v)} for k, v in g.items()},
                           "jev_calls": calls_block(recs)}

# ---- order shuffle
items, recs = load_rt("order_shuffle_banking")
rows = []
for it in items:
    i = it["meta"]["idx"]
    if it["state"] != banking_clean[i]["text"]:
        CONSIST["order_shuffle_banking"]["state_ne_core_text"] += 1
    if it["key"] in recs:
        resp = recs[it["key"]]["response"]
        inspect_choice("rt_order_shuffle_banking", resp, CATS)
        pred, cf, probs, _ = choice_of(resp)
        rows.append((it, pred, cf, probs))
        if list(probs) == CATS:
            CONSIST["order_shuffle_banking"]["probabilities_in_original_order"] += 1
corr = [float(p == it["gold"]) for it, p, _, _ in rows]
m = summ(corr, [c for _, _, c, _ in rows])
m["n_missing"] = len(items) - len(rows)
m["clean_accuracy_same_examples"] = mean(core_bank[it["meta"]["idx"]][2] for it, *_ in rows)
m["same_answer_as_original_order"] = mean(float(p == core_bank[it["meta"]["idx"]][0]) for it, p, _, _ in rows)
m["mean_abs_change_in_p_gold"] = mean(abs(probs.get(it["gold"], 0) - float(core_bank_probs[it["meta"]["idx"]].get(it["gold"], 0)))
                                      for it, _, _, probs in rows)
RT["order_shuffle_banking"] = {"jev": m, "jev_calls": calls_block(recs)}
shuffle_keys = {it["meta"]["idx"] for it in items}

# ---- repeat
items, recs = load_rt("repeat_banking")
grp = defaultdict(list)
for it in items:
    if it["state"] != banking_clean[it["meta"]["idx"]]["text"]:
        CONSIST["repeat_banking"]["state_ne_core_text"] += 1
    if it["key"] in recs:
        resp = recs[it["key"]]["response"]
        pred, cf, probs, _ = choice_of(resp)
        grp[it["meta"]["idx"]].append((pred, cf, json.dumps(resp["answers"]["intent"]["probabilities"], sort_keys=True)))
RT["repeat_banking"] = {"jev": {
    "n_queries": len(grp), "calls": sum(map(len, grp.values())),
    "share_same_answer_all_repeats": mean(float(len({p for p, _, _ in v}) == 1) for v in grp.values()),
    "share_identical_probabilities_all_repeats": mean(float(len({s for *_, s in v}) == 1) for v in grp.values()),
    "mean_confidence_spread_max_minus_min": mean(max(c for _, c, _ in v) - min(c for _, c, _ in v) for v in grp.values()),
    # extra context: per-call agreement of a repeat with the core clean run on the same query
    "share_repeat_calls_matching_core_clean_answer": mean(float(p == core_bank[i][0]) for i, v in grp.items() for p, _, _ in v),
    "share_queries_where_some_repeat_differs_from_core_clean": mean(
        float(any(p != core_bank[i][0] for p, _, _ in v)) for i, v in grp.items()),
}, "jev_calls": calls_block(recs)}
rep_idx = set(grp)
# order-shuffle restricted to the 200 repeated queries, to compare like with like
sub = [(it, p) for it, p, _, _ in rows if it["meta"]["idx"] in rep_idx]
RT["order_shuffle_banking"]["jev"]["same_answer_on_the_200_repeat_queries"] = mean(
    float(p == core_bank[it["meta"]["idx"]][0]) for it, p in sub)
RT["order_shuffle_banking"]["jev"]["n_overlap_with_repeat_queries"] = len(sub)
# how many shuffle disagreements land on queries that were ALSO unstable under plain repeats
unstable = {i for i, v in grp.items() if len({p for p, _, _ in v}) > 1 or any(p != core_bank[i][0] for p, _, _ in v)}
RT["order_shuffle_banking"]["jev"]["n_repeat_queries_unstable_without_shuffle"] = len(unstable)

# ---- question count
items, recs = load_rt("question_count")
byn = defaultdict(list)
for it in items:
    r = recs.get(it["key"])
    if r is None:
        continue
    nq = it["meta"]["n_questions"]
    if it["qset"] != f"multi{nq}":
        CONSIST["question_count"]["qset_ne_n_questions"] += 1
    byn[nq].append(r)
qc = {}
for nq in sorted(byn):
    lat = sorted(float(r["latency_ms"]) for r in byn[nq])
    qc[str(nq)] = {"calls": len(lat), "median_latency_ms": statistics.median(lat),
                   "p90_latency_ms_index_rule": lat[int(0.9 * len(lat))],
                   "mean_input_tokens": mean(r["response"]["usage"]["input_tokens"] for r in byn[nq]),
                   "all_questions_answered": all(len(r["response"]["answers"]) == nq for r in byn[nq])}
qc["latency_ratio_16_vs_1"] = qc["16"]["median_latency_ms"] / qc["1"]["median_latency_ms"]
# paired (same message) ratio, more robust than ratio of medians
lat_by = defaultdict(dict)
for it in items:
    if it["key"] in recs:
        lat_by[it["meta"]["idx"]][it["meta"]["n_questions"]] = float(recs[it["key"]]["latency_ms"])
qc["paired_median_ratio_16_vs_1"] = statistics.median(v[16] / v[1] for v in lat_by.values())
RT["question_count"] = {"jev": qc, "jev_calls": calls_block(recs)}

# ---- amazon scores (gold check against the raw CSV by text)
import csv  # noqa: E402
amz = {}
with open(f"{ROOT}/data/raw/amazon_food_reviews.csv", encoding="utf-8", errors="replace") as f:
    for r in csv.DictReader(f):
        try:
            sc = float(r["Score"])
        except (ValueError, KeyError):
            continue
        summ_ = (r.get("Summary") or "").strip()
        txt = (r.get("Text") or "").replace("<br />", " ").strip()
        comb = f"{summ_}. {txt}" if summ_ else txt
        amz.setdefault(comb, set()).add(int(round(sc)))
clean_amz = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/score_amazon_clean.jsonl")}
for name in ["score_amazon_clean", "score_amazon_swap2"]:
    items, recs = load_rt(name)
    CC = CONSIST[name]
    rows = []
    for it in items:
        CC["n"] += 1
        src = clean_amz[it["key"]]["state"]
        if src not in amz:
            CC["clean_text_not_in_csv"] += 1
        elif it["gold"] not in amz[src]:
            CC["gold_ne_csv_score"] += 1
        if it["gold"] != clean_amz[it["key"]]["gold"]:
            CC["gold_ne_clean_gold"] += 1
        if it["key"] not in recs:
            continue
        a = recs[it["key"]]["response"]["answers"]["stars"]
        pr = [float(a["probabilities"][str(k)]) for k in range(5)]
        if abs(sum(pr) - 1) > 0.015:
            CC["prob_sum_off_gt_0.015"] += 1
        exp_raw = sum((k + 1) * p for k, p in enumerate(pr))
        exp_norm = exp_raw / sum(pr)
        am = int(np.argmax(pr)) + 1
        if sum(1 for p in pr if p == max(pr)) > 1:
            CC["argmax_tie"] += 1
        rows.append((it["gold"], exp_raw, exp_norm, am, max(pr), float(a["score"]) + 1))
    G = np.array([r[0] for r in rows], float)
    ER = np.array([r[1] for r in rows])
    EN = np.array([r[2] for r in rows])
    AM = np.array([r[3] for r in rows])
    CF = np.array([r[4] for r in rows])
    SC = np.array([r[5] for r in rows])
    ok_ = (AM == G).astype(float)
    RT[name] = {"jev": {
        "n": len(rows), "n_missing": len(items) - len(rows),
        "pearson_r_expected_stars": float(np.corrcoef(ER, G)[0, 1]),
        "pearson_r_expected_stars_normalized": float(np.corrcoef(EN, G)[0, 1]),
        "pearson_r_jev_score_field_plus1": float(np.corrcoef(SC, G)[0, 1]),
        "mae_stars_expected": float(np.mean(np.abs(ER - G))),
        "mae_stars_expected_normalized": float(np.mean(np.abs(EN - G))),
        "exact_star_accuracy_argmax": float(ok_.mean()),
        "within_one_star_argmax": float((np.abs(AM - G) <= 1).mean()),
        "ece_argmax": ece_exact(CF, ok_), "ece_argmax_float32_edges": ece_float_edges(CF, ok_, F32_EDGES),
        "baseline_always_5_exact": float((G == 5).mean()),
        "baseline_always_5_mae": float(np.mean(np.abs(5 - G))),
    }, "gold_distribution": {str(k): int((G == k).sum()) for k in range(1, 6)}, "jev_calls": calls_block(recs)}

# ---- CLINC150
clinc_clean_pred = {}
for name in ["clinc150_clean", "clinc150_swap2"]:
    items, recs = load_rt(name)
    CC = CONSIST[name]
    rows = []
    for it in items:
        i = it["meta"]["idx"]
        CC["n"] += 1
        if it["gold"] != clinc_rows[i][1]:
            CC["gold_ne_raw_json"] += 1
        if name == "clinc150_clean" and it["state"] != clinc_rows[i][0]:
            CC["state_ne_raw_json"] += 1
        if it["key"] not in recs:
            continue
        resp = recs[it["key"]]["response"]
        inspect_choice(f"rt_{name}", resp, clinc_opts)
        pred, cf, _, _ = choice_of(resp)
        rows.append((it, pred, cf))
        if name == "clinc150_clean":
            clinc_clean_pred[i] = pred
    corr = [float(p == it["gold"]) for it, p, _ in rows]
    m = summ(corr, [c for _, _, c in rows])
    ins = [(it, p) for it, p, _ in rows if it["gold"] != "oos"]
    oo = [(it, p) for it, p, _ in rows if it["gold"] == "oos"]
    m.update({"in_scope_accuracy": mean(float(p == it["gold"]) for it, p in ins),
              "oos_recall": mean(float(p == "oos") for _, p in oo),
              "false_oos_rate_on_in_scope": mean(float(p == "oos") for _, p in ins),
              "oos_precision": (sum(1 for _, p in oo if p == "oos") /
                                max(1, sum(1 for _, p, _ in rows if p == "oos"))),
              "n_in_scope": len(ins), "n_oos": len(oo), "n_missing": len(items) - len(rows)})
    RT[name] = {"jev": m, "jev_calls": calls_block(recs)}

items, recs = load_rt("injection_oos_clinc")
rows = []
for it in items:
    i = it["meta"]["idx"]
    CONSIST["injection_oos_clinc"]["n"] += 1
    if not it["state"].startswith(clinc_rows[i][0]) or i >= len(clinc_raw["test"]):
        CONSIST["injection_oos_clinc"]["state_or_idx_mismatch_vs_clinc_test"] += 1
    if it["gold"] != clinc_rows[i][1] or it["gold"] == "oos":
        CONSIST["injection_oos_clinc"]["gold_mismatch_or_oos"] += 1
    if it["key"] in recs:
        resp = recs[it["key"]]["response"]
        inspect_choice("rt_injection_oos_clinc", resp, clinc_opts)
        pred, cf, _, _ = choice_of(resp)
        rows.append((it, pred, cf))
corr = [float(p == it["gold"]) for it, p, _ in rows]
m = summ(corr, [c for _, _, c in rows])
base = [(it, clinc_clean_pred[it["meta"]["idx"]]) for it, _, _ in rows if it["meta"]["idx"] in clinc_clean_pred]
m.update({"said_oos_with_note": mean(float(p == "oos") for _, p, _ in rows),
          "said_oos_without_note_same_requests": mean(float(p == "oos") for _, p in base),
          "clean_accuracy_same_requests": mean(float(p == it["gold"]) for it, p in base),
          "n_baseline_matched": len(base), "n_missing": len(items) - len(rows)})
RT["injection_oos_clinc"] = {"jev": m, "jev_calls": calls_block(recs)}

# ---- sequential latency
items, recs = load_rt("latency_sequential_banking")
for it in items:
    if it["state"] != banking_clean[it["meta"]["idx"]]["text"]:
        CONSIST["latency_sequential_banking"]["state_ne_core_text"] += 1
lat = sorted(float(r["latency_ms"]) for r in recs.values())
RT["latency_sequential_banking"] = {"jev": {"calls": len(lat), "median_latency_ms": statistics.median(lat),
                                            "p90_latency_ms": lat[int(0.9 * len(lat))]},
                                    "jev_calls": calls_block(recs)}
# timestamps: were sequential calls actually sequential?
ts = sorted(r["ts_utc"] for r in recs.values())
RT["latency_sequential_banking"]["wall_span_s"] = None

tok = sum(v["jev_calls"]["input_tokens"] for v in RT.values())
RT_COST = {"input_tokens": tok, "usd": tok / 1e6 * 0.042,
           "output_tokens": sum(int(r["response"]["usage"].get("output_tokens", 0) or 0)
                                for name in RT for r in load_rt(name)[1].values())}

# probability-sum distribution for banking core
ps = np.array(PROB_SUMS["banking77_core"])
PSUM = {"min": float(ps.min()), "max": float(ps.max()), "mean": float(ps.mean()),
        "share_abs_dev_gt_0.01": float((np.abs(ps - 1) > 0.01 + 1e-9).mean()),
        "share_abs_dev_gt_0.05": float((np.abs(ps - 1) > 0.05).mean())}

# confidences sitting exactly on a bin edge (2-decimal quantisation)
edge_counts = {}
for (task, c), A in core_ans.items():
    confs = [cf for _, cf, _ in A.values()]
    edge_counts[f"{task}_{c}"] = {f"{e/10:.1f}": sum(1 for x in confs if abs(x - e / 10) < 1e-9) for e in range(1, 10)}
    edge_counts[f"{task}_{c}"]["distinct_conf_values"] = len({round(x, 6) for x in confs})

json.dump({"core": CORE, "redteam": RT, "redteam_cost": RT_COST, "flags": {k: dict(v) for k, v in FLAGS.items()},
           "consistency": {k: dict(v) for k, v in CONSIST.items()}, "banking_prob_sums": PSUM,
           "edge_counts": edge_counts},
          open(f"{AUD}/audit_metrics.json", "w"), indent=1, default=float)
print("ok")
