"""Check 3b: sensitivity of LLM accuracy / invalid rate to the reply-parsing policy, plus a catalogue of
invalid intents. Policies (all written here):
  greedy  : regex {.*} (DOTALL) over the whole reply, json.loads (same rule as the report, re-implemented)
  last    : last JSON object containing the key (this audit's main parser)
  first   : first JSON object containing the key
  strict  : the reply, after stripping whitespace and one optional ```json fence, must be exactly one JSON object
"""
import json, re, math
from collections import Counter, defaultdict
from common import ROOT, P2, rj, cats, mean
import check3_llm as A   # reuses this audit's item sets and parser only

CATS = cats(); CATSET = set(CATS)
DEC = json.JSONDecoder()

def objs(text):
    out = []
    for m in re.finditer(r"\{", text):
        try:
            o, e = DEC.raw_decode(text, m.start())
            if isinstance(o, dict):
                out.append((o, m.start(), e))
        except ValueError:
            pass
    return out

def pol(content, kind, policy):
    t = content or ""
    key = "p_spam" if kind == "spam" else "intent"
    o = None
    if policy == "greedy":
        m = re.search(r"\{.*\}", t, re.S)
        try:
            o = json.loads(m.group(0)) if m else None
        except Exception:
            o = None
        if not isinstance(o, dict) or key not in o:
            o = None
    elif policy in ("last", "first"):
        c = [x for x, _, _ in objs(t) if key in x]
        o = (c[-1] if policy == "last" else c[0]) if c else None
    else:
        s = t.strip()
        s = re.sub(r"^```(?:json)?\s*", "", s); s = re.sub(r"\s*```$", "", s)
        try:
            o = json.loads(s)
        except Exception:
            o = None
        if not isinstance(o, dict) or key not in o:
            o = None
    if o is None:
        return False, None
    if kind == "spam":
        p = A.num(o["p_spam"])
        return (p is not None and 0 <= p <= 1), (int(p > 0.5) if p is not None else None)
    it = o["intent"]
    if not isinstance(it, str) or it.strip() not in CATSET:
        return False, it
    return True, it.strip()

rep = json.load(open(f"{ROOT}/runs/llm_report.json"))
TAB = {}
INVALID = defaultdict(Counter)
MULTI = Counter()
for model, M in rep["models"].items():
    for test in M:
        items = A.TESTS[test](); by = {it["key"]: it for it in items}
        recs = {r["key"]: r for r in rj(f"{ROOT}/runs/llm/{model}/{test}.jsonl") if r["status"] == "ok" and r["key"] in by}
        kind = items[0]["kind"]
        row = {}
        for p in ("greedy", "last", "first", "strict"):
            res = [pol(recs[k].get("content"), kind, p) for k in recs]
            corr = [float(v and pr == by[k]["gold"]) for k, (v, pr) in zip(recs, res)]
            row[p] = {"accuracy": mean(corr), "invalid": sum(1 for v, _ in res if not v)}
        TAB[f"{model}/{test}"] = row
        for k, r in recs.items():
            c = r.get("content") or ""
            n = len([x for x, _, _ in objs(c) if ("p_spam" if kind == "spam" else "intent") in x])
            if n > 1:
                MULTI[model] += 1
            if kind != "spam":
                v, pr = pol(c, kind, "last")
                if not v and pr is not None:
                    INVALID[model][str(pr)] += 1
# label that differs from the dataset only by case
case_lab = [c for c in CATS if c != c.lower()]
out = {"policy_table": TAB, "multi_object_replies_by_model": dict(MULTI),
       "invalid_intents_by_model": {m: dict(v.most_common()) for m, v in INVALID.items()},
       "labels_with_uppercase": case_lab,
       "invalid_that_are_case_variants_of_a_label": {m: sum(n for k, n in v.items() if k.lower() in {c.lower() for c in CATS}) for m, v in INVALID.items()}}
# max spread across policies
spread = {k: round(max(v[p]["accuracy"] for p in v) - min(v[p]["accuracy"] for p in v), 4) for k, v in TAB.items()}
out["max_accuracy_spread_across_policies"] = dict(sorted(spread.items(), key=lambda kv: -kv[1])[:12])
json.dump(out, open(f"{P2}/check3b_parser_policies.json", "w"), indent=1)
print(json.dumps({k: out[k] for k in ("multi_object_replies_by_model", "labels_with_uppercase", "invalid_that_are_case_variants_of_a_label", "max_accuracy_spread_across_policies")}, indent=1))
for m, v in out["invalid_intents_by_model"].items():
    print(m, dict(list(v.items())[:12]))
for k in ["claude-opus-5.5/banking77_clean", "claude-opus-5.5/banking77_mixed3", "claude-haiku-5.5/banking77_swap2", "claude-sonnet-5.5/banking77_mixed3", "qwen3.8-flash/banking77_clean"]:
    print(k, TAB[k])
