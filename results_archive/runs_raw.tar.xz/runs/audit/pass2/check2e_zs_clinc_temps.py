"""Check 2e: zs_offshelf and zs_offshelf_bge_base CLINC150-target temperatures, refit on BANKING77 val."""
import glob, json, os, pickle
os.environ["HF_HUB_OFFLINE"] = "1"; os.environ["TRANSFORMERS_OFFLINE"] = "1"
import torch, torch.nn.functional as F
torch.set_num_threads(1)
from transformers import AutoModel, AutoTokenizer
from common import ROOT, P2, cats
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb")); C = cats()
temps = json.load(open(f"{ROOT}/runs/bema/zeroshot_temperatures.json")); out = {}
for name, path, pool in (("zs_offshelf", glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/*"))[0], "mean"),
                         ("zs_offshelf_bge_base", glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--BAAI--bge-base-en-v1.5/snapshots/*"))[0], "cls")):
    tok = AutoTokenizer.from_pretrained(path); m = AutoModel.from_pretrained(path).eval()
    def emb(t):
        o = []
        with torch.no_grad():
            for s in range(0, len(t), 128):
                x = tok(t[s:s+128], padding=True, truncation=True, max_length=64, return_tensors="pt"); h = m(**x).last_hidden_state
                if pool == "cls":
                    o.append(F.normalize(h[:, 0], dim=-1))
                else:
                    k = x["attention_mask"].unsqueeze(-1).float(); o.append(F.normalize((h * k).sum(1) / k.sum(1).clamp(min=1), dim=-1))
        return torch.cat(o)
    sims = emb([r["text"] for r in data["choice"]["val"]]) @ emb([c.replace("_", " ") for c in C]).T
    g = torch.tensor([r["label"] for r in data["choice"]["val"]]); t = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([t], lr=0.1, max_iter=200)
    def cl():
        opt.zero_grad(); l = F.cross_entropy(sims * t.exp(), g); l.backward(); return l
    opt.step(cl)
    out[name] = {"reported": temps[name]["clinc"]["temperature"], "refit_on_banking_val": float(t.exp().detach())}
json.dump(out, open(f"{P2}/check2e_zs_clinc_temps.json", "w"), indent=1); print(json.dumps(out))
