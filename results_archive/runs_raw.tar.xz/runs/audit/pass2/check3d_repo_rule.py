"""Check 3d: rerun this audit's LLM metric code (check3_llm.main) with the report's parsing RULE re-implemented
(greedy {.*} regex + json.loads, intent must be one of the 77 labels), to separate parser policy from arithmetic."""
import json, re
import check3_llm as A
from common import P2, cats
CATSET = set(cats())
def repo_rule(content, kind):
    m = re.search(r"\{.*\}", content or "", re.S)
    try:
        j = json.loads(m.group(0)) if m else None
    except Exception:
        j = None
    if kind == "spam":
        try:
            p = float(j["p_spam"])
            ok = 0 <= p <= 1
            return {"valid": ok, "pred": int(p > 0.5), "conf": max(p, 1 - p), "reason": "ok" if ok else "range"}
        except Exception:
            return {"valid": False, "pred": None, "conf": None, "reason": "unparseable"}
    try:
        it = str(j["intent"]).strip()
    except Exception:
        return {"valid": False, "pred": None, "conf": None, "reason": "unparseable"}
    try:
        c = float(j["confidence"])
    except Exception:
        c = None
    return {"valid": it in CATSET, "pred": it, "conf": c if it in CATSET else None, "reason": "ok" if it in CATSET else "not a label"}
A.my_parse = repo_rule
A.P2 = f"{P2}/repo_rule"
A.main()
