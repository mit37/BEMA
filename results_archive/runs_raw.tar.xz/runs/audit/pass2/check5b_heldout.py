"""Check 5b: paired model-minus-Jev differences on the held-out typo types (not used in any BEMA training)."""
import json
from common import P2, mean, boot
import check4_summary as S4
out = {}
for c in ["keyboard2", "delete2", "insert2", "mixed3"]:
    j = S4.jev_core("banking77", c)
    for m in ["bema_v2", "bema_v2_spell", "bema_baseline"]:
        d = S4.bema_core(m, "banking77", c)
        diff = [d[k][0] - j[k][0] for k in sorted(d)]
        out[f"{m} {c}"] = {"model_minus_jev_pp": round(100 * mean(diff), 2), "ci95_pp": [round(100 * x, 2) for x in boot(diff, seed=11)]}
j = S4.jev_core("banking77", "mixed3")
for m in ["claude-opus-5.5", "claude-sonnet-5.5", "claude-haiku-5.5", "qwen3.8-flash"]:
    d = S4.llm(m, "banking77_mixed3", S4.own)
    diff = [d[k][0] - j[k][0] for k in sorted(d)]
    out[f"{m} mixed3"] = {"model_minus_jev_pp": round(100 * mean(diff), 2), "ci95_pp": [round(100 * x, 2) for x in boot(diff, seed=11)]}
json.dump(out, open(f"{P2}/check5b_heldout.json", "w"), indent=1)
for k, v in out.items(): print(k, v)
