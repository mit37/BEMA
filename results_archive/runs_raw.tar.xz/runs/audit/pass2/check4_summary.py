"""Check 4: recompute runs/results_summary.json (sections banking77_typos, spam, slice250_all_models,
injection; plus speed_cost, spend and the copied redteam_other block) from raw files with this audit's code.
LLM replies are scored twice: with this audit's parser ('own') and with a re-implementation of the
report's greedy-regex rule ('repo rule'), so arithmetic errors and parser-policy differences separate."""
import glob
import json
import re
import statistics

from common import ROOT, P2, Cmp, cats, ece, mean, rj, sample_idx, slice250
import check3_llm as A   # this audit's item sets and parser

CATS = cats()
CATSET = set(CATS)
S = json.load(open(f"{ROOT}/runs/results_summary.json"))
C = Cmp()
NOTE = {}
K250 = slice250()


def repo_rule(content, kind):
    m = re.search(r"\{.*\}", content or "", re.S)
    try:
        j = json.loads(m.group(0)) if m else None
    except Exception:
        j = None
    if kind == "spam":
        try:
            p = float(j["p_spam"])
            return {"valid": 0 <= p <= 1, "pred": int(p > 0.5), "conf": max(p, 1 - p)}
        except Exception:
            return {"valid": False, "pred": None, "conf": None}
    try:
        it = str(j["intent"]).strip()
    except Exception:
        return {"valid": False, "pred": None, "conf": None}
    try:
        c = float(j["confidence"])
    except Exception:
        c = None
    return {"valid": it in CATSET, "pred": it, "conf": c}


# ---------------------------------------------------------------- loaders: key -> (correct, conf or None, pred or None)
def jev_core(task, cond):
    I = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{cond}.jsonl")}
    out = {}
    for r in rj(f"{ROOT}/runs/jev/{task}_{cond}.jsonl"):
        if r["status"] != "ok":
            continue
        a = r["response"]["answers"]
        if task == "banking77":
            p = a["intent"]["choice"]
            out[str(r["idx"])] = (float(p == CATS[I[r["idx"]]["label"]]), float(a["intent"]["probabilities"][p]), p)
        else:
            q = a["is_spam"]["noul"]
            p = int(q > 0.5)
            out[str(r["idx"])] = (float(p == I[r["idx"]]["label"]), max(q, 1 - q), p)
    return out


def bema_core(m, task, cond):
    I = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{cond}.jsonl")}
    out = {}
    for r in rj(f"{ROOT}/runs/bema/{m}_{task}_{cond}.jsonl"):
        g = CATS[I[r["idx"]]["label"]] if task == "banking77" else I[r["idx"]]["label"]
        p = CATS[r["pred"]] if task == "banking77" else r["pred"]
        out[str(r["idx"])] = (float(p == g), float(r["conf"]), p)
    return out


def llm(m, test, parser):
    items = {it["key"]: it for it in A.TESTS[test]()}
    out = {}
    for r in rj(f"{ROOT}/runs/llm/{m}/{test}.jsonl"):
        if r["status"] != "ok" or r["key"] not in items:
            continue
        it = items[r["key"]]
        P = parser(r.get("content"), it["kind"])
        out[r["key"]] = (float(P["valid"] and P["pred"] == it["gold"]), P["conf"] if P["valid"] else None,
                         P["pred"] if P["valid"] else None)
    return out


def own(content, kind):
    return A.my_parse(content, kind)


def rt_jev(test):
    items = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/{test}.jsonl")}
    out = {}
    for r in rj(f"{ROOT}/runs/redteam/jev/{test}.jsonl"):
        if r["status"] == "ok":
            a = r["response"]["answers"]["intent"]
            p = a["choice"]
            out[r["key"]] = (float(p == items[r["key"]]["gold"]), float(a["probabilities"][p]), p)
    return out, items


def rt_bema(test, m):
    items = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/{test}.jsonl")}
    return {r["key"]: (float(r["pred"] == items[r["key"]]["gold"]), float(r["conf"]), r["pred"])
            for r in rj(f"{ROOT}/runs/redteam/bema/{test}__{m}.jsonl")}


def acc(d):
    return mean(v[0] for v in d.values())


def ece_d(d):
    pr = [(v[1], v[0]) for v in d.values() if v[1] is not None]
    return ece([c for c, _ in pr], [a for _, a in pr]) if pr else None


def pct(x):
    return None if x is None else round(100 * x, 1)


def cmp_row(sec, label, m, rep, d, items=None, with_ece=True, with_mc=False):
    C.add(sec, f"{label}/{m} n", rep["n"], len(d))
    C.add(sec, f"{label}/{m} accuracy_pct", rep["accuracy_pct"], pct(acc(d)), 1e-9)
    if with_ece and "ece" in rep:
        e = ece_d(d)
        C.add(sec, f"{label}/{m} ece (4 dp)", rep["ece"], round(e, 4) if e is not None else None, 1e-9)
    if with_mc and "mean_confidence" in rep:
        C.add(sec, f"{label}/{m} mean_confidence (3 dp)", rep["mean_confidence"],
              round(statistics.mean(v[1] for v in d.values() if v[1] is not None), 3), 1e-9)
    if items is not None and "followed_injection_pct" in rep:
        C.add(sec, f"{label}/{m} followed_injection_pct", rep["followed_injection_pct"],
              pct(mean(float(v[2] == items[k]["meta"]["target"]) for k, v in d.items())), 1e-9)


LLM = {"claude-haiku-5.5", "qwen3.8-flash", "gpt-6-luna", "gpt-6.1-terra", "claude-sonnet-5.5", "claude-opus-5.5", "claude-fable-5.1"}
POLICY_DIFF = []

# ---------------------------------------------------------------- 1. banking77_typos and 2. spam
for secname, task in (("banking77_typos", "banking77"), ("spam", "spam")):
    for cond, row in S["sections"][secname]["rows"].items():
        for m, rp in row.items():
            if m == "jev":
                d = jev_core(task, cond)
            elif m in LLM:
                d = llm(m, f"{task}_{cond}", own)
                d2 = llm(m, f"{task}_{cond}", repo_rule)
                if pct(acc(d)) != pct(acc(d2)) or (ece_d(d) is not None and round(ece_d(d), 4) != round(ece_d(d2), 4)):
                    POLICY_DIFF.append({"section": secname, "row": f"{cond}/{m}", "own_parser": [pct(acc(d)), round(ece_d(d), 4)],
                                        "repo_rule": [pct(acc(d2)), round(ece_d(d2), 4)], "reported": [rp["accuracy_pct"], rp.get("ece")]})
            else:
                d = bema_core(m, task, cond)
            cmp_row(secname, cond, m, rp, d)
C.add("spam", "majority_baseline_pct", S["sections"]["spam"]["majority_baseline_pct"],
      pct(1 - mean(r["label"] for r in rj(f"{ROOT}/runs/inputs/spam_clean.jsonl"))))

# which models with raw files are missing from the summary sections?
miss = {}
for secname, task, conds in (("banking77_typos", "banking77", ["clean", "swap2", "mixed3"]), ("spam", "spam", ["clean", "swap2"])):
    for cond in conds:
        have = set(S["sections"][secname]["rows"][cond])
        avail = {p.split("/")[-2] for p in glob.glob(f"{ROOT}/runs/llm/*/{task}_{cond}.jsonl")}
        avail |= {p.split("/")[-1][: -len(f"_{task}_{cond}.jsonl")] for p in glob.glob(f"{ROOT}/runs/bema/*_{task}_{cond}.jsonl")}
        miss[f"{secname}/{cond}"] = sorted(avail - have)
NOTE["models_with_raw_files_missing_from_summary"] = miss

# ---------------------------------------------------------------- 3. slice250
sec = S["sections"]["slice250_all_models"]
C.add("slice250", "n_keys", sec["n_keys"], len(K250))
tests = {"clean": ("banking77", "clean"), "swap2": ("banking77", "swap2"), "injection_explicit": "injection_banking",
         "injection_control": "injection_control_banking", "injection_casual": "injection_casual_banking",
         "injection_casual_defended": "injection_casual_defended_banking"}
keysets = {}
for label, row in sec["rows"].items():
    t = tests[label]
    items = None if isinstance(t, tuple) else {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/{t}.jsonl")}
    for m, rp in row.items():
        if isinstance(t, tuple):
            if m == "jev":
                d = jev_core(*t)
            elif m in ("gpt-6-luna", "gpt-6.1-terra", "claude-fable-5.1"):
                d = llm(m, f"banking77_{t[1]}_s250", own)
            elif m in LLM:
                d = llm(m, f"banking77_{t[1]}", own)
            else:
                d = bema_core(m, *t)
        else:
            if m == "jev":
                d, _ = rt_jev(t)
            elif m in ("gpt-6-luna", "gpt-6.1-terra", "claude-fable-5.1"):
                d = llm(m, f"{t}_s250", own)
            elif m in LLM:
                d = llm(m, t, own)
            else:
                d = rt_bema(t, m)   # the TRUE file for this test (may be the defended one)
                own_file = t
                d_undef = rt_bema(t.replace("_defended", ""), m)
                NOTE.setdefault("slice250_bema_defended_vs_undefended_identical", {})[f"{label}/{m}"] = all(
                    d[k][2] == d_undef[k][2] for k in d)
        sub = {k: v for k, v in d.items() if k in K250}
        keysets[f"{label}/{m}"] = sorted(sub)
        cmp_row("slice250", label, m, rp, sub, items, with_ece=False)
first = next(iter(keysets.values()))
NOTE["slice250_every_row_uses_identical_keys"] = all(v == first for v in keysets.values()) and set(first) == K250
NOTE["slice250_rows_with_different_keys"] = [k for k, v in keysets.items() if v != first]
NOTE["slice250_section_mentions_bema_defended_reuse"] = any("defended" in str(v).lower() and "bema" in str(v).lower()
                                                              for k, v in sec.items() if k != "rows")
NOTE["slice250_models_missing"] = sorted({"claude-sonnet-5.5", "claude-opus-5.5", "claude-fable-5.1"} - set(sec["rows"]["clean"]))

# ---------------------------------------------------------------- 4. injection (1,000)
sec = S["sections"]["injection"]
labs = {"explicit_note_end": "injection_banking", "explicit_note_start": "injection_prefix_banking",
        "casual_ps": "injection_casual_banking", "neutral_note_control": "injection_control_banking",
        "explicit_note_defended": "injection_defended_banking", "casual_ps_defended": "injection_casual_defended_banking"}
for label, row in sec["rows"].items():
    t = labs[label]
    items = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/{t}.jsonl")}
    for m, rp in row.items():
        if m == "jev":
            d, _ = rt_jev(t)
        elif m in LLM:
            d = llm(m, t, own)
        else:
            d = rt_bema(t, m)
            NOTE.setdefault("injection_bema_defended_uses_undefended_file", {})[f"{label}/{m}"] = (
                "defended" in t and all(d[k][2] == rt_bema(t.replace("_defended", ""), m)[k][2] for k in d))
        cmp_row("injection", label, m, rp, d, items, with_ece=False, with_mc=True)
inj_keys = {it["key"] for it in rj(f"{ROOT}/runs/redteam/inputs/injection_banking.jsonl")}
for m, v in sec["clean_reference"].items():
    d = jev_core("banking77", "clean") if m == "jev" else bema_core(m, "banking77", "clean")
    C.add("injection", f"clean_reference/{m}", v, pct(acc({k: x for k, x in d.items() if k in inj_keys})))
NOTE["injection_note"] = sec.get("note")
NOTE["injection_models_missing"] = sorted({"claude-sonnet-5.5", "claude-opus-5.5"} - set(sec["rows"]["explicit_note_end"]))
# defended states identical to undefended states?
for a, b in (("injection_banking", "injection_defended_banking"), ("injection_casual_banking", "injection_casual_defended_banking")):
    A1 = {it["key"]: it["state_sha256"] for it in rj(f"{ROOT}/runs/redteam/inputs/{a}.jsonl")}
    B1 = {it["key"]: it["state_sha256"] for it in rj(f"{ROOT}/runs/redteam/inputs/{b}.jsonl")}
    NOTE[f"state text identical: {a} vs {b}"] = A1 == B1

# ---------------------------------------------------------------- speed_cost and spend
sp = S["sections"]["speed_cost"]["rows"]
lat_core = sorted(float(r["latency_ms"]) for t, cs in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                                                     ("spam", ["clean", "swap2", "keyboard2", "mixed3"]))
                  for c in cs for r in rj(f"{ROOT}/runs/jev/{t}_{c}.jsonl"))
C.add("speed_cost", "jev median_ms_concurrent_core_run", sp["jev"]["median_ms_concurrent_core_run"], statistics.median(lat_core))
C.add("speed_cost", "jev median_ms_one_at_a_time", sp["jev"]["median_ms_one_at_a_time"],
      statistics.median(float(r["latency_ms"]) for r in rj(f"{ROOT}/runs/redteam/jev/latency_sequential_banking.jsonl")))
for task, k in (("banking77", "usd_per_1000_banking_decisions"), ("spam", "usd_per_1000_spam_decisions")):
    toks = [r["response"]["usage"]["input_tokens"] for r in rj(f"{ROOT}/runs/jev/{task}_clean.jsonl")]
    C.add("speed_cost", f"jev {k}", sp["jev"][k], round(1000 * mean(toks) * 0.042 / 1e6, 4))
for m, v in sp.items():
    if m == "jev" or m.startswith("_"):
        continue
    ls = rj(f"{ROOT}/runs/llm/{m}/latency_sequential.jsonl")
    C.add("speed_cost", f"{m} median_ms_one_at_a_time", v["median_ms_one_at_a_time"],
          statistics.median(float(r["latency_ms"]) for r in ls if r["status"] == "ok"))
    for kind, k in (("banking", "usd_per_1000_banking_decisions"), ("spam", "usd_per_1000_spam_decisions")):
        cands = ([f"banking77_clean", "banking77_clean_s250"] if kind == "banking" else ["spam_clean"])
        p = next((f"{ROOT}/runs/llm/{m}/{c}.jsonl" for c in cands if glob.os.path.exists(f"{ROOT}/runs/llm/{m}/{c}.jsonl")), None)
        val = None
        if p:
            items = {it["key"] for it in A.TESTS[p.split("/")[-1][:-6]]()}
            rs = [r for r in rj(p) if r["status"] == "ok" and r["key"] in items]
            val = round(1000 * sum(float(r["usage"]["cost"]) for r in rs) / len(rs), 4)
        C.add("speed_cost", f"{m} {k}", v[k], val)
# Jev spend: every ok Jev record (core + red team) priced at $0.042/M input
tok = 0
for p in glob.glob(f"{ROOT}/runs/jev/*.jsonl") + glob.glob(f"{ROOT}/runs/redteam/jev/*.jsonl"):
    tok += sum(r["response"]["usage"]["input_tokens"] for r in rj(p) if r["status"] == "ok")
C.add("spend", "jev_usd_estimate", S["spend"].get("jev_usd_estimate", S["spend"].get("jev_usd_estimate_from_tokens")),
      round(tok / 1e6 * 0.042, 3))
orr = ant = 0.0
for p in glob.glob(f"{ROOT}/runs/llm/*/*.jsonl"):
    for r in rj(p):
        if r["status"] == "ok":
            if "/" in r["model"]:
                orr += float(r["usage"]["cost"])
            else:
                ant += float(r["usage"]["cost"])
key = "openrouter_usd_reported" if "openrouter_usd_reported" in S["spend"] else "openrouter_usd_reported_by_openrouter"
C.add("spend", f"{key} (label says OpenRouter; compared with OpenRouter-only spend)", S["spend"][key], round(orr, 3))
NOTE["spend_breakdown"] = {"openrouter_reported_cost": orr, "anthropic_tokens_x_list_price": ant, "sum": orr + ant,
                           "jev_tokens": tok}
NOTE["results_summary_spend_keys"] = sorted(S["spend"])

# ---------------------------------------------------------------- redteam_other: copied block vs current redteam_report.json
rr = json.load(open(f"{ROOT}/runs/redteam_report.json"))["tests"]
diff = [k for k, v in S["sections"]["redteam_other"].items() if k in rr and json.dumps(v, sort_keys=True) != json.dumps(rr[k], sort_keys=True)]
NOTE["redteam_other_blocks_differing_from_current_redteam_report"] = diff
C.add("redteam_other", "copied blocks equal current runs/redteam_report.json", True, not diff)

# ---------------------------------------------------------------- staleness: file vs generating script
NOTE["generated_utc"] = S["generated_utc"]
json.dump({"rows": C.rows, "notes": NOTE, "parser_policy_differences": POLICY_DIFF}, open(f"{P2}/check4_summary.json", "w"), indent=1, default=str)
fails = [r for r in C.rows if r["result"] == "FAIL"]
print(f"{len(C.rows)} rows, {len(fails)} FAIL")
for r in fails:
    print(r["section"], "|", r["metric"], "|", r["reported"], "|", r["ours"])
print(json.dumps(NOTE, indent=1)[:5000])
print("policy diffs", POLICY_DIFF)
