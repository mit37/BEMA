"""Check 2: leakage. Static facts from the code are written up by hand in AUDIT_PASS2.md; this script
measures the data-level facts: train/val/test text overlap, the spell dictionaries' test exposure,
and whether the CLINC150 'zero-shot' source shares intents with BANKING77."""
import json
import os
import pickle
import re
from collections import Counter

from common import ROOT, P2, rj

d = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
OUT = {}


def norm(t):
    return re.sub(r"\s+", " ", t.strip().lower())


for head in ("choice", "noul", "score"):
    tr = {norm(r["text"]) for r in d[head]["train"]}
    va = {norm(r["text"]) for r in d[head]["val"]}
    te = [norm(r["text"]) for r in d[head]["test"]]
    OUT[f"{head}: test rows whose text (case/space-normalised) also appears in TRAIN"] = sum(1 for t in te if t in tr)
    OUT[f"{head}: test rows whose text also appears in VAL"] = sum(1 for t in te if t in va)
    OUT[f"{head}: n test"] = len(te)
# the frozen benchmark inputs are exactly the prepared test split?
OUT["banking77_clean inputs == prepared choice test (text, label, order)"] = [
    (r["text"], r["label"]) for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")] == [
    (r["text"], int(r["label"])) for r in d["choice"]["test"]]
OUT["spam_clean inputs == prepared noul test"] = [(r["text"], r["label"]) for r in rj(f"{ROOT}/runs/inputs/spam_clean.jsonl")] == [
    (r["text"], int(r["label"])) for r in d["noul"]["test"]]

# spam overlap detail: accuracy of BEMA on overlapping vs non-overlapping test messages
tr_sp = {norm(r["text"]) for r in d["noul"]["train"]}
sp = rj(f"{ROOT}/runs/inputs/spam_clean.jsonl")
ov = {r["idx"] for r in sp if norm(r["text"]) in tr_sp}
for m in ("bema_baseline", "bema_v2"):
    P = {r["idx"]: r for r in rj(f"{ROOT}/runs/bema/{m}_spam_clean.jsonl")}
    a_ov = [float(P[r["idx"]]["pred"] == r["label"]) for r in sp if r["idx"] in ov]
    a_no = [float(P[r["idx"]]["pred"] == r["label"]) for r in sp if r["idx"] not in ov]
    OUT[f"{m} spam/clean accuracy on train-overlapping vs unseen test messages"] = {
        "overlap_n": len(a_ov), "overlap_acc": sum(a_ov) / len(a_ov), "unseen_n": len(a_no), "unseen_acc": sum(a_no) / len(a_no)}
J = {r["idx"]: r for r in rj(f"{ROOT}/runs/jev/spam_clean.jsonl")}
a_ov = [float((J[r["idx"]]["response"]["answers"]["is_spam"]["noul"] > 0.5) == bool(r["label"])) for r in sp if r["idx"] in ov]
a_no = [float((J[r["idx"]]["response"]["answers"]["is_spam"]["noul"] > 0.5) == bool(r["label"])) for r in sp if r["idx"] not in ov]
OUT["jev spam/clean accuracy on the same split"] = {"overlap_acc": sum(a_ov) / len(a_ov), "unseen_acc": sum(a_no) / len(a_no)}
OUT["spam overlap: share spam among overlapping test rows"] = sum(r["label"] for r in sp if r["idx"] in ov) / max(1, len(ov))

# BANKING77: any typo'd test text present verbatim in train (should be ~0)
tr_b = {norm(r["text"]) for r in d["choice"]["train"]}
OUT["banking clean test texts present in BANKING77 train"] = sum(1 for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl") if norm(r["text"]) in tr_b)

# spell dictionary: words that occur ONLY in test text (would reveal test use if the domain dictionary contained them)
def words(rows):
    c = Counter()
    for r in rows:
        c.update(w.lower() for w in re.findall(r"[A-Za-z]+", r["text"]))
    return c


for head, task in (("choice", "banking77"), ("noul", "spam")):
    trw = words(d[head]["train"])
    dom = {w for w, c in trw.items() if c >= 2}
    tew = words(rj(f"{ROOT}/runs/inputs/{task}_clean.jsonl"))
    test_only = {w for w in tew if w not in trw}
    OUT[f"{task}: clean-test-only words (not in train)"] = len(test_only)
    OUT[f"{task}: of those, in the train-built domain dictionary"] = len(test_only & dom)
    # corrections the speller made that map a typo to a word seen ONLY in test (would be impossible without test text,
    # unless the bundled English dictionary has the word)
    eng = set()
    import symspellpy
    with open(os.path.join(os.path.dirname(symspellpy.__file__), "frequency_dictionary_en_82_765.txt")) as f:
        for line in f:
            eng.add(line.split()[0])
    outs = Counter()
    for c in (["swap2", "mixed3"] if task == "spam" else ["swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]):
        for r in rj(f"{ROOT}/runs/bema/spell_texts/{task}_{c}.jsonl"):
            ow = re.findall(r"[A-Za-z]+", r["original"])
            cw = re.findall(r"[A-Za-z]+", r["corrected"])
            for a, b in zip(ow, cw):
                if a != b:
                    bl = b.lower()
                    if bl not in dom and bl not in eng:
                        outs["corrected_to_word_in_neither_dictionary"] += 1
                    elif bl in test_only and bl not in eng:
                        outs["corrected_to_test_only_word_not_in_english_dict"] += 1
                    else:
                        outs["corrected_to_dictionary_word"] += 1
    OUT[f"{task}: speller output words by dictionary"] = dict(outs)

# CLINC150 vs BANKING77 intent overlap (relevant to the 'zero-shot transfer' framing)
raw = json.load(open(f"{ROOT}/data/raw/clinc150_data_full.json"))
cl = sorted({l for _, l in raw["train"]})
bk = json.load(open(f"{ROOT}/runs/inputs/categories.json"))
OUT["clinc150 intents with an identical BANKING77 name"] = sorted(set(cl) & set(bk))
OUT["clinc150 banking-domain intents (name contains card/pin/transfer/balance/exchange/account/transaction)"] = [
    x for x in cl if re.search(r"card|pin_|transfer|balance|exchange|account|transaction|routing|direct_deposit|freeze", x)]
# CLINC test text in CLINC train?
ctr = {norm(t) for t, _ in raw["train"]} | {norm(t) for t, _ in raw["oos_train"]}
OUT["clinc150 test rows whose text appears in clinc150 train"] = sum(
    1 for t, _ in raw["test"] + raw["oos_test"] if norm(t) in ctr)
OUT["clinc150 n test"] = len(raw["test"]) + len(raw["oos_test"])
# CLINC val vs BANKING test overlap (temperature of zs models fit on CLINC val)
bt = {norm(r["text"]) for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")}
OUT["clinc150 val texts that are BANKING77 test texts"] = sum(1 for t, _ in raw["val"] + raw["oos_val"] if norm(t) in bt)
OUT["banking val (from BANKING77 train) texts that are clinc150 test texts"] = sum(
    1 for r in d["choice"]["val"] if norm(r["text"]) in {norm(t) for t, _ in raw["test"] + raw["oos_test"]})

json.dump(OUT, open(f"{P2}/check2_leakage.json", "w"), indent=1)
print(json.dumps(OUT, indent=1))
