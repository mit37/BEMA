"""Regression check of pass-1 fixes in the regenerated reports: Jev ECE (exact edges) and Wilson CIs vs pass-1 values."""
import json
from common import ROOT, P2, Cmp, wilson
m = json.load(open(f"{ROOT}/runs/audit/audit_metrics.json"))
rep = json.load(open(f"{ROOT}/runs/report.json")); rr = json.load(open(f"{ROOT}/runs/redteam_report.json"))
C = Cmp()
for t, cs in m["core"]["tasks"].items():
    for c, v in cs.items():
        R = rep["tasks"][t][c]["jev"]
        C.add(f"core {t}/{c}", "jev ece (exact)", R["ece"], v["ece"], 1e-9)
        C.add(f"core {t}/{c}", "jev accuracy_ci95 (Wilson)", R["accuracy_ci95"], wilson(round(v["accuracy"] * v["n"]), v["n"]), 1e-9)
        C.add(f"core {t}/{c}", "ci_method", R.get("ci_method"), "Wilson score")
for t, v in m["redteam"].items():
    J = rr["tests"][t]["jev"]
    if "ece" in v["jev"] and "ece" in J:
        C.add(f"redteam {t}", "jev ece (exact)", J["ece"], v["jev"]["ece"], 1e-9)
    if "ece_argmax" in v["jev"]:
        C.add(f"redteam {t}", "jev ece_argmax (exact)", J["ece_argmax"], v["jev"]["ece_argmax"], 1e-9)
    if "accuracy" in v["jev"] and "accuracy_ci95" in J:
        C.add(f"redteam {t}", "jev accuracy_ci95 (Wilson)", J["accuracy_ci95"], wilson(round(v["jev"]["accuracy"] * v["jev"]["n"]), v["jev"]["n"]), 1e-9)
sp = rep["tasks"]["spam"]["clean"]["jev"]
C.add("core spam/clean", "jev spam_precision", sp["spam_precision"], 115 / 147)
C.add("core spam/clean", "jev false_alarms_on_ham", sp["false_alarms_on_ham"], 32)
json.dump(C.rows, open(f"{P2}/check0_jev_regression.json", "w"), indent=1)
f = [r for r in C.rows if r["result"] == "FAIL"]
print(len(C.rows), "rows", len(f), "FAIL"); [print(r) for r in f]
