"""Shared helpers for audit pass 2 (written from scratch; no repo modules imported)."""
import hashlib
import json
import math
import random
from decimal import Decimal, ROUND_CEILING

import numpy as np

ROOT = "/home/claude/mit37/bema"
P2 = f"{ROOT}/runs/audit/pass2"


def rj(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def sha(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()


def cats():
    return json.load(open(f"{ROOT}/runs/inputs/categories.json"))


def bin_of(c, n_bins=10):
    """Exact decimal bin of the printed value: bin 0 = [0, 0.1], bin k = (k/10, (k+1)/10]."""
    d = Decimal(repr(float(c))) * n_bins
    k = int(d.to_integral_value(rounding=ROUND_CEILING)) - 1
    return min(n_bins - 1, max(0, k))


def ece(conf, corr):
    conf = [float(c) for c in conf]
    corr = [float(a) for a in corr]
    n = len(conf)
    bins = {}
    for c, a in zip(conf, corr):
        bins.setdefault(bin_of(c), []).append((c, a))
    return float(sum(len(b) / n * abs(sum(a for _, a in b) / len(b) - sum(c for c, _ in b) / len(b))
                     for b in bins.values()))


F32 = [float(x) for x in np.linspace(0, 1, 11, dtype=np.float32)]


def ece_f32(conf, corr):
    conf, corr = np.asarray(conf, float), np.asarray(corr, float)
    tot = 0.0
    for k in range(10):
        m = (conf > F32[k]) & (conf <= F32[k + 1])
        if k == 0:
            m |= conf == F32[0]
        if m.any():
            tot += m.mean() * abs(corr[m].mean() - conf[m].mean())
    return float(tot)


def wilson(k, n, z=1.959963984540054):
    if n == 0:
        return [None, None]
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [max(0.0, c - h), min(1.0, c + h)]


def boot(values, B=4000, seed=97):
    a = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    m = a[rng.integers(0, len(a), size=(B, len(a)))].mean(1)
    return [float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))]


def mean(xs):
    xs = list(xs)
    return sum(xs) / len(xs) if xs else None


def pearson(x, y):
    return float(np.corrcoef(np.asarray(x, float), np.asarray(y, float))[0, 1])


def summ(corr, conf):
    corr = [float(c) for c in corr]
    conf = [float(c) for c in conf]
    acc = sum(corr) / len(corr)
    mc = sum(conf) / len(conf)
    return {"n": len(corr), "accuracy": acc, "accuracy_ci95": wilson(sum(corr), len(corr)),
            "mean_confidence": mc, "overconfidence": mc - acc, "ece": ece(conf, corr),
            "ece_repo_float32_edges": ece_f32(conf, corr)}


# The 1,000-query red-team sample and the 250-key slice, re-derived independently from the
# documented seeds (redteam_jev.sample_idx: Random(7).sample(range(3080), 1000), sorted;
# llm_baseline.subsample_keys: Random(11).sample(that list, 250)).
def sample_idx():
    return sorted(random.Random(7).sample(range(3080), 1000))


def slice250():
    return {str(i) for i in random.Random(11).sample(sample_idx(), 250)}


class Cmp:
    """Collects reported-vs-recomputed rows."""

    def __init__(self):
        self.rows = []

    def add(self, section, metric, reported, ours, tol=1e-9, note=""):
        if isinstance(reported, (list, tuple)):
            ok = reported is not None and ours is not None and len(reported) == len(ours) and all(
                (a is None and b is None) or (a is not None and b is not None and abs(a - b) <= tol)
                for a, b in zip(reported, ours))
        elif isinstance(reported, (bool, str)) or reported is None:
            ok = reported == ours
        else:
            ok = ours is not None and abs(float(reported) - float(ours)) <= tol
        self.rows.append({"section": section, "metric": metric, "reported": reported, "ours": ours,
                          "tol": tol, "result": "PASS" if ok else "FAIL", "note": note})
        return ok
