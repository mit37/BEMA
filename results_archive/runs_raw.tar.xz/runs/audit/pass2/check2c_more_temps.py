"""Check 2c: bema_clinc150 temperature with the repo's recipe (init 1.5, LBFGS lr 0.01, 200 iters) on val vs
test; zs_from_banking CLINC temperature refit on BANKING77 val (as zeroshot_temperatures.json claims)."""
import json, os, pickle, sys
os.environ["HF_HUB_OFFLINE"] = "1"; os.environ["TRANSFORMERS_OFFLINE"] = "1"
import torch, torch.nn as nn, torch.nn.functional as F
torch.set_num_threads(1)
from common import ROOT, P2, cats
sys.path.insert(0, ROOT)
from model import JevCloneEncoder
from transformers import AutoModel, AutoTokenizer
out = {}
cd = pickle.load(open(f"{ROOT}/data/prepared_clinc150.pkl", "rb"))
m = JevCloneEncoder(vocab_size=cd["vocab_size"], d_model=96, nhead=6, num_layers=3, max_len=cd["max_len"], num_choice_classes=cd["num_classes"])
sd = torch.load(f"{ROOT}/jev_clone_clinc150.pt", map_location="cpu"); m.load_state_dict(sd); m.eval()
def lg(rows):
    with torch.no_grad():
        return torch.cat([m.choice_head(m.encode(torch.tensor([r["ids"] for r in rows[s:s+64]]), torch.tensor([r["mask"] for r in rows[s:s+64]]))) for s in range(0, len(rows), 64)])
def repo_fit(l, y):
    T = nn.Parameter(torch.ones(1) * 1.5); opt = torch.optim.LBFGS([T], lr=0.01, max_iter=200); ce = nn.CrossEntropyLoss()
    def cl():
        opt.zero_grad(); x = ce(l / T, y); x.backward(); return x
    opt.step(cl); return T.item()
cal = torch.load(f"{ROOT}/jev_clone_clinc150_calibrated.pt", map_location="cpu")
out["bema_clinc150 stored choice_temperature"] = float(cal["choice_temperature"])
out["bema_clinc150 uncalibrated and calibrated weights identical (except temperature)"] = all(torch.equal(sd[k], cal[k]) for k in sd if k != "choice_temperature")
for split in ("val", "test"):
    out[f"bema_clinc150 repo-recipe fit on {split}"] = repo_fit(lg(cd[split]), torch.tensor([r["label"] for r in cd[split]]))
# zs_from_banking: temperature for CLINC target, claimed fit on banking validation split
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
C = cats()
tok = AutoTokenizer.from_pretrained(f"{ROOT}/zs_from_banking"); enc = AutoModel.from_pretrained(f"{ROOT}/zs_from_banking").eval()
def emb(texts):
    o = []
    with torch.no_grad():
        for s in range(0, len(texts), 128):
            x = tok(texts[s:s+128], padding=True, truncation=True, max_length=64, return_tensors="pt")
            h = enc(**x).last_hidden_state; mk = x["attention_mask"].unsqueeze(-1).float()
            o.append(F.normalize((h * mk).sum(1) / mk.sum(1).clamp(min=1), dim=-1))
    return torch.cat(o)
sims = emb([r["text"] for r in data["choice"]["val"]]) @ emb([c.replace("_", " ") for c in C]).T
t = torch.zeros(1, requires_grad=True); opt = torch.optim.LBFGS([t], lr=0.1, max_iter=200)
gold = torch.tensor([r["label"] for r in data["choice"]["val"]])
def cl():
    opt.zero_grad(); x = F.cross_entropy(sims * t.exp(), gold); x.backward(); return x
opt.step(cl)
out["zs_from_banking clinc temperature: reported"] = json.load(open(f"{ROOT}/runs/bema/zeroshot_temperatures.json"))["zs_from_banking"]["clinc"]["temperature"]
out["zs_from_banking clinc temperature: refit on BANKING77 val"] = float(t.exp().detach())
json.dump(out, open(f"{P2}/check2c_more_temps.json", "w"), indent=1); print(json.dumps(out, indent=1))
