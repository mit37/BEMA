"""Check 1b: spot-reproduce BEMA predictions from the checkpoints (CPU, 1 thread, offline).

bema_baseline: the repo's JevCloneEncoder architecture (model.py) is needed to hold the checkpoint's
weights, but tokenisation, padding, temperature and confidence are re-implemented here.
bema_v2: re-implemented from scratch on top of the HF MiniLM encoder (mean pooling + linear heads),
loading bema_v2.pt's state dict into this audit's own module.
Also: bema_v2_spell on the saved corrected texts, zs_offshelf, and bema_clinc150; and refits of the
temperatures on validation vs test to check what they were fit on.
"""
import json
import os
import random
import sys
import time

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
import torch  # noqa: E402
import torch.nn as nn  # noqa: E402
import torch.nn.functional as F  # noqa: E402

torch.set_num_threads(1)
torch.set_num_interop_threads(1)

from common import ROOT, P2, cats, rj, sha  # noqa: E402

sys.path.insert(0, ROOT)
from model import JevCloneEncoder  # noqa: E402  (architecture only)
from tokenizers import Tokenizer  # noqa: E402
from transformers import AutoModel, AutoTokenizer  # noqa: E402

MINILM = os.path.expanduser("~/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/"
                            "1110a243fdf4706b3f48f1d95db1a4f5529b4d41")
CATS = cats()
OUT = {"threads": torch.get_num_threads()}
rnd = random.Random(20261027)
t_start = time.time()


def inputs(task, cond):
    return {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{cond}.jsonl")}


def preds(name, task, cond):
    return {r["idx"]: r for r in rj(f"{ROOT}/runs/bema/{name}_{task}_{cond}.jsonl")}


def compare(tag, file_recs, ours):
    """ours: idx -> (pred, conf). Returns summary dict."""
    pm = sum(1 for i, (p, c) in ours.items() if p != file_recs[i]["pred"])
    diffs = [abs(c - file_recs[i]["conf"]) for i, (p, c) in ours.items()]
    worst = max(ours, key=lambda i: abs(ours[i][1] - file_recs[i]["conf"]))
    res = {"n": len(ours), "pred_mismatches": pm, "max_abs_conf_diff": max(diffs),
           "n_conf_diff_gt_1e-5": sum(1 for d in diffs if d > 1e-5),
           "worst_example": {"idx": worst, "file": [file_recs[worst]["pred"], file_recs[worst]["conf"]], "ours": list(ours[worst])},
           "PASS": pm == 0 and max(diffs) <= 1e-5}
    OUT[tag] = res
    print(tag, json.dumps(res), f"({time.time() - t_start:.0f}s)", flush=True)
    return res


# ---------------------------------------------------------------- picks
b_swap2 = inputs("banking77", "swap2")
s_clean = inputs("spam", "clean")
pick_b = sorted(rnd.sample(sorted(b_swap2), 200))
pick_s = sorted(rnd.sample(sorted(s_clean), 100))
OUT["picks"] = {"banking77_swap2_idx": pick_b, "spam_clean_idx": pick_s, "seed": 20261027}

# ---------------------------------------------------------------- bema_baseline (v1)
import pickle  # noqa: E402
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
tok1 = Tokenizer.from_file(f"{ROOT}/data/tokenizer_multitask.json")
MAXLEN, PAD = data["max_len"], data["pad_id"]
v1 = JevCloneEncoder(vocab_size=data["vocab_size"], max_len=MAXLEN, num_choice_classes=77, enable_score=True)
v1.load_state_dict(torch.load(f"{ROOT}/jev_clone_multitask_calibrated.pt", map_location="cpu"))
v1.eval()


def enc1(texts):
    ids, mask = [], []
    for t in texts:
        x = tok1.encode(t).ids[:MAXLEN]
        ids.append(x + [PAD] * (MAXLEN - len(x)))
        mask.append([1] * len(x) + [0] * (MAXLEN - len(x)))
    return torch.tensor(ids), torch.tensor(mask)


def v1_run(texts, head, batch):
    out = []
    with torch.no_grad():
        for s in range(0, len(texts), batch):
            ids, mask = enc1(texts[s:s + batch])
            pooled = v1.encode(ids, mask)
            if head == "choice":
                p = torch.softmax(v1.choice_head(pooled) / v1.choice_temperature, -1)
                c, i = p.max(-1)
                out += [(int(a), float(b)) for a, b in zip(i, c)]
            else:
                q = torch.sigmoid(v1.noul_head(pooled).squeeze(-1) / v1.temperature)
                out += [(int(x > 0.5), float(max(x, 1 - x))) for x in q]
    return out


for batch in (256, 1):   # the repo scored in batches of 256; batch 1 checks the result does not depend on batching
    o = v1_run([b_swap2[i]["text"] for i in pick_b], "choice", batch)
    compare(f"bema_baseline banking77/swap2 (batch {batch})", preds("bema_baseline", "banking77", "swap2"), dict(zip(pick_b, o)))
    o = v1_run([s_clean[i]["text"] for i in pick_s], "noul", batch)
    compare(f"bema_baseline spam/clean (batch {batch})", preds("bema_baseline", "spam", "clean"), dict(zip(pick_s, o)))


# ---------------------------------------------------------------- bema_v2 (own module)
class V2(nn.Module):
    def __init__(self):
        super().__init__()
        self.enc = AutoModel.from_pretrained(MINILM)
        h = self.enc.config.hidden_size
        self.noul_head, self.choice_head, self.score_head = nn.Linear(h, 1), nn.Linear(h, 77), nn.Linear(h, 1)
        self.register_buffer("t_noul", torch.ones(1))
        self.register_buffer("t_choice", torch.ones(1))


tok2 = AutoTokenizer.from_pretrained(MINILM)
v2 = V2()
missing = v2.load_state_dict(torch.load(f"{ROOT}/bema_v2.pt", map_location="cpu"), strict=True)
v2.eval()
OUT["bema_v2_temperatures_in_checkpoint"] = {"t_noul": float(v2.t_noul), "t_choice": float(v2.t_choice)}


def v2_logits(texts, head, batch=128):
    out = []
    with torch.no_grad():
        for s in range(0, len(texts), batch):
            x = tok2(texts[s:s + batch], padding=True, truncation=True, max_length=64, return_tensors="pt")
            h = v2.enc(input_ids=x["input_ids"], attention_mask=x["attention_mask"]).last_hidden_state
            m = x["attention_mask"].unsqueeze(-1).float()
            pooled = (h * m).sum(1) / m.sum(1).clamp(min=1)
            out.append((v2.choice_head if head == "choice" else v2.noul_head)(pooled))
    return torch.cat(out)


def v2_run(texts, head, batch=128):
    lg = v2_logits(texts, head, batch)
    if head == "choice":
        p = torch.softmax(lg / v2.t_choice, -1)
        c, i = p.max(-1)
        return [(int(a), float(b)) for a, b in zip(i, c)]
    q = torch.sigmoid(lg.squeeze(-1) / v2.t_noul)
    return [(int(x > 0.5), float(max(x, 1 - x))) for x in q]


o = v2_run([b_swap2[i]["text"] for i in pick_b], "choice")
compare("bema_v2 banking77/swap2", preds("bema_v2", "banking77", "swap2"), dict(zip(pick_b, o)))
o = v2_run([s_clean[i]["text"] for i in pick_s], "noul")
compare("bema_v2 spam/clean", preds("bema_v2", "spam", "clean"), dict(zip(pick_s, o)))

# ---------------------------------------------------------------- bema_v2_spell
spell = {}
hash_ok, orig_ok, n_spell = 0, 0, 0
for task, conds in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    for c in conds:
        I = inputs(task, c)
        st = {r["idx"]: r for r in rj(f"{ROOT}/runs/bema/spell_texts/{task}_{c}.jsonl")}
        P = preds("bema_v2_spell", task, c)
        n_spell += len(P)
        hash_ok += sum(1 for i, r in P.items() if r["text_sha256"] == I[i]["text_sha256"] == sha(I[i]["text"]))
        orig_ok += sum(1 for i, r in st.items() if r["original"] == I[i]["text"])
        spell[(task, c)] = (I, st, P)
OUT["bema_v2_spell_integrity"] = {"prediction_rows": n_spell, "text_sha256_equals_ORIGINAL_input_hash": hash_ok,
                                  "spell_texts_original_equals_input_text": orig_ok,
                                  "rows_where_sha_equals_corrected_text_hash": sum(
                                      1 for (I, st, P) in spell.values() for i, r in P.items()
                                      if r["text_sha256"] == sha(st[i]["corrected"]) and st[i]["corrected"] != st[i]["original"])}
pairs = [(k, i) for k, (I, st, P) in spell.items() for i in I]
pick_sp = rnd.sample(pairs, 100)
for head, task in (("choice", "banking77"), ("noul", "spam")):
    sel = [(k, i) for k, i in pick_sp if k[0] == task]
    if not sel:
        continue
    o = v2_run([spell[k][1][i]["corrected"] for k, i in sel], head)
    file_recs = {f"{k[1]}:{i}": spell[k][2][i] for k, i in sel}
    compare(f"bema_v2_spell {task} (random over all conditions, corrected text)", file_recs,
            {f"{k[1]}:{i}": v for (k, i), v in zip(sel, o)})
    # and the same rows on the ORIGINAL text should NOT generally match (proves the corrected text was used)
    o2 = v2_run([spell[k][0][i]["text"] for k, i in sel], head)
    OUT[f"bema_v2_spell {task}: same rows on ORIGINAL text, pred mismatches"] = sum(
        1 for (k, i), (p, c) in zip(sel, o2) if p != spell[k][2][i]["pred"] or abs(c - spell[k][2][i]["conf"]) > 1e-5)
OUT["spell_pick_conditions"] = dict(__import__("collections").Counter(f"{k[0]}/{k[1]}" for k, _ in pick_sp))

# ---------------------------------------------------------------- temperature provenance for bema_v2
val_c = data["choice"]["val"]
val_n = data["noul"]["val"]
test_c = data["choice"]["test"]


def fit_T(logits, labels, binary):
    t = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([t], lr=0.1, max_iter=200)
    loss_fn = nn.BCEWithLogitsLoss() if binary else nn.CrossEntropyLoss()

    def cl():
        opt.zero_grad()
        z = logits.squeeze(-1) / t.exp() if binary else logits / t.exp()
        l = loss_fn(z, labels.float() if binary else labels)
        l.backward()
        return l
    opt.step(cl)
    return float(t.exp())


lv = v2_logits([r["text"] for r in val_c], "choice")
OUT["bema_v2 t_choice refit on VAL"] = fit_T(lv, torch.tensor([r["label"] for r in val_c]), False)
lt = v2_logits([r["text"] for r in test_c], "choice")
OUT["bema_v2 t_choice refit on TEST (for contrast)"] = fit_T(lt, torch.tensor([r["label"] for r in test_c]), False)
ln = v2_logits([r["text"] for r in val_n], "noul")
OUT["bema_v2 t_noul refit on VAL"] = fit_T(ln, torch.tensor([r["label"] for r in val_n]), True)
print("temperatures", {k: v for k, v in OUT.items() if "refit" in k}, OUT["bema_v2_temperatures_in_checkpoint"], flush=True)
del lt

# ---------------------------------------------------------------- zs_offshelf (MiniLM as downloaded)
zs = AutoModel.from_pretrained(MINILM).eval()


def emb(texts, batch=128):
    out = []
    with torch.no_grad():
        for s in range(0, len(texts), batch):
            x = tok2(texts[s:s + batch], padding=True, truncation=True, max_length=64, return_tensors="pt")
            h = zs(**x).last_hidden_state
            m = x["attention_mask"].unsqueeze(-1).float()
            out.append(F.normalize((h * m).sum(1) / m.sum(1).clamp(min=1), dim=-1))
    return torch.cat(out)


temps = json.load(open(f"{ROOT}/runs/bema/zeroshot_temperatures.json"))
descs = [c.replace("_", " ") for c in CATS]
E_lab = emb(descs)
b_clean = inputs("banking77", "clean")
pick_z = sorted(rnd.sample(sorted(b_clean), 100))
sims = emb([b_clean[i]["text"] for i in pick_z]) @ E_lab.T
p = torch.softmax(temps["zs_offshelf"]["banking"]["temperature"] * sims, -1)
c, i = p.max(-1)
compare("zs_offshelf banking77/clean", preds("zs_offshelf", "banking77", "clean"),
        {k: (int(a), float(b)) for k, a, b in zip(pick_z, i, c)})
# temperature provenance: refit on CLINC150 validation (what the file says) vs BANKING77 val/test
raw = json.load(open(f"{ROOT}/data/raw/clinc150_data_full.json"))
ckeys = sorted({l for _, l in raw["train"]})
cdesc = [k.replace("_", " ") for k in ckeys] + ["none of the other intents apply (an out-of-scope request)"]
cidx = {k: n for n, k in enumerate(ckeys + ["oos"])}
cval = [(t, l) for t, l in raw["val"]] + [(t, "oos") for t, _ in raw["oos_val"]]
E_c = emb(cdesc)


def fit_mult(simm, gold):
    t = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([t], lr=0.1, max_iter=200)

    def cl():
        opt.zero_grad()
        l = F.cross_entropy(simm * t.exp(), gold)
        l.backward()
        return l
    opt.step(cl)
    return float(t.exp().detach())


S_cv = emb([t for t, _ in cval]) @ E_c.T
OUT["zs_offshelf banking temperature: reported"] = temps["zs_offshelf"]["banking"]["temperature"]
OUT["zs_offshelf banking temperature: refit on CLINC150 val"] = fit_mult(S_cv, torch.tensor([cidx[l] for _, l in cval]))
S_bt = emb([r["text"] for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")]) @ E_lab.T
OUT["zs_offshelf banking temperature: refit on BANKING77 TEST (for contrast)"] = fit_mult(
    S_bt, torch.tensor([r["label"] for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")]))
print("zs temps", {k: v for k, v in OUT.items() if "temperature" in k}, flush=True)
del zs, S_bt

# ---------------------------------------------------------------- bema_clinc150
cd = pickle.load(open(f"{ROOT}/data/prepared_clinc150.pkl", "rb"))
tokc = Tokenizer.from_file(f"{ROOT}/data/tokenizer_clinc150.json")
mc = JevCloneEncoder(vocab_size=cd["vocab_size"], d_model=96, nhead=6, num_layers=3, max_len=cd["max_len"],
                     num_choice_classes=cd["num_classes"], enable_score=False)
mc.load_state_dict(torch.load(f"{ROOT}/jev_clone_clinc150_calibrated.pt", map_location="cpu"))
mc.eval()
OUT["bema_clinc150 categories equal sorted(train intents)+oos"] = cd["categories"] == ckeys + ["oos"]
items = rj(f"{ROOT}/runs/redteam/inputs/clinc150_clean.jsonl")
pick_c = rnd.sample(items, 100)
ids, mask = [], []
for it in pick_c:
    x = tokc.encode(it["state"]).ids[:cd["max_len"]]
    ids.append(x + [cd["pad_id"]] * (cd["max_len"] - len(x)))
    mask.append([1] * len(x) + [0] * (cd["max_len"] - len(x)))
with torch.no_grad():
    pr = torch.softmax(mc.choice_head(mc.encode(torch.tensor(ids), torch.tensor(mask))) / mc.choice_temperature, -1)
c, i = pr.max(-1)
fr = {r["key"]: r for r in rj(f"{ROOT}/runs/redteam/bema/clinc150_clean__bema_clinc150.jsonl")}
compare("bema_clinc150 clinc150_clean", fr, {it["key"]: (cd["categories"][int(a)], float(b)) for it, a, b in zip(pick_c, i, c)})

OUT["elapsed_s"] = time.time() - t_start
json.dump(OUT, open(f"{P2}/check1_reproduce.json", "w"), indent=1)
print("done", OUT["elapsed_s"])
