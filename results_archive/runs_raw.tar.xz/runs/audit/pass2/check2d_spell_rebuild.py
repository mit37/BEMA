"""Check 2d: rebuild the SymSpell corrector from TRAIN splits + bundled English dictionary only (own code,
symspellpy library), re-correct a random sample of every condition, and compare with runs/bema/spell_texts."""
import json, os, random, re, pickle
from collections import Counter
import symspellpy
from symspellpy import SymSpell, Verbosity
from common import ROOT, P2, rj
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
ENG = os.path.join(os.path.dirname(symspellpy.__file__), "frequency_dictionary_en_82_765.txt")
TOK = re.compile(r"[A-Za-z]+|[^A-Za-z]+")
def build(head):
    cnt = Counter(w.lower() for r in data[head]["train"] for w in re.findall(r"[A-Za-z]+", r["text"]))
    dom = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
    for w, c in cnt.items():
        if c >= 2:
            dom.create_dictionary_entry(w, c)
    eng = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
    eng.load_dictionary(ENG, term_index=0, count_index=1)
    return dom, eng
def fix(sp, text):
    dom, eng = sp; out = []
    for t in TOK.findall(text):
        if not t.isalpha() or len(t) < 2:
            out.append(t); continue
        lo = t.lower()
        if dom.lookup(lo, Verbosity.TOP, max_edit_distance=0) or eng.lookup(lo, Verbosity.TOP, max_edit_distance=0):
            out.append(t); continue
        s = dom.lookup(lo, Verbosity.TOP, max_edit_distance=1 if len(lo) <= 4 else 2) or eng.lookup(lo, Verbosity.TOP, max_edit_distance=1 if len(lo) <= 4 else 2)
        out.append(t if not s else (s[0].term.capitalize() if t[0].isupper() else s[0].term))
    return "".join(out)
rnd = random.Random(8); out = {}
for head, task, conds in (("choice", "banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                          ("noul", "spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    sp = build(head)
    for c in conds:
        rows = rj(f"{ROOT}/runs/bema/spell_texts/{task}_{c}.jsonl")
        pick = rnd.sample(rows, 150)
        mism = [r["idx"] for r in pick if fix(sp, r["original"]) != r["corrected"]]
        out[f"{task}/{c}"] = {"checked": len(pick), "mismatches": len(mism), "examples": mism[:5]}
json.dump(out, open(f"{P2}/check2d_spell_rebuild.json", "w"), indent=1); print(json.dumps(out))
