"""Check 1c / 2: temperature provenance for bema_baseline, bema_clinc150 and zs_from_clinc, and spot
reproduction of zs_from_clinc and zs_offshelf_bge_base predictions. CPU, 1 thread, offline."""
import glob
import json
import os
import pickle
import random
import sys
import time

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
import torch  # noqa: E402
import torch.nn as nn  # noqa: E402
import torch.nn.functional as F  # noqa: E402

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
from common import ROOT, P2, cats, rj  # noqa: E402

sys.path.insert(0, ROOT)
from model import JevCloneEncoder  # noqa: E402  (architecture only)
from tokenizers import Tokenizer  # noqa: E402
from transformers import AutoModel, AutoTokenizer  # noqa: E402

CATS = cats()
OUT = {}
t0 = time.time()
rnd = random.Random(31337)


def fit_div(logits, labels, binary=False):
    """Temperature T minimising NLL of logits / T."""
    t = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([t], lr=0.1, max_iter=500)
    lf = nn.BCEWithLogitsLoss() if binary else nn.CrossEntropyLoss()

    def cl():
        opt.zero_grad()
        z = logits.squeeze(-1) / t.exp() if binary else logits / t.exp()
        l = lf(z, labels.float() if binary else labels)
        l.backward()
        return l
    opt.step(cl)
    return float(t.exp().detach())


def fit_mult(sims, gold):
    t = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([t], lr=0.1, max_iter=200)

    def cl():
        opt.zero_grad()
        l = F.cross_entropy(sims * t.exp(), gold)
        l.backward()
        return l
    opt.step(cl)
    return float(t.exp().detach())


# ---------------------------------------------------------------- bema_baseline temperatures
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
v1 = JevCloneEncoder(vocab_size=data["vocab_size"], max_len=data["max_len"], num_choice_classes=77, enable_score=True)
v1.load_state_dict(torch.load(f"{ROOT}/jev_clone_multitask_calibrated.pt", map_location="cpu"))
v1.eval()


def v1_logits(rows, head):
    out = []
    with torch.no_grad():
        for s in range(0, len(rows), 256):
            ids = torch.tensor([r["ids"] for r in rows[s:s + 256]])
            mask = torch.tensor([r["mask"] for r in rows[s:s + 256]])
            p = v1.encode(ids, mask)
            out.append(v1.choice_head(p) if head == "choice" else v1.noul_head(p))
    return torch.cat(out)


for head, binary in (("choice", False), ("noul", True)):
    for split in ("val", "test"):
        rows = data[head][split]
        OUT[f"bema_baseline {head} temperature refit on {split.upper()}"] = fit_div(
            v1_logits(rows, head), torch.tensor([int(r["label"]) for r in rows]), binary)
OUT["bema_baseline temperatures in checkpoint"] = {"choice": float(v1.choice_temperature), "noul": float(v1.temperature)}
print({k: v for k, v in OUT.items() if "bema_baseline" in k}, f"{time.time() - t0:.0f}s", flush=True)

# ---------------------------------------------------------------- bema_clinc150 temperature
cd = pickle.load(open(f"{ROOT}/data/prepared_clinc150.pkl", "rb"))
mc = JevCloneEncoder(vocab_size=cd["vocab_size"], d_model=96, nhead=6, num_layers=3, max_len=cd["max_len"],
                     num_choice_classes=cd["num_classes"], enable_score=False)
mc.load_state_dict(torch.load(f"{ROOT}/jev_clone_clinc150_calibrated.pt", map_location="cpu"))
mc.eval()
for split in ("val", "test"):
    rows = cd[split]
    with torch.no_grad():
        lg = torch.cat([mc.choice_head(mc.encode(torch.tensor([r["ids"] for r in rows[s:s + 256]]),
                                                 torch.tensor([r["mask"] for r in rows[s:s + 256]])))
                        for s in range(0, len(rows), 256)])
    OUT[f"bema_clinc150 temperature refit on {split.upper()}"] = fit_div(lg, torch.tensor([r["label"] for r in rows]))
OUT["bema_clinc150 temperature in checkpoint"] = float(mc.choice_temperature)
print({k: v for k, v in OUT.items() if "clinc150" in k}, f"{time.time() - t0:.0f}s", flush=True)

# ---------------------------------------------------------------- zero-shot helpers
raw = json.load(open(f"{ROOT}/data/raw/clinc150_data_full.json"))
ckeys = sorted({l for _, l in raw["train"]})
cdesc = [k.replace("_", " ") for k in ckeys] + ["none of the other intents apply (an out-of-scope request)"]
cidx = {k: n for n, k in enumerate(ckeys + ["oos"])}
cval = [(t, l) for t, l in raw["val"]] + [(t, "oos") for t, _ in raw["oos_val"]]
bdesc = [c.replace("_", " ") for c in CATS]
b_clean = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")}
temps = json.load(open(f"{ROOT}/runs/bema/zeroshot_temperatures.json"))


def embedder(path, pool):
    tok = AutoTokenizer.from_pretrained(path)
    m = AutoModel.from_pretrained(path).eval()

    def emb(texts):
        out = []
        with torch.no_grad():
            for s in range(0, len(texts), 128):
                x = tok(texts[s:s + 128], padding=True, truncation=True, max_length=64, return_tensors="pt")
                h = m(**x).last_hidden_state
                if pool == "cls":
                    out.append(F.normalize(h[:, 0], dim=-1))
                else:
                    mk = x["attention_mask"].unsqueeze(-1).float()
                    out.append(F.normalize((h * mk).sum(1) / mk.sum(1).clamp(min=1), dim=-1))
        return torch.cat(out)
    return emb


def compare(tag, name, idxs, probs):
    file = {r["idx"]: r for r in rj(f"{ROOT}/runs/bema/{name}_banking77_clean.jsonl")}
    c, i = probs.max(-1)
    pm = sum(1 for k, a in zip(idxs, i) if int(a) != file[k]["pred"])
    md = max(abs(float(b) - file[k]["conf"]) for k, b in zip(idxs, c))
    OUT[tag] = {"n": len(idxs), "pred_mismatches": pm, "max_abs_conf_diff": md, "PASS": pm == 0 and md <= 1e-5}
    print(tag, OUT[tag], f"{time.time() - t0:.0f}s", flush=True)


pick = sorted(rnd.sample(sorted(b_clean), 100))

# zs_from_clinc: fine-tuned dir, mean pooling
emb = embedder(f"{ROOT}/zs_from_clinc", "mean")
S = emb([t for t, _ in cval]) @ emb(cdesc).T
OUT["zs_from_clinc banking temperature: reported"] = temps["zs_from_clinc"]["banking"]["temperature"]
OUT["zs_from_clinc banking temperature: refit on CLINC150 val"] = fit_mult(S, torch.tensor([cidx[l] for _, l in cval]))
E = emb(bdesc)
compare("zs_from_clinc banking77/clean reproduction", "zs_from_clinc", pick,
        torch.softmax(temps["zs_from_clinc"]["banking"]["temperature"] * (emb([b_clean[k]["text"] for k in pick]) @ E.T), -1))
del emb, S, E

# zs_offshelf_bge_base: try both poolings, report which reproduces
bge = glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--BAAI--bge-base-en-v1.5/snapshots/*"))[0]
for pool in ("cls", "mean"):
    emb = embedder(bge, pool)
    E = emb(bdesc)
    compare(f"zs_offshelf_bge_base banking77/clean reproduction ({pool} pooling)", "zs_offshelf_bge_base", pick,
            torch.softmax(temps["zs_offshelf_bge_base"]["banking"]["temperature"] * (emb([b_clean[k]["text"] for k in pick]) @ E.T), -1))
    if OUT[f"zs_offshelf_bge_base banking77/clean reproduction ({pool} pooling)"]["PASS"]:
        S = emb([t for t, _ in cval]) @ emb(cdesc).T
        OUT["zs_offshelf_bge_base banking temperature: reported"] = temps["zs_offshelf_bge_base"]["banking"]["temperature"]
        OUT["zs_offshelf_bge_base banking temperature: refit on CLINC150 val"] = fit_mult(S, torch.tensor([cidx[l] for _, l in cval]))
        break
    del emb, E

OUT["elapsed_s"] = time.time() - t0
json.dump(OUT, open(f"{P2}/check1c_more_repro.json", "w"), indent=1)
print(json.dumps(OUT, indent=1))
