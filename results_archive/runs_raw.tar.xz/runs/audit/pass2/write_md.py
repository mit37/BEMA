"""Writes runs/audit/AUDIT_PASS2.md from the pass-2 JSON outputs (all produced by this audit's own code)."""
import json

from common import ROOT, P2

A = f"{ROOT}/runs/audit"
j = lambda n: json.load(open(f"{P2}/{n}"))
c1, rp, rp2, lk, t1, t2, t3 = (j("check1_bema_metrics.json"), j("check1_reproduce.json"), j("check1c_more_repro.json"),
                               j("check2_leakage.json"), j("check2b_v1_temperature.json"), j("check2c_more_temps.json"),
                               j("check2e_zs_clinc_temps.json"))
sp, l3, l3b, l3c, l3r, s4, c5, c5b, c0 = (j("check2d_spell_rebuild.json"), j("check3_llm.json"), j("check3b_parser_policies.json"),
                                          j("check3c_extra.json"), json.load(open(f"{P2}/repo_rule/check3_llm.json")),
                                          j("check4_summary.json"), j("check5_context.json"), j("check5b_heldout.json"),
                                          j("check0_jev_regression.json"))


def f(v):
    if isinstance(v, bool) or v is None:
        return str(v)
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, float):
        return f"{v:.6g}"
    if isinstance(v, list):
        return "[" + ", ".join(f(a) for a in v) + "]"
    return str(v).replace("|", "\\|")


def nfail(rows):
    return sum(r["result"] == "FAIL" for r in rows)


tot_rows = len(c1["rows"]) + len(l3["rows"]) + len(s4["rows"]) + len(c0)
tot_fail = nfail(c1["rows"]) + nfail(l3["rows"]) + nfail(s4["rows"]) + nfail(c0)
L = []
P = L.append
P("# Audit pass 2: BEMA, zero-shot and LLM numbers")
P("")
P("This is an independent re-computation from the raw files in `runs/`. I wrote all the code in `runs/audit/pass2/` from scratch. "
  "Four scripts import `model.py`, but only for the `JevCloneEncoder` class, which they need to load the checkpoint weights; tokenisation, "
  "temperature and confidence are recomputed independently. One script imports `llm_baseline.parse`, but only to list the rows where the "
  "report's parser and mine disagree. I did not rerun any report command or modify any file outside `runs/audit/pass2/` and this file. "
  "I made no network or API calls: Hugging Face was set to offline mode, and all inference ran on CPU with `torch.set_num_threads(1)`. "
  "The `bema_v2_full` training job was running when I started; `runs/bema_v2_full.log` shows it was terminated at 13:44:01 local time, "
  "during epoch 3, and no `bema_v2_full.pt` exists.")
P("")
P("Inputs as they stood: `runs/report.json` (20:22:32 UTC), `runs/redteam_report.json` (20:22:48), `runs/llm_report.json` (20:21:01), "
  "`runs/results_summary.json` (20:21:33).")
P("")
P("## Verdict")
P("")
P(f"**{tot_rows - tot_fail:,} of {tot_rows:,} reported numbers reproduce exactly.** Every BEMA and zero-shot number in `report.json` and "
  f"`redteam_report.json` reproduces (1,143/1,143), and so does every prediction I re-ran from the checkpoints. The leakage checks pass. "
  f"Of the {tot_fail} row-level FAILs, 62 come from one LLM reply-parsing choice and 1 from a mislabelled spend figure. On top of these, "
  f"`results_summary.json` has two problems that are not single numbers: it omits models, and it reuses BEMA predictions without saying so. In detail:")
P("")
P("1. **`results_summary.json` is stale.** It was written at 20:21:33 UTC, before the commit at 20:25:31 UTC that changed `results_summary.py`. "
  "This matters because it is the file the paper, slides and infographic are meant to quote. "
  "(a) Its spend line `openrouter_usd_reported: 113.69` mislabels the total: only **$3.115** of it is OpenRouter. The other **$110.575** is "
  "Anthropic direct, computed as tokens x list price. "
  "(b) It **omits Claude Sonnet 5.5, Claude Opus 5.5 and Claude Fable 5.1** from every accuracy section, even though their raw files exist. "
  "Those three, plus GPT-6.1 Terra (which the summary does include, on the 250-query slice), are the LLMs that beat Jev: "
  "Opus by +8.2 points and Sonnet by +4.0 on the full clean BANKING77 set, Fable by +6.8 and Terra by +4.4 on the slice.")
P("2. **LLM reply parsing (8 replies in 7 model/test cells, 61 rows).** The report's greedy `{.*}` regex marks a reply invalid when the model "
  "writes a JSON answer and then a corrected second JSON answer. My parser takes the last JSON object. The effect is at most 0.1 accuracy "
  "points, 2 invalid replies and 0.0008 ECE in any cell. When I re-implement the report's own rule, all 1,208 LLM rows reproduce exactly, "
  "so the arithmetic is correct and the differences are purely a parsing-policy choice. One results_summary row inherits this "
  "(Haiku clean ECE 0.0854 vs 0.0857).")
P("3. **Unlabelled reuse in slice250.** The `slice250_all_models` section reuses BEMA's undefended predictions for its "
  "`injection_casual_defended` row (they are identical), and nothing in that section says so. The `injection` section does say so.")
P("")
P("| # | FAIL | reported | recomputed | note |")
P("|---|---|---|---|---|")
P("| 1 | results_summary `spend.openrouter_usd_reported` | 113.69 | 3.115 OpenRouter (+110.575 Anthropic = 113.690 total) | mislabelled; the current script splits it, but the file predates that change |")
P("| 2 | results_summary banking77_typos / spam / slice250 / injection: rows for Sonnet 5.5, Opus 5.5, Fable 5.1, zs_offshelf_bge_base | absent | present in raw files and in llm_report/report | stale file; Fable appears nowhere in the summary's accuracy tables |")
P("| 3 | results_summary slice250 `injection_casual_defended/bema_v2` | 45.2% (unlabelled) | 45.2%, byte-identical to the undefended row | needs the same note as the injection section |")
P("| 4 | results_summary banking77_typos clean/claude-haiku-5.5 ECE | 0.0854 | 0.0857 | parsing policy (see 2) |")
fs = {}
for r in l3["rows"]:
    if r["result"] == "FAIL":
        fs.setdefault(r["section"].replace("llm ", ""), {})[r["metric"]] = (r["reported"], r["ours"])
for k, v in fs.items():
    bits = []
    for m in ("invalid_output", "accuracy_invalid_counted_wrong", "ece_stated_confidence"):
        if m in v:
            a, b = v[m]
            bits.append(f"{m.replace('accuracy_invalid_counted_wrong', 'accuracy').replace('ece_stated_confidence', 'ECE')} {f(a)} -> {f(b)}")
    P(f"| 5 | llm_report {k} | | | {'; '.join(bits)} (plus derived rows: rate, n_with_confidence, mean conf, Wilson CI) |")
P("")
P("## Check 1: BEMA prediction files")
P("")
P("### 1a. Recomputing every BEMA and zero-shot metric: PASS (1,143/1,143)")
P("- `report.json`: I recomputed 672 values across bema_baseline, bema_v2, bema_v2_spell, zs_offshelf, zs_from_clinc and zs_offshelf_bge_base. "
  "These cover accuracy, mean confidence, overconfidence, ECE (exact edges and the float32 variant), Wilson CI, drops, spam precision/recall/F1/FP/FN, "
  "and the Jev-minus-model difference. My own bootstrap matches the paired-bootstrap CIs within 0.005. All PASS.")
P("- `redteam_report.json`: I recomputed 471 values for every BEMA, zero-shot and bema_clinc150 entry: injection, spam, OOD, gibberish by kind, "
  "order shuffle, Amazon r/MAE/rounded accuracy, CLINC in-scope/oos/false-oos, and said_oos_with_note. All PASS.")
P("- File integrity: none of the 49 core and 65 red-team prediction files has a duplicate, missing or extra idx/key, or a sha256 mismatch. "
  "No pred falls outside its option set and no confidence outside [0, 1]. For spam, pred and conf agree with p_yes in every row.")
P("- Not reported, but present: BEMA predictions for `repeat_banking`, `repeat_banking_spread` and `latency_sequential_banking`. They are identical to the core "
  "clean predictions (0 changed answers, max |Δconf| 1.6e-6), as expected for a deterministic model.")
P("")
P("### 1b. Re-running predictions from the checkpoints: PASS (CPU, 1 thread)")
P("| model | sample | pred mismatches | max abs conf diff |")
P("|---|---|---|---|")
for k in ["bema_baseline banking77/swap2 (batch 256)", "bema_baseline spam/clean (batch 256)", "bema_baseline banking77/swap2 (batch 1)",
          "bema_baseline spam/clean (batch 1)", "bema_v2 banking77/swap2", "bema_v2 spam/clean",
          "bema_v2_spell banking77 (random over all conditions, corrected text)", "bema_v2_spell spam (random over all conditions, corrected text)",
          "zs_offshelf banking77/clean", "bema_clinc150 clinc150_clean"]:
    v = rp[k]
    P(f"| {k} | {v['n']} | {v['pred_mismatches']} | {v['max_abs_conf_diff']:.2e} |")
for k in ["zs_from_clinc banking77/clean reproduction", "zs_offshelf_bge_base banking77/clean reproduction (cls pooling)"]:
    v = rp2[k]
    P(f"| {k} | {v['n']} | {v['pred_mismatches']} | {v['max_abs_conf_diff']:.2e} |")
P("")
P("I picked 200 random banking77/swap2 rows and 100 random spam/clean rows (seed 20261027). For bema_v2 I wrote my own module (MiniLM, mean pooling, "
  "linear heads) and loaded `bema_v2.pt` into it with strict key matching. For bema_baseline I used `model.py`'s class, and re-implemented the tokenisation, "
  "padding, temperature and softmax. Batch size changes confidence by at most 6e-7.")
si = rp["bema_v2_spell_integrity"]
P(f"- bema_v2_spell: in all {si['prediction_rows']:,} prediction rows, text_sha256 equals the hash of the **original** frozen input; it never "
  f"equals the hash of the corrected text ({si['rows_where_sha_equals_corrected_text_hash']} rows). The `original` field in spell_texts equals "
  f"the input text in all {si['spell_texts_original_equals_input_text']:,} rows. I drew 100 random rows across all 11 conditions and re-ran "
  f"bema_v2.pt on the corrected text; all 100 reproduce. Running the same rows on the original text changes "
  f"{rp['bema_v2_spell banking77: same rows on ORIGINAL text, pred mismatches'] + rp['bema_v2_spell spam: same rows on ORIGINAL text, pred mismatches']} "
  f"of the 100 (pred or confidence), which shows the corrected text really was what the model scored.")
P("")
P("## Check 2: Leakage: PASS, with two dataset-level caveats")
P("")
P("**Temperatures.** For each model I refit the temperature myself on the split the code claims, and on the test split for contrast:")
P("")
P("| model / head | stored | refit on claimed split | refit on test (contrast) |")
P("|---|---|---|---|")
P(f"| bema_baseline choice | {t1['checkpoint']['choice']:.6f} | {t1['choice repo-recipe fit on val']:.6f} (val, repo recipe) | {t1['choice repo-recipe fit on test']:.6f} |")
P(f"| bema_baseline noul | {t1['checkpoint']['noul']:.6f} | {t1['noul repo-recipe fit on val']:.6f} (val) | {t1['noul repo-recipe fit on test']:.6f} |")
P(f"| bema_v2 choice | {rp['bema_v2_temperatures_in_checkpoint']['t_choice']:.6f} | {rp['bema_v2 t_choice refit on VAL']:.6f} (val) | {rp['bema_v2 t_choice refit on TEST (for contrast)']:.6f} |")
P(f"| bema_v2 noul | {rp['bema_v2_temperatures_in_checkpoint']['t_noul']:.6f} | {rp['bema_v2 t_noul refit on VAL']:.6f} (val) | |")
P(f"| bema_clinc150 | {t2['bema_clinc150 stored choice_temperature']:.6f} | {t2['bema_clinc150 repo-recipe fit on val']:.6f} (val) | {t2['bema_clinc150 repo-recipe fit on test']:.6f} |")
P(f"| zs_offshelf -> BANKING77 | {rp['zs_offshelf banking temperature: reported']:.4f} | {rp['zs_offshelf banking temperature: refit on CLINC150 val']:.4f} (CLINC150 val) | {rp['zs_offshelf banking temperature: refit on BANKING77 TEST (for contrast)']:.4f} |")
P(f"| zs_offshelf -> CLINC150 | {t3['zs_offshelf']['reported']:.4f} | {t3['zs_offshelf']['refit_on_banking_val']:.4f} (BANKING77 val) | |")
P(f"| zs_from_clinc -> BANKING77 | {rp2['zs_from_clinc banking temperature: reported']:.4f} | {rp2['zs_from_clinc banking temperature: refit on CLINC150 val']:.4f} (CLINC150 val) | |")
P(f"| zs_from_banking -> CLINC150 | {t2['zs_from_banking clinc temperature: reported']:.4f} | {t2['zs_from_banking clinc temperature: refit on BANKING77 val']:.4f} (BANKING77 val) | |")
P(f"| zs_offshelf_bge_base -> BANKING77 | {rp2['zs_offshelf_bge_base banking temperature: reported']:.4f} | {rp2['zs_offshelf_bge_base banking temperature: refit on CLINC150 val']:.4f} (CLINC150 val) | |")
P(f"| zs_offshelf_bge_base -> CLINC150 | {t3['zs_offshelf_bge_base']['reported']:.4f} | {t3['zs_offshelf_bge_base']['refit_on_banking_val']:.4f} (BANKING77 val; optimiser noise of 0.02%) | |")
P("")
P("Every stored temperature reproduces from the validation split the code names, to 6-7 digits. Fitting on test gives a visibly different value "
  "in every case. Note that bema_v2's choice temperature is 0.50, which sharpens its probabilities rather than softening them.")
P("")
P("**Code read.**")
P("- `bema_spell.py` builds the domain dictionary only from `data[head][\"train\"]` (words seen at least twice), plus SymSpell's bundled English list. It never reads test text. "
  "(The inner `for head in (head,)` loop shadows a variable but does no harm.) I rebuilt the corrector from train only and re-corrected "
  "150 random texts per condition (1,650 texts); my output equals the saved corrected text in every case. None of the 220 BANKING77 and 699 spam words that "
  "appear only in the test text are in the domain dictionary.")
P("- `bema_v2.py`: epoch selection and both temperatures use `data[...][\"val\"]` only; training uses only `train`, with swap2 augmentation re-drawn by its own RNG. The test splits are read only in `predict()`.")
P("- `bema_zeroshot.py`: fine-tuning reads `clinc_split(\"train\")` or `banking_split(\"train\")` only. Each temperature is fit on the other dataset's validation split, as "
  "`zeroshot_temperatures.json` states, and the refits above confirm it. No test text is touched before scoring.")
P("- `calibrate_multitask.py` (bema_baseline) and `clinc150_pipeline.py` (bema_clinc150) fit temperatures on val. They then evaluate on test, but only to print diagnostics; the checkpoint values match the val fits.")
P("")
P("**Dataset-level caveats.** These are properties of the datasets and the random split, not leaks in the code:")
P(f"- Spam: {lk['noul: test rows whose text (case/space-normalised) also appears in TRAIN']} of 836 test messages are verbatim duplicates of training messages. The SMS corpus contains repeats, and `prepare_multitask.py` "
  f"splits it without de-duplicating. BEMA scores 100% on these. On the {lk['bema_v2 spam/clean accuracy on train-overlapping vs unseen test messages']['unseen_n']} unseen messages, "
  f"bema_v2 scores {lk['bema_v2 spam/clean accuracy on train-overlapping vs unseen test messages']['unseen_acc']:.4f} (vs 0.9868 overall) and bema_baseline "
  f"{lk['bema_baseline spam/clean accuracy on train-overlapping vs unseen test messages']['unseen_acc']:.4f} (vs 0.9785), so the inflation is about 0.2 points.")
P(f"- Amazon: {c5['amazon test rows overlapping train']} of 1,517 test reviews also appear in train. For bema_v2, r is {c5['bema_v2 amazon clean: r all / r unseen-only / MAE all / MAE unseen-only'][0]:.3f} on all reviews and "
  f"{c5['bema_v2 amazon clean: r all / r unseen-only / MAE all / MAE unseen-only'][1]:.3f} on unseen ones only, so the effect is negligible. BANKING77 has 5 such test texts and CLINC150 has 2, also negligible.")
P(f"- CLINC150 shares only one intent name with BANKING77 (`exchange_rate`). However, it has {len(lk['clinc150 banking-domain intents (name contains card/pin/transfer/balance/exchange/account/transaction)'])} banking-domain intents "
  "(transfer, report_lost_card, pin_change, card_declined, freeze_account, ...). So 'zero-shot from CLINC150' is cross-dataset, but only partly cross-domain.")
P("")
P("## Check 3: LLM files")
P("")
P(f"**Recomputation: {len(l3['rows']) - nfail(l3['rows'])}/{len(l3['rows'])} PASS with my parser, and {len(l3r['rows']) - nfail(l3r['rows'])}/{len(l3r['rows'])} PASS with the report's rule re-implemented.** "
  "I rebuilt every test's item set independently: the core inputs; the red-team inputs; the 250-key slice re-derived from the documented seeds "
  "(Random(7), then Random(11)); and latency = the first 100 clean queries. I then recomputed accuracy (invalid counted as wrong), invalid count and rate, "
  "mean stated confidence, ECE on valid rows, followed_injected_label, median and p90 latency, cost per 1,000 calls, prompt and output tokens, "
  "thinking/reasoning tokens, providers, and Qwen's token-probability ECE.")
P("")
P("**My parser:** it takes the last JSON object in the reply that contains the key. The intent must be a string that exactly matches one of the 77 labels "
  "after stripping surrounding whitespace. Confidence and p_spam must be numbers in [0, 1]. Empty or unparseable replies are invalid and counted as wrong.")
P("")
P("**Every reply where the two parsers disagree** (8 replies; in all 8 the model wrote two JSON objects, so the greedy `{.*}` match spans both and fails to parse):")
P("")
P("| model / test / key | gold | report | audit | reply (truncated) |")
P("|---|---|---|---|---|")
for d in l3["disagreements"]:
    P(f"| {d['model']} / {d['test']} / {d['key']} | {d['gold']} | invalid | {d['audit']['pred']} ({d['audit']['conf']}) | "
      f"{d['content'][:170].replace(chr(10), ' ').replace('|', '/')} |")
P("")
tab = l3b["policy_table"]
P("How sensitive the results are to the parsing policy (accuracy / invalid count). 'Strict' means the reply must be a single JSON object, optionally in a ```json fence:")
P("")
P("| model/test | report rule | last object (audit) | strict JSON-only |")
P("|---|---|---|---|")
for k in ["claude-opus-5.5/banking77_clean", "claude-opus-5.5/banking77_mixed3", "claude-opus-5.5/spam_swap2", "claude-sonnet-5.5/banking77_mixed3",
          "claude-sonnet-5.5/banking77_clean", "claude-haiku-5.5/banking77_swap2", "qwen3.8-flash/banking77_clean"]:
    v = tab[k]
    P(f"| {k} | {v['greedy']['accuracy']:.4f} / {v['greedy']['invalid']} | {v['last']['accuracy']:.4f} / {v['last']['invalid']} | {v['strict']['accuracy']:.4f} / {v['strict']['invalid']} |")
P("")
P("Opus reports 0 invalid outputs only because the extraction is lenient. On mixed3, 37 of its replies (1.2%) put prose before the JSON. Real invalid intents look like this: "
  + "; ".join(f"{m}: " + ", ".join(f"`{k}` x{n}" for k, n in list(v.items())[:4]) for m, v in l3b["invalid_intents_by_model"].items()) + ".")
P("")
cc = l3["cost_checks"]
P("**Other checks: all PASS.**")
P(f"- Thinking tokens are billed. Opus has {cc['claude-opus-5.5']['thinking_tokens']:,} thinking tokens across {cc['claude-opus-5.5']['records_with_thinking']:,} of {cc['claude-opus-5.5']['records']:,} calls. "
  f"In every record, output_tokens >= thinking_tokens (thinking is included in output), and cost = in x $4/M + out x $20/M exactly "
  f"({cc['claude-opus-5.5']['cost_ne_tokens_x_price']} mismatches). Sonnet (thinking off) and Fable (adaptive, low) used 0 thinking tokens; their costs equal tokens x $2/$10 and $10/$50 exactly. "
  "None of the Anthropic calls used cache tokens. OpenRouter cost = usage.cost, which equals upstream_inference_cost in every record.")
P("- No empty replies exist in any of the 64,848 ok records, so none can be counted as correct. Under my parser an empty reply would be invalid and wrong.")
P("- No record outside a test's item set is counted: 0 ok keys outside the item set, 0 duplicate ok keys, 0 sha256 mismatches, in every file. All 18 `_s250` files contain exactly the 250 slice keys.")
nr = sum(l3["notes"]["llm_partial_ratelimited_records"].values())
cr = sum(l3["notes"]["llm_partial_ratelimited_cost_not_counted"].values())
P(f"- `runs/llm_partial_ratelimited/` ({nr:,} records, ${cr:.3f}) is excluded everywhere. llm_report, results_summary and the spend functions all read only `runs/llm/<model>/`. "
  f"My totals from `runs/llm/` equal the reported totals: $3.1148 OpenRouter and $110.5751 Anthropic. Note that these totals therefore leave out the ${cr:.2f} spent on the set-aside runs.")
P("- The sequential latency runs really were sequential: with request start times reconstructed as timestamp minus latency, no two calls overlap in any of the 8 files.")
P("")
P("## Check 4: results_summary.json")
P("")
P(f"I recomputed {len(s4['rows'])} values from the raw files. {len(s4['rows']) - nfail(s4['rows'])} PASS and 2 FAIL (#1 and #4 above). Covered: every accuracy_pct, n, ECE (4 dp) and followed-injection value in "
  "banking77_typos, spam, slice250_all_models and injection; mean confidence and clean_reference in injection; and all speed_cost, Jev spend and majority-baseline numbers.")
nt = s4["notes"]
P(f"- slice250 uses identical keys for every model and every row: {nt['slice250_every_row_uses_identical_keys']} (250 keys, 75 distinct intents).")
P(f"- BEMA defended rows reuse the undefended predictions. I checked that the predictions are identical "
  f"({all(nt['slice250_bema_defended_vs_undefended_identical'].values())}) and that the state text of the defended and undefended inputs is identical too. "
  f"The `injection` section labels this in its note: \"{nt['injection_note'][:110]}...\". The `slice250_all_models` section has **no** such label (FAIL #3).")
P("- The `redteam_other` block equals the current `redteam_report.json` exactly.")
P("- The file is stale: its spend keys (`jev_usd_estimate`, `openrouter_usd_reported`) are the previous script's, and it lacks the model rows the current script adds. "
  "Models with raw files that are missing from the summary: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in nt["models_with_raw_files_missing_from_summary"].items() if v) +
  ". slice250 is also missing Sonnet, Opus and Fable; injection is missing Sonnet and Opus. The fix is to regenerate it and then re-audit.")
P("")
P("## Check 5: What a skeptical interviewer would attack")
P("")
pv = c5["paired_vs_jev"]
hd = c5b


def pp(k, src=pv):
    v = src[k]
    return f"{v['model_minus_jev_pp']:+.1f} pts [{v['ci95_pp'][0]:+.1f}, {v['ci95_pp'][1]:+.1f}]"


P("Paired model-minus-Jev accuracy on identical queries, with 95% bootstrap CIs:")
P("")
P("| comparison | clean | swap2 | mixed3 (held out for BEMA) |")
P("|---|---|---|---|")
P(f"| bema_baseline (trained on BANKING77) | {pp('bema_baseline full clean')} | {pp('bema_baseline full swap2')} | {pp('bema_baseline mixed3', hd)} |")
P(f"| bema_v2 (trained) | {pp('bema_v2 full clean')} | {pp('bema_v2 full swap2')} | {pp('bema_v2 mixed3', hd)} |")
P(f"| bema_v2_spell (trained + spell-fix) | {pp('bema_v2_spell full clean')} | {pp('bema_v2_spell full swap2')} | {pp('bema_v2_spell mixed3', hd)} |")
P(f"| zs_offshelf_bge_base (zero-shot) | {pp('zs_offshelf_bge_base full clean')} | {pp('zs_offshelf_bge_base full swap2')} | |")
P(f"| zs_from_clinc (zero-shot) | {pp('zs_from_clinc full clean')} | {pp('zs_from_clinc full swap2')} | |")
P(f"| Claude Opus 5.5 | {pp('claude-opus-5.5 full clean')} | | {pp('claude-opus-5.5 mixed3', hd)} |")
P(f"| Claude Sonnet 5.5 | {pp('claude-sonnet-5.5 full clean')} | | {pp('claude-sonnet-5.5 mixed3', hd)} |")
P(f"| Claude Haiku 5.5 | {pp('claude-haiku-5.5 full clean')} | | {pp('claude-haiku-5.5 mixed3', hd)} |")
P(f"| Qwen 3.8 Flash | {pp('qwen3.8-flash full clean')} | | {pp('qwen3.8-flash mixed3', hd)} |")
P(f"| GPT-6.1 Terra (250 slice only) | {pp('gpt-6.1-terra slice250 clean')} | | |")
P(f"| Claude Fable 5.1 (250 slice only) | {pp('claude-fable-5.1 slice250 clean')} | | |")
P("")
P("1. **The summary omits the strongest baselines.** On the full set, the file meant to be quoted shows Jev at 80.6% ahead of every LLM it lists: "
  "Haiku (76.8%) and Qwen (79.4%). Opus (88.8%) and Sonnet (84.6%) were run on the same 3,080 queries and are missing. "
  "Jev beats only the small, cheap LLMs. Opus's lead holds under typos (88.8% on swap2, 88.3% on mixed3).")
P("2. **Trained vs zero-shot.** BEMA v1 and v2 were trained on 8,503 BANKING77 and 3,900 SMS examples, while Jev and the LLMs see only label names. On clean "
  "BANKING77, trained BEMA v2 leads Jev by only +1.8 points (and v1's lead is not significant). The zero-shot BEMA variants trail Jev by 11-18 points. "
  "Saying 'BEMA matches Jev' without 'after supervised training on this exact task' would be misleading.")
P("3. **The spell corrector does the work on typos.** Without it, bema_v2 falls 7.7-13.0 points behind Jev on each of the five typo types I checked (swap2, keyboard2, delete2, insert2, mixed3). bema_v2_spell is level with Jev on swap2 and mixed3 "
  "(CIs include 0), slightly ahead on keyboard2 and insert2, and slightly behind on delete2. The credit belongs to the SymSpell front end with a domain dictionary built from training data.")
P(f"4. **Different sample sizes.** GPT-6 Luna, GPT-6.1 Terra and Fable were run only on the 250-query slice (95% CI half-width about ±{c5['slice250 wilson halfwidth at 80%']} points at 80%). "
  f"The slice is harder than the full set: Jev scores {c5['jev accuracy: full 3080 vs slice250 vs 1000-sample'][1]:.1%} on it vs {c5['jev accuracy: full 3080 vs slice250 vs 1000-sample'][0]:.1%} on all 3,080. "
  "Slice numbers must never be compared with full-set numbers.")
P("5. **Spam.** BEMA's 98.7% vs Jev's 96.1% rests on a model trained on in-distribution SMS. 88 of the test messages are verbatim training messages, and BEMA scores 100% on those. "
  "The majority-class baseline is 86.1%.")
P("6. **'Followed the injected label' measures different things for BEMA and the LLMs.** BEMA cannot read instructions. "
  "Its 17-34% 'following' rate comes from the target intent's words appearing in the text, and its defended rows are literally the same run as the undefended ones. "
  "Comparing BEMA with LLMs on this metric mixes lexical leakage with instruction-following.")
P("7. **The sampling setup is not identical across models.** The OpenRouter models (including Haiku) run at temperature 0. Sonnet, Opus and Fable, called directly, run at default sampling because the API rejects a temperature setting. "
  "Opus and Fable use adaptive thinking at low effort, while Sonnet has thinking off. The prompts are identical. The invalid-output rate depends on the parser: 0 vs 37 for Opus on mixed3 (check 3).")
P("8. **Cost.** Jev's $0.071 per 1,000 banking decisions assumes output tokens are free and uses a posted price. "
  "The Anthropic figures are tokens x list price (Opus $4.54 per 1,000, including thinking), not invoices. Only the OpenRouter figures are provider-reported. "
  "The headline spend leaves out $0.75 of set-aside runs.")
P("9. **Latency.** Jev's ~99 ms and the LLMs' 0.84-1.30 s (sequential medians) are client-side times from a cloud machine and include the network; the providers' routes differ "
  "(Haiku via OpenRouter on AWS; Sonnet, Opus and Fable direct). **The BEMA timings in `runs/bema/timing.json` are provisional.** They were measured while other jobs were running, "
  "and bema_baseline's 100 ms median (388 ms p90) for a 3-layer, 96-dimension encoder is clearly CPU contention, since the much larger MiniLM measured 12 ms. "
  "`results_summary.json` quotes no BEMA latency, but `report.json` (`bema_latency`) still quotes the contended numbers. "
  "A re-measurement, `runs/bema/timing_quiet.json`, appeared during this audit (13:44:26 local, 25 s after the training job ended): bema_baseline 1.70 ms, bema_v2 14.0 ms, bema_v2_spell 14.1 ms. "
  "Its `load_avg_at_start` of 1.71 on 2 cores is the tail of the killed job. As far as the timestamps show, none of my audit scripts was running then. "
  "Neither audited report uses that file yet, so I did not audit it.")
P("10. **'Zero-shot transfer from CLINC150'** comes from a source dataset with 17 banking-domain intents. It is cross-dataset, not cross-domain.")
P("11. **The typo-augmented BEMA model is absent.** `jev_clone_multitask_augmented_calibrated.pt` does not exist (its rebuild was terminated after epoch 1, per `runs/augment_rebuild.log`), "
  "so no current file backs the FINDINGS.md claims about the augmented model, which come from earlier runs.")
P("12. **Work in progress.** `bema_v2_full` (and the `bema_v3*` / `*_gpu` names) are listed in the report and summary code, but no prediction files exist for them. "
  "The full-training run was terminated during epoch 3. Any numbers produced later will be unaudited.")
P("")
P("## Regression check of the pass-1 fixes (Jev rows): PASS (63/63)")
P("In the regenerated reports, Jev's ECE now equals pass 1's exact-edge values: spam/clean 0.06575 and injection_oos_clinc 0.06138. "
  "The 0.0638 float32 value is kept as `ece_repo_float32_edges`. Accuracy CIs are Wilson intervals, and the spam precision of 0.7823 (32 false positives) is reported.")
P("")
P("## Files")
P("Scripts and raw outputs are in `runs/audit/pass2/`: `common.py`; `check1_bema_metrics.py` and `check1_reproduce.py`; `check1c_more_repro.py`; "
  "`check2_leakage.py`, `check2b_v1_temperature.py`, `check2c_more_temps.py`, `check2d_spell_rebuild.py` and `check2e_zs_clinc_temps.py`; "
  "`check3_llm.py`, `check3b_parser_policies.py`, `check3c_extra.py` and `check3d_repo_rule.py` (which writes `repo_rule/check3_llm.json`); `check4_summary.py`; "
  "`check5_context.py` and `check5b_heldout.py`; `check0_jev_regression.py`; and `write_md.py`, which writes this file.")
P("")
P("## Appendix: every metric checked (reported vs recomputed)")
P("")
P("Tolerances: 1e-9 for counts, rates, means and Wilson CIs; 1e-6 for ECE; 0.005 for bootstrap CIs, compared against my own bootstrap. "
  "LLM rows use my parser; their FAILs all PASS under the report's rule (`repo_rule/check3_llm.json`).")
for title, rows in (("A. report.json and redteam_report.json: BEMA and zero-shot", c1["rows"]), ("B. llm_report.json", l3["rows"]),
                    ("C. results_summary.json", s4["rows"]), ("D. Jev rows after the pass-1 fixes", c0)):
    P("")
    P(f"### {title} ({len(rows) - nfail(rows)}/{len(rows)} PASS)")
    P("")
    P("| section | metric | reported | recomputed | result |")
    P("|---|---|---|---|---|")
    for r in rows:
        res = r["result"]
        if res == "FAIL" and title.startswith("B."):
            res = "FAIL (parser policy; PASS under report rule)"
        P(f"| {f(r['section'])} | {f(r['metric'])} | {f(r['reported'])} | {f(r['ours'])} | {res} |")
open(f"{A}/AUDIT_PASS2.md", "w").write("\n".join(L) + "\n")
print("wrote", tot_rows, "rows,", tot_fail, "FAIL")
