"""Check 3: LLM baselines. Own item sets, own reply parser, own metrics; compared with runs/llm_report.json.
The repo's parse() is imported ONLY to list rows where the two parsers disagree."""
import glob
import json
import math
import os
import re
import statistics
import sys
from collections import Counter, defaultdict

from common import ROOT, P2, Cmp, cats, ece, mean, rj, sample_idx, sha, slice250, wilson

CATS = cats()
CATSET = set(CATS)
rep = json.load(open(f"{ROOT}/runs/llm_report.json"))
C = Cmp()
NOTES = {}

# ------------------------------------------------------------------ item sets, rebuilt independently
def core_items(task, cond):
    out = []
    for r in rj(f"{ROOT}/runs/inputs/{task}_{cond}.jsonl"):
        out.append({"key": str(r["idx"]), "state": r["text"], "kind": "banking" if task == "banking77" else "spam",
                    "gold": CATS[r["label"]] if task == "banking77" else int(r["label"]), "meta": {"idx": r["idx"]}})
    return out


def rt_items(name):
    return [{"key": r["key"], "state": r["state"], "kind": "banking", "gold": r["gold"], "meta": r["meta"]}
            for r in rj(f"{ROOT}/runs/redteam/inputs/{name}.jsonl")]


S250 = slice250()
TESTS = {f"banking77_{c}": (lambda c=c: core_items("banking77", c)) for c in ("clean", "swap2", "mixed3")}
TESTS.update({f"spam_{c}": (lambda c=c: core_items("spam", c)) for c in ("clean", "swap2")})
for n in ("injection_banking", "injection_control_banking", "injection_casual_banking", "injection_casual_defended_banking"):
    TESTS[n] = (lambda n=n: rt_items(n))
TESTS["latency_sequential"] = lambda: core_items("banking77", "clean")[:100]
for t in ("banking77_clean", "banking77_swap2", "injection_banking", "injection_control_banking",
          "injection_casual_banking", "injection_casual_defended_banking"):
    TESTS[f"{t}_s250"] = (lambda t=t: [it for it in TESTS[t]() if it["key"] in S250])
NOTES["slice250_n_keys"] = len(S250)
NOTES["slice250_distinct_gold_intents"] = len({CATS[r["label"]] for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl") if str(r["idx"]) in S250})
NOTES["slice250_clean_vs_full_sample_note"] = "keys drawn with random.Random(11).sample(sorted(Random(7).sample(range(3080),1000)),250)"


# ------------------------------------------------------------------ own parser
DEC = json.JSONDecoder()


def json_objects(text):
    objs = []
    for m in re.finditer(r"\{", text):
        try:
            o, end = DEC.raw_decode(text, m.start())
        except ValueError:
            continue
        if isinstance(o, dict):
            objs.append(o)
    return objs


def num(x):
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x) if math.isfinite(x) else None
    if isinstance(x, str):
        try:
            v = float(x.strip())
            return v if math.isfinite(v) else None
        except ValueError:
            return None
    return None


def my_parse(content, kind):
    """-> dict(valid, pred, conf, reason). Banking: last JSON object with an 'intent' key; the intent must be
    a string that, stripped of surrounding whitespace, is EXACTLY one of the 77 labels. Confidence is used only
    if it is a number in [0, 1]. Spam: last JSON object with 'p_spam', a number in [0, 1]."""
    text = content or ""
    if not text.strip():
        return {"valid": False, "pred": None, "conf": None, "reason": "empty"}
    objs = json_objects(text)
    key = "p_spam" if kind == "spam" else "intent"
    cand = [o for o in objs if key in o]
    if not cand:
        return {"valid": False, "pred": None, "conf": None, "reason": "no JSON object with key" if not objs else f"JSON without '{key}'"}
    o = cand[-1]
    multi = len(cand) > 1
    if kind == "spam":
        p = num(o["p_spam"])
        if p is None or not (0 <= p <= 1):
            return {"valid": False, "pred": None, "conf": None, "reason": "p_spam not a number in [0,1]", "multi": multi}
        return {"valid": True, "pred": int(p > 0.5), "conf": max(p, 1 - p), "p": p, "reason": "ok", "multi": multi}
    it = o["intent"]
    if not isinstance(it, str):
        return {"valid": False, "pred": None, "conf": None, "reason": "intent not a string", "multi": multi}
    it = it.strip()
    c = num(o.get("confidence"))
    conf_ok = c is not None and 0 <= c <= 1
    if it not in CATSET:
        return {"valid": False, "pred": it, "conf": None, "reason": "intent not one of the 77 labels", "multi": multi,
                "case_or_space_variant_of_label": next((k for k in CATS if k.lower() == it.lower().replace(" ", "_")), None)}
    return {"valid": True, "pred": it, "conf": c if conf_ok else None, "reason": "ok" if conf_ok else
            ("confidence missing" if c is None else "confidence outside [0,1]"), "multi": multi, "raw_conf": c}


def main():
    # repo parser, imported only to diff row by row
    os.chdir(ROOT)
    sys.path.insert(0, ROOT)
    import llm_baseline as L  # noqa: E402

    PRICES = {"claude-sonnet-5-5": (2.0, 10.0), "claude-opus-5-5": (4.0, 20.0), "claude-fable-5-1": (10.0, 50.0)}
    DISAGREE = []
    COST = defaultdict(Counter)
    OUTSIDE = {}
    REASONS = defaultdict(Counter)
    MYRES = {}

    for model, M in rep["models"].items():
        for test, T in M.items():
            items = TESTS[test]()
            by = {it["key"]: it for it in items}
            path = f"{ROOT}/runs/llm/{model}/{test}.jsonl"
            allrecs = rj(path)
            OUTSIDE[f"{model}/{test}"] = {"records": len(allrecs), "ok": sum(r["status"] == "ok" for r in allrecs),
                                          "ok_keys_outside_item_set": sum(1 for r in allrecs if r["status"] == "ok" and r["key"] not in by),
                                          "dup_ok_keys": sum(v - 1 for v in Counter(r["key"] for r in allrecs if r["status"] == "ok").values() if v > 1),
                                          "sha_mismatch": sum(1 for r in allrecs if r["status"] == "ok" and r["key"] in by and r["state_sha256"] != sha(by[r["key"]]["state"]))}
            recs = {}
            for r in allrecs:
                if r["status"] == "ok" and r["key"] in by:
                    recs[r["key"]] = r
            kind = items[0]["kind"]
            rows = []
            for it in items:
                r = recs.get(it["key"])
                if r is None:
                    continue
                P = my_parse(r.get("content"), kind)
                REASONS[f"{model}/{test}"][P["reason"]] += 1
                correct = float(P["valid"] and P["pred"] == it["gold"])
                # repo parse, for the diff
                rp = L.parse(r.get("content"), "spam" if kind == "spam" else "banking")
                r_pred, r_conf, r_valid = rp[0], rp[1], rp[2]
                r_correct = float(bool(r_valid) and r_pred == it["gold"])
                used_conf_repo = r_conf if (r_valid and r_conf is not None) else None
                if (bool(r_valid) != P["valid"]) or (r_correct != correct) or \
                        ((used_conf_repo is None) != (P["conf"] is None)) or \
                        (used_conf_repo is not None and P["conf"] is not None and abs(used_conf_repo - P["conf"]) > 1e-12):
                    DISAGREE.append({"model": model, "test": test, "key": it["key"], "gold": it["gold"],
                                     "repo": {"valid": bool(r_valid), "pred": r_pred, "conf": r_conf},
                                     "audit": {k: P.get(k) for k in ("valid", "pred", "conf", "reason")},
                                     "content": (r.get("content") or "")[:600]})
                rows.append((it, r, P, correct))
                u = r.get("usage") or {}
                if "/" not in r["model"]:   # Anthropic direct
                    raw = u.get("raw") or {}
                    pin, pout = PRICES[r["model"]]
                    mine = (raw.get("input_tokens", 0) * pin + raw.get("output_tokens", 0) * pout) / 1e6
                    th = (raw.get("output_tokens_details") or {}).get("thinking_tokens", 0) or 0
                    COST[model]["records"] += 1
                    COST[model]["cost_ne_tokens_x_price"] += abs(mine - float(u.get("cost") or 0)) > 1e-12
                    COST[model]["thinking_tokens"] += th
                    COST[model]["records_with_thinking"] += th > 0
                    COST[model]["output_tokens_lt_thinking_tokens"] += raw.get("output_tokens", 0) < th
                    COST[model]["cache_tokens_nonzero"] += bool(raw.get("cache_creation_input_tokens") or raw.get("cache_read_input_tokens"))
                    COST[model]["prompt_tokens_ne_raw_input"] += u.get("prompt_tokens") != raw.get("input_tokens")
                    COST[model]["completion_tokens_ne_raw_output"] += u.get("completion_tokens") != raw.get("output_tokens")
                else:
                    COST[model]["records"] += 1
                    COST[model]["cost_missing"] += u.get("cost") is None
                    cd = u.get("cost_details") or {}
                    if cd.get("upstream_inference_cost") is not None:
                        COST[model]["cost_ne_upstream_cost"] += abs(float(u["cost"]) - float(cd["upstream_inference_cost"])) > 1e-9
                    COST[model]["reasoning_tokens"] += ((u.get("completion_tokens_details") or {}).get("reasoning_tokens") or 0)
            # ---- metrics
            n = len(rows)
            corr = [c for *_, c in rows]
            inv = sum(1 for _, _, P, _ in rows if not P["valid"])
            wc = [(c, P["conf"]) for _, _, P, c in rows if P["valid"] and P["conf"] is not None]
            res = {"n": n, "n_missing": len(items) - n, "invalid_output": inv, "invalid_output_rate": inv / n,
                   "accuracy_invalid_counted_wrong": sum(corr) / n, "accuracy_ci95": wilson(sum(corr), n)}
            if wc:
                res.update({"n_with_confidence": len(wc), "mean_stated_confidence": mean(c for _, c in wc),
                            "accuracy_on_those": mean(a for a, _ in wc), "ece_stated_confidence": ece([c for _, c in wc], [a for a, _ in wc])})
                res["overconfidence"] = res["mean_stated_confidence"] - res["accuracy_on_those"]
            if test.startswith("injection") and items[0]["meta"].get("target"):
                res["followed_injected_label"] = mean(float(P["pred"] == it["meta"]["target"]) for it, _, P, _ in rows)
            lat = sorted(float(r["latency_ms"]) for _, r, _, _ in rows)
            res["latency_ms"] = {"median": statistics.median(lat), "p90": lat[int(0.9 * len(lat))]}
            cost = sum(float((r.get("usage") or {}).get("cost") or 0) for _, r, _, _ in rows)
            res["cost_usd"] = cost
            res["cost_per_1000_calls_usd"] = 1000 * cost / n
            res["mean_prompt_tokens"] = mean((r.get("usage") or {}).get("prompt_tokens") or 0 for _, r, _, _ in rows)
            res["mean_output_tokens"] = mean((r.get("usage") or {}).get("completion_tokens") or 0 for _, r, _, _ in rows)
            res["reasoning_tokens_total"] = sum(((r.get("usage") or {}).get("completion_tokens_details") or {}).get("reasoning_tokens", 0) or 0
                                                for _, r, _, _ in rows) + \
                sum((((r.get("usage") or {}).get("raw") or {}).get("output_tokens_details") or {}).get("thinking_tokens", 0) or 0 for _, r, _, _ in rows)
            res["providers"] = sorted({str(r.get("provider")) for _, r, _, _ in rows})
            # Qwen token probability of the chosen intent (own span logic)
            if any(r.get("token_logprobs") for _, r, _, _ in rows) and kind != "spam":
                tp = []
                for it, r, P, c in rows:
                    lp = r.get("token_logprobs")
                    if not (P["valid"] and lp):
                        continue
                    text, spans = "", []
                    for tok, l in lp:
                        spans.append((len(text), len(text) + len(tok), l))
                        text += tok
                    m = re.search(r'"intent"\s*:\s*"([^"]*)"', text)
                    if not m or m.group(1).strip() != P["pred"]:
                        j = text.find(f'"{P["pred"]}"')
                        if j < 0:
                            continue
                        s, e = j + 1, j + 1 + len(P["pred"])
                    else:
                        s, e = m.span(1)
                    tp.append((c, math.exp(sum(l for a, b, l in spans if a < e and b > s))))
                if tp:
                    res["ece_token_probability"] = ece([q for _, q in tp], [a for a, _ in tp])
                    res["mean_token_probability"] = mean(q for _, q in tp)
                    res["n_token_probability"] = len(tp)
            MYRES[f"{model}/{test}"] = res
            sec = f"llm {model}/{test}"
            for k in ["n", "n_missing", "invalid_output", "invalid_output_rate", "accuracy_invalid_counted_wrong",
                      "n_with_confidence", "mean_stated_confidence", "accuracy_on_those", "overconfidence",
                      "followed_injected_label", "cost_usd", "cost_per_1000_calls_usd", "mean_prompt_tokens",
                      "mean_output_tokens", "reasoning_tokens_total", "mean_token_probability", "n_token_probability"]:
                if k in T or k in res:
                    C.add(sec, k, T.get(k), res.get(k))
            for k in ["ece_stated_confidence", "ece_token_probability"]:
                if k in T or k in res:
                    C.add(sec, k, T.get(k), res.get(k), 1e-6)
            C.add(sec, "accuracy_ci95 (Wilson)", T["accuracy_ci95"], res["accuracy_ci95"])
            C.add(sec, "latency median", T["latency_ms"]["median"], res["latency_ms"]["median"])
            C.add(sec, "latency p90 (index rule)", T["latency_ms"]["p90"], res["latency_ms"]["p90"])
            C.add(sec, "providers", json.dumps(T["providers"]), json.dumps(res["providers"]))

    # files present but not in the report
    for p in glob.glob(f"{ROOT}/runs/llm/*/*.jsonl"):
        m, t = p.split("/")[-2], os.path.basename(p)[:-6]
        if m not in rep["models"] or t not in rep["models"][m]:
            NOTES.setdefault("llm_files_not_in_report", []).append(f"{m}/{t}")
    # s250 files: are their keys exactly the slice?
    NOTES["s250_files_keys_equal_slice"] = {}
    for p in glob.glob(f"{ROOT}/runs/llm/*/*_s250.jsonl"):
        ks = {r["key"] for r in rj(p) if r["status"] == "ok"}
        NOTES["s250_files_keys_equal_slice"][p.split("runs/llm/")[1]] = ks == S250
    # totals
    tot = defaultdict(float)
    for p in glob.glob(f"{ROOT}/runs/llm/*/*.jsonl"):
        for r in rj(p):
            if r.get("status") == "ok":
                tot["anthropic" if "/" not in r.get("model", "") else "openrouter"] += float((r.get("usage") or {}).get("cost") or 0)
    C.add("llm totals", "total_cost_usd", rep["total_cost_usd"], tot["openrouter"] + tot["anthropic"])
    C.add("llm totals", "cost_by_provider openrouter", rep["cost_by_provider_usd"]["openrouter"], tot["openrouter"])
    C.add("llm totals", "cost_by_provider anthropic", rep["cost_by_provider_usd"]["anthropic"], tot["anthropic"])
    C.add("llm totals", "mock flag", rep["mock"], False)
    # excluded set-aside runs: what they cost (not counted)
    aside = defaultdict(float)
    for p in glob.glob(f"{ROOT}/runs/llm_partial_ratelimited/**/*.jsonl", recursive=True):
        for r in rj(p):
            if r.get("status") == "ok":
                aside[p.split("llm_partial_ratelimited/")[1]] += float((r.get("usage") or {}).get("cost") or 0)
    NOTES["llm_partial_ratelimited_cost_not_counted"] = dict(aside)
    NOTES["llm_partial_ratelimited_records"] = {p.split("llm_partial_ratelimited/")[1]: len(rj(p))
                                                for p in glob.glob(f"{ROOT}/runs/llm_partial_ratelimited/**/*.jsonl", recursive=True)}
    # lenient-parser sensitivity: what if case/space variants of a label were accepted?
    len_fix = Counter()
    for d in DISAGREE:
        pass
    for key, rs in REASONS.items():
        pass

    json.dump({"rows": C.rows, "my_results": MYRES, "disagreements": DISAGREE, "cost_checks": {k: dict(v) for k, v in COST.items()},
               "record_checks": OUTSIDE, "parse_reasons": {k: dict(v) for k, v in REASONS.items()}, "notes": NOTES},
              open(f"{P2}/check3_llm.json", "w"), indent=1, default=str)
    fails = [r for r in C.rows if r["result"] == "FAIL"]
    print(f"{len(C.rows)} rows, {len(fails)} FAIL")
    for r in fails:
        print(r["section"], "|", r["metric"], "|", r["reported"], "|", r["ours"])
    print("disagreements:", len(DISAGREE), Counter((d["model"], d["test"]) for d in DISAGREE))
    print(json.dumps({k: dict(v) for k, v in COST.items()}, indent=0))
    bad = {k: v for k, v in OUTSIDE.items() if v["ok_keys_outside_item_set"] or v["dup_ok_keys"] or v["sha_mismatch"]}
    print("record problems", bad)
    print(json.dumps(NOTES, indent=0)[:3000])



if __name__ == "__main__":
    main()
