"""Check 3c: (a) were latency_sequential calls really one at a time (no overlap in wall-clock)?
(b) per-section summary of the LLM rows that FAIL against the report, for the write-up."""
import json, glob
from datetime import datetime, timedelta
from common import ROOT, P2, rj
out = {"sequential_overlap": {}}
for p in sorted(glob.glob(f"{ROOT}/runs/llm/*/latency_sequential.jsonl")) + [f"{ROOT}/runs/redteam/jev/latency_sequential_banking.jsonl"]:
    rs = [r for r in rj(p) if r["status"] == "ok"]
    iv = sorted((datetime.fromisoformat(r["ts_utc"]) - timedelta(milliseconds=r["latency_ms"]), datetime.fromisoformat(r["ts_utc"])) for r in rs)
    ov = sum(1 for a, b in zip(iv, iv[1:]) if b[0] < a[1] - timedelta(milliseconds=50))
    out["sequential_overlap"][p.split("runs/")[1]] = {"calls": len(rs), "overlapping_pairs_gt_50ms": ov,
                                                       "wall_span_s": (iv[-1][1] - iv[0][0]).total_seconds()}
d = json.load(open(f"{P2}/check3_llm.json"))
fails = [r for r in d["rows"] if r["result"] == "FAIL"]
sec = {}
for r in fails:
    sec.setdefault(r["section"], {})[r["metric"]] = [r["reported"], r["ours"]]
out["llm_fail_sections"] = sec
json.dump(out, open(f"{P2}/check3c_extra.json", "w"), indent=1, default=str)
print(json.dumps(out["sequential_overlap"], indent=0))
for s, v in sec.items():
    print(s, {k: v[k] for k in v if k in ("invalid_output", "accuracy_invalid_counted_wrong", "mean_stated_confidence", "ece_stated_confidence")})
