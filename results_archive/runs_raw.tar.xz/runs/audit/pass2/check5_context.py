"""Check 5: numbers for the 'what an interviewer would attack' list: paired Jev-vs-model differences with
CIs on identical keys, Amazon train/test overlap effect on BEMA, and slice250 vs full-set difficulty."""
import json, pickle, re
import numpy as np
from common import ROOT, P2, rj, cats, mean, boot, wilson, slice250, pearson
import check4_summary as S4   # loaders only (module-level run prints; acceptable)
K = slice250()
out = {"paired_vs_jev": {}}
jc = S4.jev_core("banking77", "clean")
js = S4.jev_core("banking77", "swap2")
def paired(a, b, keys):
    d = [a[k][0] - b[k][0] for k in keys]
    return {"n": len(d), "model_minus_jev_pp": round(100 * mean(d), 2), "ci95_pp": [round(100 * x, 2) for x in boot(d, B=4000, seed=5)]}
for m, t in [("claude-opus-5.5", "banking77_clean"), ("claude-sonnet-5.5", "banking77_clean"), ("claude-haiku-5.5", "banking77_clean"),
             ("qwen3.8-flash", "banking77_clean")]:
    d = S4.llm(m, t, S4.own)
    out["paired_vs_jev"][f"{m} full clean"] = paired(d, jc, sorted(d))
for m, t in [("gpt-6.1-terra", "banking77_clean_s250"), ("gpt-6-luna", "banking77_clean_s250"), ("claude-fable-5.1", "banking77_clean_s250")]:
    d = S4.llm(m, t, S4.own)
    out["paired_vs_jev"][f"{m} slice250 clean"] = paired(d, jc, sorted(d))
for m in ["bema_v2", "bema_v2_spell", "bema_baseline", "zs_offshelf", "zs_from_clinc", "zs_offshelf_bge_base"]:
    d = S4.bema_core(m, "banking77", "clean")
    out["paired_vs_jev"][f"{m} full clean"] = paired(d, jc, sorted(d))
    d2 = S4.bema_core(m, "banking77", "swap2")
    out["paired_vs_jev"][f"{m} full swap2"] = paired(d2, js, sorted(d2))
for m in ["claude-opus-5.5", "claude-sonnet-5.5"]:
    for c in ["swap2", "mixed3"]:
        d = S4.llm(m, f"banking77_{c}", S4.own)
        out[f"{m} banking77_{c} accuracy"] = mean(v[0] for v in d.values())
out["jev accuracy: full 3080 vs slice250 vs 1000-sample"] = [mean(v[0] for v in jc.values()), mean(jc[k][0] for k in K),
                                                            mean(jc[str(i)][0] for i in __import__("common").sample_idx())]
out["slice250 wilson halfwidth at 80%"] = (lambda lo, hi: round(50 * (hi - lo), 1))(*wilson(200, 250))
# Amazon overlap and BEMA score metrics
d = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
norm = lambda t: re.sub(r"\s+", " ", t.strip().lower())
tr = {norm(r["text"]) for r in d["score"]["train"]}
items = rj(f"{ROOT}/runs/redteam/inputs/score_amazon_clean.jsonl")
ov = {it["key"] for it in items if norm(it["state"]) in tr}
for m in ["bema_baseline", "bema_v2"]:
    P = {r["key"]: r["stars_expected"] for r in rj(f"{ROOT}/runs/redteam/bema/score_amazon_clean__{m}.jsonl")}
    g = {it["key"]: it["gold"] for it in items}
    a = [k for k in g if k not in ov]
    out[f"{m} amazon clean: r all / r unseen-only / MAE all / MAE unseen-only"] = [
        pearson([P[k] for k in g], [g[k] for k in g]), pearson([P[k] for k in a], [g[k] for k in a]),
        mean(abs(P[k] - g[k]) for k in g), mean(abs(P[k] - g[k]) for k in a)]
out["amazon test rows overlapping train"] = len(ov)
json.dump(out, open(f"{P2}/check5_context.json", "w"), indent=1)
print(json.dumps(out, indent=1))
