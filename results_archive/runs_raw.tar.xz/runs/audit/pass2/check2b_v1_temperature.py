"""Check 2b: reproduce bema_baseline's stored temperatures with the repo's own fitting recipe
(T init 1.5, LBFGS lr=0.01, max_iter=200, direct T), on VAL and on TEST, to identify the split used."""
import json, pickle, sys, torch, torch.nn as nn
torch.set_num_threads(1)
from common import ROOT, P2
sys.path.insert(0, ROOT)
from model import JevCloneEncoder
data = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
m = JevCloneEncoder(vocab_size=data["vocab_size"], max_len=data["max_len"], num_choice_classes=77, enable_score=True)
m.load_state_dict(torch.load(f"{ROOT}/jev_clone_multitask_calibrated.pt", map_location="cpu")); m.eval()
def logits(rows, head):
    with torch.no_grad():
        out = []
        for s in range(0, len(rows), 64):
            ids = torch.tensor([r["ids"] for r in rows[s:s+64]]); mk = torch.tensor([r["mask"] for r in rows[s:s+64]])
            out.append(m.choice_head(m.encode(ids, mk)) if head == "choice" else m.forward(ids, mk))
        return torch.cat(out)
def repo_fit(lg, y, binary):
    T = nn.Parameter(torch.ones(1) * 1.5); opt = torch.optim.LBFGS([T], lr=0.01, max_iter=200)
    lf = nn.BCEWithLogitsLoss() if binary else nn.CrossEntropyLoss()
    def cl():
        opt.zero_grad(); l = lf(lg / T, y.float() if binary else y); l.backward(); return l
    opt.step(cl); return T.item()
out = {"checkpoint": {"choice": float(m.choice_temperature), "noul": float(m.temperature)}}
for head, b in (("choice", False), ("noul", True)):
    for split in ("val", "test"):
        rows = data[head][split]
        out[f"{head} repo-recipe fit on {split}"] = repo_fit(logits(rows, head), torch.tensor([int(r["label"]) for r in rows]), b)
json.dump(out, open(f"{P2}/check2b_v1_temperature.json", "w"), indent=1); print(json.dumps(out, indent=1))
