"""Compare reported Jev numbers (runs/report.json, runs/redteam_report.json) with audit_metrics.json."""
import json

ROOT = "/home/claude/mit37/bema"
rep = json.load(open(f"{ROOT}/runs/report.json"))
rrep = json.load(open(f"{ROOT}/runs/redteam_report.json"))
mine = json.load(open(f"{ROOT}/runs/audit/audit_metrics.json"))

TOL = {"default": 1e-9, "ece": 1e-3, "ci": 5e-3}
rows = []


def add(section, metric, reported, ours, kind="default"):
    if isinstance(reported, list):
        ok = all(abs(a - b) <= TOL[kind] for a, b in zip(reported, ours))
    elif isinstance(reported, bool) or isinstance(reported, str):
        ok = reported == ours
    elif reported is None or ours is None:
        ok = reported is None and ours is None
    else:
        ok = abs(reported - ours) <= TOL[kind]
    rows.append({"section": section, "metric": metric, "reported": reported, "ours": ours,
                 "tol": TOL[kind] if not isinstance(reported, (bool, str)) else "exact",
                 "result": "PASS" if ok else "FAIL"})


# ---------------- core
for task, conds in rep["tasks"].items():
    for c, res in conds.items():
        R, M = res["jev"], mine["core"]["tasks"][task][c]
        sec = f"core {task}/{c}"
        for k in ["n", "accuracy", "mean_confidence", "overconfidence", "n_missing", "n_failed_calls",
                  "accuracy_drop_from_clean", "confidence_drop_from_clean"]:
            if k in R:
                add(sec, k, R[k], M[k])
        add(sec, "ece (spec: exact decimal bin edges)", R["ece"], M["ece"], "ece")
        if "ece_using_jev_confidence_field" in R:
            add(sec, "ece_using_jev_confidence_field", R["ece_using_jev_confidence_field"],
                M["ece_using_jev_confidence_field"], "ece")
        add(sec, "accuracy_ci95 (own bootstrap, 10k, seed 2026)", R["accuracy_ci95"], M["accuracy_ci95"], "ci")
L, ML = rep["jev_latency_ms"], mine["core"]["jev_latency_ms"]
add("core latency", "n", L["n"], ML["n"])
add("core latency", "median_ms", L["median"], ML["median"])
add("core latency", "p90_ms (index rule s[int(0.9n)])", L["p90"], ML["p90_index_rule"])
add("core latency", "p99_ms (index rule s[int(0.99n)])", L["p99"], ML["p99_index_rule"])
add("core cost", "input_tokens", rep["jev_cost"]["input_tokens"], mine["core"]["jev_cost"]["input_tokens"])
add("core cost", "usd", rep["jev_cost"]["usd"], mine["core"]["jev_cost"]["usd"])
add("core", "jev_failed_calls_total", rep["jev_failed_calls_total"], 0)
add("core", "model versions", json.dumps(rep["jev_model_versions_reported"]), json.dumps({"jev-1.14.0": ML["n"]}))
add("core", "mock flag", rep["mock"], False)

# ---------------- red team
T = rrep["tests"]
MR = mine["redteam"]
generic = ["n", "n_missing", "accuracy", "mean_confidence", "overconfidence", "clean_accuracy_same_examples",
           "followed_injected_label", "mean_confidence_when_following_injection",
           "share_following_injection_with_confidence_ge_0.9", "picked_target_without_injection",
           "mean_p_spam", "clean_recall_same_examples", "same_answer_as_original_order",
           "mean_abs_change_in_p_gold", "n_queries", "calls", "share_same_answer_all_repeats",
           "share_identical_probabilities_all_repeats", "mean_confidence_spread_max_minus_min",
           "pearson_r_expected_stars", "mae_stars_expected", "exact_star_accuracy_argmax",
           "within_one_star_argmax", "in_scope_accuracy", "oos_recall", "false_oos_rate_on_in_scope",
           "n_in_scope", "n_oos", "said_oos_with_note", "said_oos_without_note_same_requests",
           "clean_accuracy_same_requests", "median_latency_ms", "p90_latency_ms"]
for name, R in T.items():
    J, M = R["jev"], MR[name]["jev"]
    sec = f"redteam {name}"
    if name == "gibberish_banking":
        for kd, v in J.items():
            for k in ["n", "mean_confidence", "share_confidence_ge_0.9", "share_confidence_ge_0.5"]:
                add(sec, f"{kd}: {k}", v[k], M[kd][k])
    elif name == "question_count":
        for nq, v in J.items():
            if nq == "latency_ratio_16_vs_1":
                add(sec, nq, v, M[nq])
                continue
            add(sec, f"n={nq}: calls", v["calls"], M[nq]["calls"])
            add(sec, f"n={nq}: median_latency_ms", v["median_latency_ms"], M[nq]["median_latency_ms"])
            add(sec, f"n={nq}: p90_latency_ms", v["p90_latency_ms"], M[nq]["p90_latency_ms_index_rule"])
            add(sec, f"n={nq}: mean_input_tokens", v["mean_input_tokens"], M[nq]["mean_input_tokens"])
            add(sec, f"n={nq}: all_questions_answered", v["all_questions_answered"], M[nq]["all_questions_answered"])
    else:
        for k in generic:
            if k in J:
                add(sec, k, J[k], M[k])
        if "ece" in J:
            add(sec, "ece", J["ece"], M["ece"], "ece")
        if "ece_argmax" in J:
            add(sec, "ece_argmax", J["ece_argmax"], M["ece_argmax"], "ece")
        if "accuracy_ci95" in J:
            add(sec, "accuracy_ci95", J["accuracy_ci95"], M["accuracy_ci95"], "ci")
        if "gold_distribution" in R:
            add(sec, "gold_distribution", json.dumps(R["gold_distribution"]), json.dumps(MR[name]["gold_distribution"]))
    jc, mc = R["jev_calls"], MR[name]["jev_calls"]
    add(sec, "calls.ok", jc["ok"], mc["ok"])
    add(sec, "calls.input_tokens", jc["input_tokens"], mc["input_tokens"])
    add(sec, "calls.median_latency_ms", jc["median_latency_ms"], mc["median_latency_ms"])
    add(sec, "calls.model_versions", json.dumps(jc["model_versions"]), json.dumps(mc["model_versions"]))
add("redteam cost", "input_tokens", rrep["redteam_cost"]["input_tokens"], mine["redteam_cost"]["input_tokens"])
add("redteam cost", "usd", rrep["redteam_cost"]["usd"], mine["redteam_cost"]["usd"])
add("redteam", "mock flag", rrep["mock"], False)

json.dump(rows, open(f"{ROOT}/runs/audit/comparison.json", "w"), indent=1)
fails = [r for r in rows if r["result"] == "FAIL"]
print(f"{len(rows)} checks, {len(fails)} FAIL")
for r in fails:
    print(r)
