"""Extra probes for check F (misleading-ness), written from scratch."""
import json
import random
import statistics
from collections import Counter

import numpy as np

ROOT = "/home/claude/mit37/bema"


def rj(p):
    return [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]


CATS = json.load(open(f"{ROOT}/runs/inputs/categories.json"))
OUT = {}

# 1. Jev's own `confidence` field vs probabilities[choice]
recs = rj(f"{ROOT}/runs/jev/banking77_clean.jsonl")
diffs = []
ex = []
for r in recs:
    a = r["response"]["answers"]["intent"]
    pc = a["probabilities"][a["choice"]]
    if abs(a["confidence"] - pc) > 1e-9:
        diffs.append(a["confidence"] - pc)
        if len(ex) < 4:
            top = sorted(a["probabilities"].items(), key=lambda kv: -kv[1])[:3]
            ex.append({"idx": r["idx"], "choice": a["choice"], "confidence_field": a["confidence"], "p_choice": pc, "top3": top})
OUT["confidence_field_vs_p_choice"] = {"n_differ": len(diffs), "mean_diff": float(np.mean(diffs)),
                                       "min_diff": float(min(diffs)), "max_diff": float(max(diffs)),
                                       "share_field_higher": float(np.mean(np.array(diffs) > 0)), "examples": ex}

# 2. choice not argmax / ties in banking clean
inp = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")}
na = []
ties = []
for r in recs:
    a = r["response"]["answers"]["intent"]
    p = a["probabilities"]
    mx = max(p.values())
    g = CATS[inp[r["idx"]]["label"]]
    if p[a["choice"]] < mx:
        na.append({"idx": r["idx"], "choice": a["choice"], "p_choice": p[a["choice"]],
                   "argmax": max(p, key=p.get), "p_max": mx, "gold": g})
    tops = [k for k, v in p.items() if v == mx]
    if len(tops) > 1:
        ties.append({"idx": r["idx"], "tied": tops, "choice": a["choice"], "gold": g,
                     "gold_in_tie": g in tops, "choice_correct": a["choice"] == g})
OUT["banking_clean_choice_not_argmax"] = na
OUT["banking_clean_argmax_ties"] = ties
# accuracy if argmax (first in option order) were used instead of `choice`
alt = sum(1 for r in recs if max(r["response"]["answers"]["intent"]["probabilities"],
                                  key=r["response"]["answers"]["intent"]["probabilities"].get) == CATS[inp[r["idx"]]["label"]])
OUT["banking_clean_accuracy_if_argmax_used"] = alt / len(recs)


# 3. paired bootstrap CIs for accuracy drops (clean - condition) + discordant counts
def correct_map(task, cond):
    I = {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{task}_{cond}.jsonl")}
    out = {}
    for r in rj(f"{ROOT}/runs/jev/{task}_{cond}.jsonl"):
        if r["status"] != "ok":
            continue
        if task == "banking77":
            out[r["idx"]] = float(r["response"]["answers"]["intent"]["choice"] == CATS[I[r["idx"]]["label"]])
        else:
            p = r["response"]["answers"]["is_spam"]["noul"]
            out[r["idx"]] = float((1 if p > 0.5 else 0) == I[r["idx"]]["label"])
    return out


def conf_map(task, cond):
    out = {}
    for r in rj(f"{ROOT}/runs/jev/{task}_{cond}.jsonl"):
        if task == "banking77":
            a = r["response"]["answers"]["intent"]
            out[r["idx"]] = a["probabilities"][a["choice"]]
        else:
            p = r["response"]["answers"]["is_spam"]["noul"]
            out[r["idx"]] = max(p, 1 - p)
    return out


rng = np.random.default_rng(7)
drops = {}
for task, conds in (("banking77", ["swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["swap2", "keyboard2", "mixed3"])):
    c0 = correct_map(task, "clean")
    k0 = conf_map(task, "clean")
    for c in conds:
        c1 = correct_map(task, c)
        k1 = conf_map(task, c)
        ids = sorted(c0)
        d = np.array([c0[i] - c1[i] for i in ids])
        dc = np.array([k0[i] - k1[i] for i in ids])
        bi = rng.integers(0, len(d), size=(10000, len(d)))
        bm = d[bi].mean(1)
        bc = dc[bi].mean(1)
        drops[f"{task}_{c}"] = {"acc_drop": float(d.mean()), "acc_drop_ci95": [float(np.percentile(bm, 2.5)), float(np.percentile(bm, 97.5))],
                                "conf_drop": float(dc.mean()), "conf_drop_ci95": [float(np.percentile(bc, 2.5)), float(np.percentile(bc, 97.5))],
                                "right_to_wrong": int((d == 1).sum()), "wrong_to_right": int((d == -1).sum())}
OUT["paired_drop_cis"] = drops

# 4. noise floor: two clean-input calls of the same query disagree how often?
core = {r["idx"]: r["response"]["answers"]["intent"]["choice"] for r in recs}
rep = rj(f"{ROOT}/runs/redteam/jev/repeat_banking.jsonl")
rep_in = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/repeat_banking.jsonl")}
g = {}
for r in rep:
    it = rep_in[r["key"]]
    g.setdefault(it["meta"]["idx"], []).append(r["response"]["answers"]["intent"]["choice"])
pair_dis = []
for i, v in g.items():
    for a in range(len(v)):
        for b in range(a + 1, len(v)):
            pair_dis.append(float(v[a] != v[b]))
core_dis = [float(x != core[i]) for i, v in g.items() for x in v]
rep_cats = Counter(CATS[inp[i]["label"]] for i in g)
OUT["repeat_noise_floor"] = {"pairwise_disagreement_between_repeats": float(np.mean(pair_dis)),
                             "repeat_vs_core_clean_disagreement": float(np.mean(core_dis)),
                             "repeat_queries_idx_range": [min(g), max(g)],
                             "n_distinct_intents_covered": len(rep_cats), "intents": sorted(rep_cats)}
# order shuffle restricted to the same 200 queries
sh_in = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/order_shuffle_banking.jsonl")}
sh = {sh_in[r["key"]]["meta"]["idx"]: r for r in rj(f"{ROOT}/runs/redteam/jev/order_shuffle_banking.jsonl")}
sh_dis_all = np.mean([float(r["response"]["answers"]["intent"]["choice"] != core[i]) for i, r in sh.items()])
sh_dis_200 = np.mean([float(sh[i]["response"]["answers"]["intent"]["choice"] != core[i]) for i in g if i in sh])
OUT["order_shuffle_vs_noise"] = {"shuffle_vs_core_disagreement_all_1000": float(sh_dis_all),
                                 "shuffle_vs_core_disagreement_on_200_repeat_queries": float(sh_dis_200),
                                 "plain_repeat_vs_core_disagreement_same_200": float(np.mean(core_dis))}
# was the shuffled option order actually what was sent? Response key order should follow it.
match = 0
for i, r in sh.items():
    cats = CATS[:]
    random.Random(f"order-{i}").shuffle(cats)
    match += list(r["response"]["answers"]["intent"]["probabilities"]) == cats
OUT["order_shuffle_response_key_order_matches_expected_shuffle"] = f"{match}/{len(sh)}"

# 5. latency breakdown (core pooled across tasks with concurrency 8)
lat = {}
for task, conds in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    L = [r["latency_ms"] for c in conds for r in rj(f"{ROOT}/runs/jev/{task}_{c}.jsonl")]
    lat[task] = {"n": len(L), "median": statistics.median(L), "max": max(L)}
OUT["core_latency_by_task"] = lat
seq = sorted(r["ts_utc"] for r in rj(f"{ROOT}/runs/redteam/jev/latency_sequential_banking.jsonl"))
OUT["latency_sequential_first_last_ts"] = [seq[0], seq[-1]]

# 6. tokens: output tokens are large; cost depends entirely on "$0 output"
tin = tout = 0
for task, conds in (("banking77", ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]),
                    ("spam", ["clean", "swap2", "keyboard2", "mixed3"])):
    for c in conds:
        for r in rj(f"{ROOT}/runs/jev/{task}_{c}.jsonl"):
            tin += r["response"]["usage"]["input_tokens"]
            tout += r["response"]["usage"]["output_tokens"]
OUT["core_tokens"] = {"input": tin, "output": tout, "usd_input_only": tin / 1e6 * 0.042,
                      "usd_if_output_billed_at_input_rate": (tin + tout) / 1e6 * 0.042}
man = json.load(open(f"{ROOT}/runs/jev/manifest.json"))
OUT["manifest_price"] = {k: man.get(k) for k in ("price_per_million_input_tokens_usd", "price_source", "model_requested", "mock")}

# 7. spam: duplicates, class balance, the single p==0.5 case
sp = rj(f"{ROOT}/runs/inputs/spam_clean.jsonl")
sj = {r["idx"]: r["response"]["answers"]["is_spam"]["noul"] for r in rj(f"{ROOT}/runs/jev/spam_clean.jsonl")}
OUT["spam_p_eq_0.5"] = [{"idx": r["idx"], "label": r["label"]} for r in sp if sj[r["idx"]] == 0.5]
# spam newline-normalized label check for the one row that failed exact match
import csv  # noqa: E402
raw = {}
with open(f"{ROOT}/data/spam.csv", encoding="latin-1", newline="") as f:
    rd = csv.reader(f)
    next(rd)
    for row in rd:
        if len(row) >= 2 and row[0] in ("ham", "spam"):
            raw.setdefault(row[1].replace("\r\n", "\n").replace("\r", "\n"), set()).add(1 if row[0] == "spam" else 0)
OUT["spam_label_check_newline_normalized"] = {
    "not_found": sum(1 for r in sp if r["text"] not in raw),
    "mismatch": sum(1 for r in sp if r["text"] in raw and r["label"] not in raw[r["text"]])}

# 8. Wilson vs bootstrap for the small/degenerate red-team proportions
from math import sqrt  # noqa: E402


def wilson(k, n, z=1.959964):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    w = z * sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return [round(c - w, 4), round(c + w, 4)]


m = json.load(open(f"{ROOT}/runs/audit/audit_metrics.json"))
OUT["wilson_small_tests"] = {n: {"acc": m["redteam"][n]["jev"]["accuracy"], "n": m["redteam"][n]["jev"]["n"],
                                 "bootstrap": m["redteam"][n]["jev"]["accuracy_ci95"],
                                 "wilson": wilson(round(m["redteam"][n]["jev"]["accuracy"] * m["redteam"][n]["jev"]["n"]),
                                                  m["redteam"][n]["jev"]["n"])}
                             for n in ["evasion_spam", "injection_spam", "ood_spam_on_banking"]}

# 9. ECE edge artefact: which confidences moved bins (spam clean, injection_oos_clinc)
def edge_moves(confs, corr):
    e32 = [float(x) for x in np.linspace(0, 1, 11, dtype=np.float32)]
    out = Counter()
    for c, y in zip(confs, corr):
        exact = min(9, max(0, int(np.ceil(round(c * 10, 6))) - 1))
        f32 = next(k for k in range(10) if (c > e32[k] and c <= e32[k + 1]) or (k == 0 and c == 0))
        if exact != f32:
            out[f"conf={c} bin{exact}->bin{f32} correct={int(y)}"] += 1
    return dict(out)


I = {r["idx"]: r for r in sp}
sc = [(max(sj[i], 1 - sj[i]), float((1 if sj[i] > 0.5 else 0) == I[i]["label"])) for i in sorted(sj)]
OUT["ece_edge_moves_spam_clean"] = edge_moves([a for a, _ in sc], [b for _, b in sc])
oi = {it["key"]: it for it in rj(f"{ROOT}/runs/redteam/inputs/injection_oos_clinc.jsonl")}
oc = []
for r in rj(f"{ROOT}/runs/redteam/jev/injection_oos_clinc.jsonl"):
    a = r["response"]["answers"]["intent"]
    oc.append((a["probabilities"][a["choice"]], float(a["choice"] == oi[r["key"]]["gold"])))
OUT["ece_edge_moves_injection_oos_clinc"] = edge_moves([a for a, _ in oc], [b for _, b in oc])

# 10. amazon: probability sums (why renormalising changes r / MAE)
for name in ["score_amazon_clean", "score_amazon_swap2"]:
    s = [sum(r["response"]["answers"]["stars"]["probabilities"].values()) for r in rj(f"{ROOT}/runs/redteam/jev/{name}.jsonl")]
    OUT[f"{name}_prob_sums"] = dict(Counter(round(x, 2) for x in s))

json.dump(OUT, open(f"{ROOT}/runs/audit/audit_extra.json", "w"), indent=1)
print(json.dumps(OUT, indent=1)[:12000])
