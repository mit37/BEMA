"""
Audit pass 4: independent recomputation for the five GPU-run models
(bema_v2_full_gpu, bema_v2_full_gpu_spell, bema_v3, bema_v3_spell, zs3_from_clinc)
plus zs3_from_banking on CLINC150.

Reads only raw files (runs/inputs, runs/redteam/inputs, runs/bema, runs/redteam/bema,
runs/jev, data/*.pkl) and the generated reports it checks. Does NOT import any repo
module; every metric is written here from scratch.

  python3 -I runs/audit/pass4/audit4.py      (run from the repo root)
writes runs/audit/pass4/audit4.json
"""
import hashlib
import json
import math
import os
import pickle
import random
import re
import sys
from decimal import Decimal

import numpy as np

ROOT = os.getcwd()
OUT = "runs/audit/pass4/audit4.json"
NEW_CORE = ["bema_v2_full_gpu", "bema_v2_full_gpu_spell", "bema_v3", "bema_v3_spell", "zs3_from_clinc"]
BANK_CONDS = ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]
SPAM_CONDS = ["clean", "swap2", "keyboard2", "mixed3"]
RT_MODELS = ["bema_v2_full_gpu", "bema_v3", "zs3_from_clinc", "zs3_from_banking"]
BOOT_N, BOOT_SEED = 10000, 20261027


def rj(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def sha(t):
    return hashlib.sha256(t.encode("utf-8")).hexdigest()


# ------------------------------------------------------------------ metrics (own implementations)
def ece_bins(confs, correct, nb):
    """Standard equal-width ECE: bins (k/nb, (k+1)/nb], confidence 0 in the first bin.
    Edges compared in exact decimal so 2-decimal confidences land in the right bin."""
    sums = [[0, 0.0, 0.0] for _ in range(nb)]
    for c, a in zip(confs, correct):
        f = Decimal(repr(float(c))) * nb
        k = max(0, min(nb - 1, int(math.ceil(f)) - 1))
        sums[k][0] += 1
        sums[k][1] += a
        sums[k][2] += c
    n = len(confs)
    return sum(s[0] / n * abs(s[1] / s[0] - s[2] / s[0]) for s in sums if s[0])


def wilson(k, n, z=1.959963984540054):
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def boot(diffs, n=BOOT_N, seed=BOOT_SEED):
    a = np.asarray(diffs, dtype=float)
    rng = np.random.default_rng(seed)
    m = np.empty(n)
    for i in range(0, n, 500):   # chunked to keep memory small
        j = min(n, i + 500)
        m[i:j] = a[rng.integers(0, len(a), size=(j - i, len(a)))].mean(1)
    return float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def pearson(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    x, y = x - x.mean(), y - y.mean()
    return float((x * y).sum() / math.sqrt((x * x).sum() * (y * y).sum()))


def mean(v):
    return sum(v) / len(v) if v else None


def summ(correct, confs):
    k, n = sum(correct), len(correct)
    return {"n": n, "accuracy": k / n, "wilson": wilson(k, n), "mean_confidence": mean(confs),
            "ece10": ece_bins(confs, correct, 10), "ece15": ece_bins(confs, correct, 15)}


# ------------------------------------------------------------------ load frozen inputs
CATS = json.load(open("runs/inputs/categories.json"))
INPUTS = {}
input_self_hash_bad = []
for task, conds in (("banking77", BANK_CONDS), ("spam", SPAM_CONDS)):
    for c in conds:
        rows = rj(f"runs/inputs/{task}_{c}.jsonl")
        for r in rows:
            if sha(r["text"]) != r["text_sha256"]:
                input_self_hash_bad.append((task, c, r["idx"]))
        INPUTS[(task, c)] = {r["idx"]: r for r in rows}
RT_INPUTS = {}
for p in sorted(os.listdir("runs/redteam/inputs")):
    rows = rj(f"runs/redteam/inputs/{p}")
    for r in rows:
        if sha(r["state"]) != r["state_sha256"]:
            input_self_hash_bad.append((p, r["key"]))
    RT_INPUTS[p[:-6]] = rows

res = {"input_self_hash_mismatches": input_self_hash_bad}

# spam label convention: label 1 rows should be the 'spam' rows of the raw CSV
import csv
raw_spam = {}
with open("data/spam.csv", encoding="latin-1") as f:
    rd = csv.reader(f)
    next(rd)
    for r in rd:
        if len(r) >= 2 and r[0] in ("ham", "spam"):
            raw_spam.setdefault(r[1], set()).add(r[0])
conv = {"label1_raw_spam": 0, "label1_raw_ham": 0, "label0_raw_spam": 0, "label0_raw_ham": 0, "ambiguous": 0}
for r in INPUTS[("spam", "clean")].values():
    s = raw_spam.get(r["text"], set())
    if len(s) != 1:
        conv["ambiguous"] += 1
        continue
    conv[f"label{r['label']}_raw_{next(iter(s))}"] += 1
res["spam_label_convention"] = conv
res["spam_counts"] = {"n": len(INPUTS[("spam", "clean")]), "n_label1": sum(r["label"] for r in INPUTS[("spam", "clean")].values())}

# ------------------------------------------------------------------ 1. coverage + sha256
cov = []


def check_core_file(model, task, cond):
    p = f"runs/bema/{model}_{task}_{cond}.jsonl"
    if not os.path.exists(p):
        return {"file": p, "ok": False, "why": "missing"}
    rows = rj(p)
    inp = INPUTS[(task, cond)]
    idxs = [r["idx"] for r in rows]
    bad_sha = [r["idx"] for r in rows if r["idx"] in inp and r["text_sha256"] != inp[r["idx"]]["text_sha256"]]
    extra = sorted(set(idxs) - set(inp))
    missing = sorted(set(inp) - set(idxs))
    dup = len(idxs) - len(set(idxs))
    nc = 77 if task == "banking77" else 2
    bad_val = 0
    for r in rows:
        if not (isinstance(r["pred"], int) and 0 <= r["pred"] < nc and 0 <= r["conf"] <= 1 + 1e-6):
            bad_val += 1
        if task == "spam":
            q = r["p_yes"]
            if r["pred"] != int(q > 0.5) or abs(r["conf"] - max(q, 1 - q)) > 1e-6:
                bad_val += 1
    ok = not (bad_sha or extra or missing or dup or bad_val)
    return {"file": p, "ok": ok, "rows": len(rows), "inputs": len(inp), "sha_mismatch": len(bad_sha),
            "extra": len(extra), "missing": len(missing), "duplicates": dup, "bad_values": bad_val}


for m in NEW_CORE:
    for c in BANK_CONDS:
        cov.append(check_core_file(m, "banking77", c))
    if not m.startswith("zs3"):
        for c in SPAM_CONDS:
            cov.append(check_core_file(m, "spam", c))

# which red-team tests should exist for each model
BEMA_Q = {"banking", "banking_shuffled", "banking_defended", "spam", "stars"}
ZSB_Q = {"banking", "banking_shuffled", "banking_defended"}
expected_rt = {}
for t, rows in RT_INPUTS.items():
    q = rows[0]["qset"]
    if q in BEMA_Q:
        expected_rt.setdefault("bema_v2_full_gpu", []).append(t)
        expected_rt.setdefault("bema_v3", []).append(t)
    if q in ZSB_Q:
        expected_rt.setdefault("zs3_from_clinc", []).append(t)
    if t in ("clinc150_clean", "clinc150_swap2", "injection_oos_clinc"):
        expected_rt.setdefault("zs3_from_banking", []).append(t)
present_rt = {m: sorted(f.split("__")[0] for f in os.listdir("runs/redteam/bema") if f.endswith(f"__{m}.jsonl"))
              for m in RT_MODELS}
res["redteam_expected_vs_present"] = {m: {"expected": sorted(expected_rt[m]), "present": present_rt[m],
                                          "missing": sorted(set(expected_rt[m]) - set(present_rt[m])),
                                          "unexpected": sorted(set(present_rt[m]) - set(expected_rt[m]))}
                                      for m in RT_MODELS}
RT = {}
for m in RT_MODELS:
    for t in present_rt[m]:
        p = f"runs/redteam/bema/{t}__{m}.jsonl"
        rows = rj(p)
        inp = {r["key"]: r for r in RT_INPUTS[t]}
        keys = [r["key"] for r in rows]
        bad_sha = [r["key"] for r in rows if r["key"] in inp and r["state_sha256"] != inp[r["key"]]["state_sha256"]]
        extra = sorted(set(keys) - set(inp))
        missing = sorted(set(inp) - set(keys))
        dup = len(keys) - len(set(keys))
        q = RT_INPUTS[t][0]["qset"]
        bad_val = 0
        for r in rows:
            if q == "stars":
                if not (1 - 1e-6 <= r["stars_expected"] <= 5 + 1e-6):
                    bad_val += 1
            elif q == "spam":
                if r["pred"] not in (0, 1) or r["pred"] != int(r["p_yes"] > 0.5):
                    bad_val += 1
            elif q == "clinc":
                pass
            else:
                if r["pred"] not in CATS or not (0 <= r["conf"] <= 1 + 1e-6):
                    bad_val += 1
        ok = not (bad_sha or extra or missing or dup or bad_val)
        cov.append({"file": p, "ok": ok, "rows": len(rows), "inputs": len(inp), "sha_mismatch": len(bad_sha),
                    "extra": len(extra), "missing": len(missing), "duplicates": dup, "bad_values": bad_val})
        RT[(t, m)] = {r["key"]: r for r in rows}
res["coverage"] = cov
res["coverage_summary"] = {"files": len(cov), "ok": sum(c["ok"] for c in cov),
                           "not_ok": [c for c in cov if not c["ok"]]}

# ------------------------------------------------------------------ 2. recompute
def core_correct(model, task, cond):
    inp = INPUTS[(task, cond)]
    out = {}
    for r in rj(f"runs/bema/{model}_{task}_{cond}.jsonl"):
        g = inp[r["idx"]]["label"]
        if task == "banking77":
            ok = float(CATS[r["pred"]] == CATS[g])
        else:
            ok = float(int(r["pred"]) == int(g))
        out[r["idx"]] = (ok, float(r["conf"]), r["pred"])
    return out


def jev_core(task, cond):
    inp = INPUTS[(task, cond)]
    out = {}
    for r in rj(f"runs/jev/{task}_{cond}.jsonl"):
        if r["status"] != "ok":
            continue
        assert r["text_sha256"] == inp[r["idx"]]["text_sha256"]
        a = r["response"]["answers"]["intent"]
        pred = a["choice"]
        out[r["idx"]] = (float(pred == CATS[inp[r["idx"]]["label"]]), float(a["probabilities"][pred]), pred)
    return out


R = {"banking77": {}, "spam": {}}
for m in NEW_CORE:
    for c in BANK_CONDS:
        d = core_correct(m, "banking77", c)
        R["banking77"][(m, c)] = summ([v[0] for v in d.values()], [v[1] for v in d.values()])
    if not m.startswith("zs3"):
        for c in SPAM_CONDS:
            d = core_correct(m, "spam", c)
            s = summ([v[0] for v in d.values()], [v[1] for v in d.values()])
            inp = INPUTS[("spam", c)]
            tp = sum(1 for i, v in d.items() if v[2] == 1 and inp[i]["label"] == 1)
            fp = sum(1 for i, v in d.items() if v[2] == 1 and inp[i]["label"] == 0)
            fn = sum(1 for i, v in d.items() if v[2] == 0 and inp[i]["label"] == 1)
            s.update({"precision": tp / (tp + fp), "recall": tp / (tp + fn), "false_alarms": fp, "missed": fn})
            s["f1"] = 2 * s["precision"] * s["recall"] / (s["precision"] + s["recall"])
            R["spam"][(m, c)] = s

# drop from clean
for m in NEW_CORE:
    for c in BANK_CONDS[1:]:
        R["banking77"][(m, c)]["drop"] = R["banking77"][(m, "clean")]["accuracy"] - R["banking77"][(m, c)]["accuracy"]

# spam duplicates (exact text match with training)
data = pickle.load(open("data/prepared_multitask.pkl", "rb"))
spam_train = {r["text"] for r in data["noul"]["train"]}
spam_dup = {i for i, r in INPUTS[("spam", "clean")].items() if r["text"] in spam_train}
norm = lambda t: re.sub(r"\s+", " ", t.strip().lower())
spam_train_n = {norm(r["text"]) for r in data["noul"]["train"]}
spam_dup_n = {i for i, r in INPUTS[("spam", "clean")].items() if norm(r["text"]) in spam_train_n}
res["spam_dups"] = {"exact": len(spam_dup), "normalised": len(spam_dup_n)}
spam_excl = {}
for m in ("bema_v2_full_gpu", "bema_v3"):
    d = core_correct(m, "spam", "clean")
    v = [x[0] for i, x in d.items() if i not in spam_dup]
    spam_excl[m] = (sum(v) / len(v), len(v))

# paired vs Jev, clean BANKING77
jc = jev_core("banking77", "clean")
res["jev_clean_ok_rows"] = len(jc)
res["jev_clean_accuracy"] = mean([v[0] for v in jc.values()])
paired = {}
for m in NEW_CORE:
    d = core_correct(m, "banking77", "clean")
    ks = sorted(set(d) & set(jc))
    diffs = [d[k][0] - jc[k][0] for k in ks]
    lo, hi = boot(diffs)
    paired[m] = {"n": len(ks), "diff": mean(diffs), "ci": (lo, hi),
                 "model_only_right": sum(1 for x in diffs if x > 0), "jev_only_right": sum(1 for x in diffs if x < 0)}

# 1,000-key sample and the 250-key slice
sample = sorted(random.Random(7).sample(range(3080), 1000))
slice250 = set(random.Random(11).sample(sample, 250))
slice_keys = {str(i) for i in slice250}
inj_keys = sorted(int(r["key"]) for r in RT_INPUTS["injection_banking"])
res["sample_matches_injection_input_keys"] = inj_keys == sample
res["sample_matches_meta_idx"] = sorted(r["meta"]["idx"] for r in RT_INPUTS["injection_banking"]) == sample
res["slice250_n"] = len(slice250)
res["slice250_first10_sorted"] = sorted(slice250)[:10]
res["slice250_distinct_gold_intents"] = len({CATS[INPUTS[("banking77", "clean")][i]["label"]] for i in slice250})


def rt_choice(test, model):
    inp = {r["key"]: r for r in RT_INPUTS[test]}
    return {k: (float(r["pred"] == inp[k]["gold"]), float(r["conf"]), r["pred"]) for k, r in RT[(test, model)].items()}


def followed(d, test, keys=None):
    inp = {r["key"]: r for r in RT_INPUTS[test]}
    v = [float(x[2] == inp[k]["meta"]["target"]) for k, x in d.items() if keys is None or k in keys]
    return mean(v)


INJ = ["injection_banking", "injection_prefix_banking", "injection_casual_banking", "injection_control_banking",
       "injection_defended_banking", "injection_casual_defended_banking"]
inj = {}
for t in INJ:
    for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
        d = rt_choice(t, m)
        has_t = RT_INPUTS[t][0]["meta"].get("target") is not None
        e = summ([v[0] for v in d.values()], [v[1] for v in d.values()])
        e["followed"] = followed(d, t) if has_t else None
        sub = {k: v for k, v in d.items() if k in slice_keys}
        e["slice_acc"], e["slice_n"] = mean([v[0] for v in sub.values()]), len(sub)
        e["slice_followed"] = followed(sub, t) if has_t else None
        cc = core_correct(m, "banking77", "clean")
        e["clean_same_examples"] = mean([cc[int(k)][0] for k in d])
        inj[(t, m)] = e

# defended files: identical predictions to undefended?
def_ident = {}
for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
    for a, b in (("injection_defended_banking", "injection_banking"),
                 ("injection_casual_defended_banking", "injection_casual_banking")):
        da, db = RT[(a, m)], RT[(b, m)]
        same_state = all(x["state"] == y["state"] for x, y in zip(RT_INPUTS[a], RT_INPUTS[b]))
        def_ident[f"{a}__{m}"] = {"same_input_text": same_state,
                                  "same_pred": sum(da[k]["pred"] == db[k]["pred"] for k in da),
                                  "max_conf_diff": max(abs(da[k]["conf"] - db[k]["conf"]) for k in da)}
res["defended_vs_undefended"] = def_ident

# slice250 clean / swap2 for the core files
slice_core = {}
for m in NEW_CORE:
    for c in ("clean", "swap2"):
        d = core_correct(m, "banking77", c)
        v = [d[i][0] for i in slice250]
        slice_core[(m, c)] = (mean(v), len(v))

# clean injection reference (not reported for the new models; computed for completeness)
clean_ref = {m: mean([core_correct(m, "banking77", "clean")[i][0] for i in sample])
             for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc")}
res["clean_reference_new_models_pct"] = {m: round(100 * v, 2) for m, v in clean_ref.items()}

# consistency: red-team copies of clean text vs core clean predictions (same checkpoint?)
cons = {}
for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
    cc = {i: r for i, r in ((r["idx"], r) for r in rj(f"runs/bema/{m}_banking77_clean.jsonl"))}
    for t in ("order_shuffle_banking", "latency_sequential_banking", "repeat_banking_spread"):
        inp = {r["key"]: r for r in RT_INPUTS[t]}
        same, n, mx = 0, 0, 0.0
        for k, r in RT[(t, m)].items():
            i = inp[k]["meta"]["idx"]
            assert inp[k]["state"] == INPUTS[("banking77", "clean")][i]["text"]
            n += 1
            same += r["pred"] == CATS[cc[i]["pred"]]
            mx = max(mx, abs(r["conf"] - cc[i]["conf"]))
        cons[f"{t}__{m}"] = {"n": n, "same_pred_as_core_clean": same, "max_conf_diff": mx}
res["redteam_vs_core_consistency"] = cons

# spam red-team tests, gibberish, score, order shuffle
spam_rt = {}
for t in ("injection_spam", "evasion_spam", "ood_spam_on_banking"):
    inp = {r["key"]: r for r in RT_INPUTS[t]}
    for m in ("bema_v2_full_gpu", "bema_v3"):
        rows = RT[(t, m)]
        c = [float(r["pred"] == inp[k]["gold"]) for k, r in rows.items()]
        e = summ(c, [float(r["conf"]) for r in rows.values()])
        e["mean_p_spam"] = mean([r["p_yes"] for r in rows.values()])
        if t != "ood_spam_on_banking":
            cs = core_correct(m, "spam", "clean")
            e["clean_recall_same"] = mean([float(cs[inp[k]["meta"]["idx"]][2] == 1) for k in rows])
        spam_rt[(t, m)] = e
res["ood_spam_gold_all_zero"] = all(r["gold"] == 0 for r in RT_INPUTS["ood_spam_on_banking"])
res["evasion_gold_all_one"] = all(r["gold"] == 1 for r in RT_INPUTS["evasion_spam"])

gib = {}
for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
    inp = {r["key"]: r for r in RT_INPUTS["gibberish_banking"]}
    rows = RT[("gibberish_banking", m)]
    kinds = sorted({r["meta"]["kind"] for r in inp.values()})
    gib[m] = {kd: mean([rows[k]["conf"] for k in rows if inp[k]["meta"]["kind"] == kd]) for kd in kinds}
    gib[m]["all"] = mean([r["conf"] for r in rows.values()])
    gib[m]["share_ge_0.5"] = mean([float(r["conf"] >= 0.5) for r in rows.values()])
    gib[m]["share_ge_0.9"] = mean([float(r["conf"] >= 0.9) for r in rows.values()])

score = {}
for t in ("score_amazon_clean", "score_amazon_swap2"):
    inp = {r["key"]: r for r in RT_INPUTS[t]}
    for m in ("bema_v2_full_gpu", "bema_v3"):
        rows = RT[(t, m)]
        g = [inp[k]["gold"] for k in rows]
        e = [rows[k]["stars_expected"] for k in rows]
        score[(t, m)] = {"n": len(g), "pearson": pearson(e, g), "mae": mean([abs(a - b) for a, b in zip(e, g)]),
                         "exact_rounded": mean([float(round(a) == b) for a, b in zip(e, g)]),
                         "within1_rounded": mean([float(abs(round(a) - b) <= 1) for a, b in zip(e, g)])}
# Amazon gold check against the pickle
amz = data["score"]["test"]
res["amazon_gold_matches_pickle"] = all(r["gold"] == round(amz[int(r["key"])]["label"] * 4) + 1
                                        for r in RT_INPUTS["score_amazon_clean"])

order = {}
for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
    d = rt_choice("order_shuffle_banking", m)
    order[m] = summ([v[0] for v in d.values()], [v[1] for v in d.values()])

clinc = {}
for t in ("clinc150_clean", "clinc150_swap2", "injection_oos_clinc"):
    inp = {r["key"]: r for r in RT_INPUTS[t]}
    rows = RT[(t, "zs3_from_banking")]
    c = [float(r["pred"] == inp[k]["gold"]) for k, r in rows.items()]
    e = summ(c, [float(r["conf"]) for r in rows.values()])
    ins = [k for k in rows if inp[k]["gold"] != "oos"]
    oos = [k for k in rows if inp[k]["gold"] == "oos"]
    e["in_scope_acc"] = mean([float(rows[k]["pred"] == inp[k]["gold"]) for k in ins])
    e["oos_recall"] = mean([float(rows[k]["pred"] == "oos") for k in oos]) if oos else None
    e["false_oos"] = mean([float(rows[k]["pred"] == "oos") for k in ins])
    e["said_oos"] = mean([float(r["pred"] == "oos") for r in rows.values()])
    e["n_in"], e["n_oos"] = len(ins), len(oos)
    clinc[t] = e
# is zs3_from_banking's injection_oos_clinc file a copy of another model's?
other = {}
for f in os.listdir("runs/redteam/bema"):
    if f.startswith("injection_oos_clinc__") and "zs3_from_banking" not in f:
        o = {r["key"]: r for r in rj(f"runs/redteam/bema/{f}")}
        z = RT[("injection_oos_clinc", "zs3_from_banking")]
        other[f] = sum(o[k]["pred"] == z[k]["pred"] for k in z)
res["injection_oos_clinc_pred_agreement_with_other_models"] = other

# agreement between new core models and older ones (copy check)
agree = {}
for a, b in (("bema_v2_full_gpu", "bema_v2"), ("bema_v3", "bema_v2_full_gpu"), ("bema_v3", "bema_v3_spell"),
             ("bema_v2_full_gpu", "bema_v2_full_gpu_spell"), ("zs3_from_clinc", "zs_from_clinc"),
             ("zs3_from_clinc", "zs_offshelf_bge_base")):
    pa = {r["idx"]: r["pred"] for r in rj(f"runs/bema/{a}_banking77_clean.jsonl")}
    pb = {r["idx"]: r["pred"] for r in rj(f"runs/bema/{b}_banking77_clean.jsonl")}
    agree[f"{a} vs {b}"] = sum(pa[i] == pb[i] for i in pa) / len(pa)
res["clean_pred_agreement"] = agree

# ------------------------------------------------------------------ 4. leakage
def nrm(t):
    return re.sub(r"\s+", " ", t.strip().lower())


btest = [r["text"] for r in data["choice"]["test"]]
btrain = [r["text"] for r in data["choice"]["train"]]
bval = [r["text"] for r in data["choice"]["val"]]
tr_n, va_n = {nrm(t) for t in btrain}, {nrm(t) for t in bval}
tr_e, va_e = set(btrain), set(bval)
test_in_train_n = [i for i, t in enumerate(btest) if nrm(t) in tr_n]
test_in_val_n = [i for i, t in enumerate(btest) if nrm(t) in va_n]
leak = {"n_test": len(btest), "n_train": len(btrain), "n_val": len(bval),
        "test_in_train_exact": sum(t in tr_e for t in btest),
        "test_in_train_normalised": len(test_in_train_n),
        "test_in_val_normalised": len(test_in_val_n),
        "test_in_train_or_val_normalised": len(set(test_in_train_n) | set(test_in_val_n)),
        "test_texts_matching_frozen_inputs": all(INPUTS[("banking77", "clean")][i]["text"] == t for i, t in enumerate(btest)),
        "examples_in_train": [btest[i] for i in test_in_train_n[:12]],
        "train_val_overlap_normalised": len(tr_n & va_n),
        "distinct_test_texts_normalised": len({nrm(t) for t in btest})}
# label agreement on leaked texts
tr_lab = {}
for r in data["choice"]["train"]:
    tr_lab.setdefault(nrm(r["text"]), set()).add(r["label"])
leak["leaked_with_same_label"] = sum(1 for i in test_in_train_n if data["choice"]["test"][i]["label"] in tr_lab[nrm(btest[i])])
# raw-file check: official train/test files vs the pickle
with open("data/raw/banking_train.csv", encoding="utf-8") as f:
    raw_tr = [r["text"] for r in csv.DictReader(f)]
with open("data/raw/banking_test.csv", encoding="utf-8") as f:
    raw_te = [r["text"] for r in csv.DictReader(f)]
leak["raw_official_train"] = len(raw_tr)
leak["raw_official_test"] = len(raw_te)
leak["pickle_test_equals_raw_test"] = raw_te == btest
leak["pickle_train_plus_val_equals_raw_train_multiset"] = sorted(btrain + bval) == sorted(raw_tr)
# accuracy of v3 on leaked vs non-leaked test rows
d3 = core_correct("bema_v3", "banking77", "clean")
L = set(test_in_train_n)
leak["bema_v3_acc_on_leaked"] = mean([d3[i][0] for i in L]) if L else None
leak["bema_v3_acc_excluding_leaked"] = mean([d3[i][0] for i in d3 if i not in L])
leak["bema_v2_full_gpu_acc_excluding_leaked"] = mean([v[0] for i, v in core_correct("bema_v2_full_gpu", "banking77", "clean").items() if i not in L])
leak["jev_acc_excluding_leaked"] = mean([v[0] for i, v in jc.items() if i not in L])
# cross-dataset overlap for the zero-shot models
cl = json.load(open("data/raw/clinc150_data_full.json"))
cl_train_n = {nrm(t) for t, _ in cl["train"]} | {nrm(t) for t, _ in cl["oos_train"]}
cl_test_n = [nrm(t) for t, _ in cl["test"]] + [nrm(t) for t, _ in cl["oos_test"]]
leak["banking_test_in_clinc_train_normalised"] = sum(nrm(t) in cl_train_n for t in btest)
leak["clinc_test_in_banking_train_normalised"] = sum(t in tr_n for t in cl_test_n)
res["leakage"] = leak

# spam leakage for completeness (exact and normalised) already in spam_dups

# ------------------------------------------------------------------ 3. compare to reports
S = json.load(open("runs/results_summary.json"))["sections"]
RJ = json.load(open("runs/report.json"))["tasks"]
RR = json.load(open("runs/redteam_report.json"))["tests"]
cmp = []


def add(where, what, rep, mine, tol, kind="value"):
    if rep is None:
        cmp.append({"where": where, "what": what, "reported": None, "recomputed": mine, "status": "NOT REPORTED"})
        return
    if isinstance(rep, (list, tuple)):
        ok = all(abs(a - b) <= tol + 1e-12 for a, b in zip(rep, mine))
    else:
        ok = abs(rep - mine) <= tol + 1e-12
    cmp.append({"where": where, "what": what, "reported": rep, "recomputed": mine, "tol": tol,
                "status": "PASS" if ok else "FAIL"})


P1, E4, C3 = 0.05, 0.00005, 0.0005   # rounding tolerances: 1-dp percent, 4-dp ECE, 3-dp confidence
ece15_rows = []
for m in NEW_CORE:
    for c in BANK_CONDS:
        r = R["banking77"][(m, c)]
        s = S["banking77_typos"]["rows"][c].get(m)
        add(f"summary.banking77_typos.{c}", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * r["accuracy"], P1)
        add(f"summary.banking77_typos.{c}", f"{m} ece (10-bin)", s and s["ece"], r["ece10"], E4)
        add(f"summary.banking77_typos.{c}", f"{m} n", s and s["n"], r["n"], 0)
        ece15_rows.append({"task": "banking77", "model": m, "cond": c, "reported_ece": s and s["ece"],
                           "ece10": r["ece10"], "ece15": r["ece15"]})
        j = RJ["banking77"][c].get(m)
        add(f"report.banking77.{c}", f"{m} accuracy", j and j["accuracy"], r["accuracy"], 1e-12)
        add(f"report.banking77.{c}", f"{m} ece", j and j["ece"], r["ece10"], 1e-9)
        add(f"report.banking77.{c}", f"{m} mean_confidence", j and j["mean_confidence"], r["mean_confidence"], 1e-9)
        add(f"report.banking77.{c}", f"{m} wilson ci", j and j["accuracy_ci95"], r["wilson"], 1e-9)
        if c != "clean":
            add(f"report.banking77.{c}", f"{m} accuracy_drop_from_clean", j and j.get("accuracy_drop_from_clean"), r["drop"], 1e-12)
    if not m.startswith("zs3"):
        for c in SPAM_CONDS:
            r = R["spam"][(m, c)]
            s = S["spam"]["rows"][c].get(m)
            add(f"summary.spam.{c}", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * r["accuracy"], P1)
            add(f"summary.spam.{c}", f"{m} ece (10-bin)", s and s["ece"], r["ece10"], E4)
            ece15_rows.append({"task": "spam", "model": m, "cond": c, "reported_ece": s and s["ece"],
                               "ece10": r["ece10"], "ece15": r["ece15"]})
            j = RJ["spam"][c].get(m)
            add(f"report.spam.{c}", f"{m} accuracy", j and j["accuracy"], r["accuracy"], 1e-12)
            add(f"report.spam.{c}", f"{m} ece", j and j["ece"], r["ece10"], 1e-9)
            add(f"report.spam.{c}", f"{m} mean_confidence", j and j["mean_confidence"], r["mean_confidence"], 1e-9)
            for k1, k2 in (("spam_precision", "precision"), ("spam_recall", "recall"), ("spam_f1", "f1"),
                           ("false_alarms_on_ham", "false_alarms"), ("missed_spam", "missed")):
                add(f"report.spam.{c}", f"{m} {k1}", j and j[k1], r[k2], 1e-12)
for m, (a, n) in spam_excl.items():
    s = S["spam"]["clean_excluding_duplicates"].get(m)
    add("summary.spam.clean_excluding_duplicates", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * a, P1)
    add("summary.spam.clean_excluding_duplicates", f"{m} n", s and s["n"], n, 0)
add("summary.spam", "test_messages_also_in_training (exact)", S["spam"]["test_messages_also_in_training"], len(spam_dup), 0)

for m, p in paired.items():
    s = S["banking77_paired_vs_jev"]["rows"].get(m)
    add("summary.banking77_paired_vs_jev", f"{m} minus_jev_points", s and s["minus_jev_points"], 100 * p["diff"], P1)
    add("summary.banking77_paired_vs_jev", f"{m} ci95_points (tol 0.2, bootstrap seed)", s and s["ci95_points"],
        [100 * p["ci"][0], 100 * p["ci"][1]], 0.2)
    add("summary.banking77_paired_vs_jev", f"{m} n", s and s["n"], p["n"], 0)
    j = RJ["banking77"]["clean"].get(f"jev_minus_{m}_accuracy")
    add("report.banking77.clean", f"jev_minus_{m} diff", j and j["diff"], -p["diff"], 1e-12)
    add("report.banking77.clean", f"jev_minus_{m} ci95 (tol 0.002, bootstrap seed)", j and j["ci95"],
        [-p["ci"][1], -p["ci"][0]], 0.002)

SL = S["slice250_all_models"]["rows"]
add("summary.slice250", "n_keys", S["slice250_all_models"]["n_keys"], len(slice250), 0)
for (m, c), (a, n) in slice_core.items():
    s = SL[c].get(m)
    add(f"summary.slice250.{c}", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * a, P1)
    add(f"summary.slice250.{c}", f"{m} n", s and s["n"], n, 0)
for lab, t in (("injection_explicit", "injection_banking"), ("injection_control", "injection_control_banking"),
               ("injection_casual", "injection_casual_banking"), ("injection_casual_defended", "injection_casual_banking")):
    for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
        e = inj[(t, m)]
        s = SL[lab].get(m)
        add(f"summary.slice250.{lab}", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * e["slice_acc"], P1)
        add(f"summary.slice250.{lab}", f"{m} n", s and s["n"], e["slice_n"], 0)
        if e["slice_followed"] is not None:
            add(f"summary.slice250.{lab}", f"{m} followed_injection_pct", s and s.get("followed_injection_pct"),
                100 * e["slice_followed"], P1)

IR = S["injection"]["rows"]
for lab, t in (("explicit_note_end", "injection_banking"), ("explicit_note_start", "injection_prefix_banking"),
               ("casual_ps", "injection_casual_banking"), ("neutral_note_control", "injection_control_banking"),
               ("explicit_note_defended", "injection_defended_banking"),
               ("casual_ps_defended", "injection_casual_defended_banking")):
    for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
        e = inj[(t, m)]
        s = IR[lab].get(m)
        add(f"summary.injection.{lab}", f"{m} accuracy_pct", s and s["accuracy_pct"], 100 * e["accuracy"], P1)
        add(f"summary.injection.{lab}", f"{m} mean_confidence", s and s["mean_confidence"], e["mean_confidence"], C3)
        if e["followed"] is not None:
            add(f"summary.injection.{lab}", f"{m} followed_injection_pct", s and s.get("followed_injection_pct"),
                100 * e["followed"], P1)
        rr = RR[t].get(m)
        add(f"redteam.{t}", f"{m} accuracy", rr and rr["accuracy"], e["accuracy"], 1e-12)
        add(f"redteam.{t}", f"{m} mean_confidence", rr and rr["mean_confidence"], e["mean_confidence"], 1e-9)
        add(f"redteam.{t}", f"{m} ece", rr and rr["ece"], e["ece10"], 1e-9)
        add(f"redteam.{t}", f"{m} clean_accuracy_same_examples", rr and rr["clean_accuracy_same_examples"],
            e["clean_same_examples"], 1e-12)
        if e["followed"] is not None:
            add(f"redteam.{t}", f"{m} followed_injected_label", rr and rr.get("followed_injected_label"), e["followed"], 1e-12)
for m in ("bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"):
    add("summary.injection.clean_reference", f"{m} clean acc on the 1,000 keys",
        S["injection"]["clean_reference"].get(m), 100 * clean_ref[m], P1)

RO = S["redteam_other"]
for (t, m), e in spam_rt.items():
    for src, blk in (("summary.redteam_other", RO[t]), ("redteam", RR[t])):
        rr = blk.get(m)
        add(f"{src}.{t}", f"{m} accuracy", rr and rr["accuracy"], e["accuracy"], 1e-12)
        add(f"{src}.{t}", f"{m} mean_confidence", rr and rr["mean_confidence"], e["mean_confidence"], 1e-9)
        add(f"{src}.{t}", f"{m} ece", rr and rr["ece"], e["ece10"], 1e-9)
        add(f"{src}.{t}", f"{m} mean_p_spam", rr and rr["mean_p_spam"], e["mean_p_spam"], 1e-9)
        if "clean_recall_same" in e:
            add(f"{src}.{t}", f"{m} clean_recall_same_examples", rr and rr["clean_recall_same_examples"], e["clean_recall_same"], 1e-12)
for m, g in gib.items():
    for src, blk in (("summary.redteam_other", RO["gibberish_banking"]), ("redteam", RR["gibberish_banking"])):
        rr = blk.get(m)
        for kd in g:
            if kd.startswith("share"):
                continue
            add(f"{src}.gibberish_banking", f"{m} {kd} mean_confidence", rr and rr[kd]["mean_confidence"], g[kd], 1e-9)
        add(f"{src}.gibberish_banking", f"{m} all share_confidence_ge_0.5", rr and rr["all"]["share_confidence_ge_0.5"], g["share_ge_0.5"], 1e-12)
        add(f"{src}.gibberish_banking", f"{m} all share_confidence_ge_0.9", rr and rr["all"]["share_confidence_ge_0.9"], g["share_ge_0.9"], 1e-12)
for (t, m), e in score.items():
    for src, blk in (("summary.redteam_other", RO[t]), ("redteam", RR[t])):
        rr = blk.get(m)
        add(f"{src}.{t}", f"{m} pearson_r_expected_stars", rr and rr["pearson_r_expected_stars"], e["pearson"], 1e-9)
        add(f"{src}.{t}", f"{m} mae_stars_expected", rr and rr["mae_stars_expected"], e["mae"], 1e-9)
        add(f"{src}.{t}", f"{m} exact_star_accuracy_rounded", rr and rr["exact_star_accuracy_rounded"], e["exact_rounded"], 1e-12)
        add(f"{src}.{t}", f"{m} within_one_star_rounded", rr and rr["within_one_star_rounded"], e["within1_rounded"], 1e-12)
        add(f"{src}.{t}", f"{m} n", rr and rr["n"], e["n"], 0)
for m, e in order.items():
    for src, blk in (("summary.redteam_other", RO["order_shuffle_banking"]), ("redteam", RR["order_shuffle_banking"])):
        rr = blk.get(m)
        add(f"{src}.order_shuffle_banking", f"{m} accuracy", rr and rr["accuracy"], e["accuracy"], 1e-12)
        add(f"{src}.order_shuffle_banking", f"{m} ece", rr and rr["ece"], e["ece10"], 1e-9)
for t, e in clinc.items():
    for src, blk in (("summary.redteam_other", RO[t]), ("redteam", RR[t])):
        rr = blk.get("zs3_from_banking")
        add(f"{src}.{t}", "zs3_from_banking accuracy", rr and rr["accuracy"], e["accuracy"], 1e-12)
        add(f"{src}.{t}", "zs3_from_banking mean_confidence", rr and rr["mean_confidence"], e["mean_confidence"], 1e-9)
        add(f"{src}.{t}", "zs3_from_banking ece", rr and rr["ece"], e["ece10"], 1e-9)
        add(f"{src}.{t}", "zs3_from_banking wilson ci", rr and rr["accuracy_ci95"], e["wilson"], 1e-9)
        if t.startswith("clinc150"):
            add(f"{src}.{t}", "zs3_from_banking in_scope_accuracy", rr and rr["in_scope_accuracy"], e["in_scope_acc"], 1e-12)
            add(f"{src}.{t}", "zs3_from_banking oos_recall", rr and rr["oos_recall"], e["oos_recall"], 1e-12)
            add(f"{src}.{t}", "zs3_from_banking false_oos_rate_on_in_scope", rr and rr["false_oos_rate_on_in_scope"], e["false_oos"], 1e-12)
            add(f"{src}.{t}", "zs3_from_banking n_in_scope / n_oos", rr and [rr["n_in_scope"], rr["n_oos"]], [e["n_in"], e["n_oos"]], 0)
        else:
            add(f"{src}.{t}", "zs3_from_banking said_oos_with_note", rr and rr["said_oos_with_note"], e["said_oos"], 1e-12)

res["comparisons"] = cmp
res["n_compared"] = sum(1 for c in cmp if c["status"] in ("PASS", "FAIL"))
res["n_pass"] = sum(1 for c in cmp if c["status"] == "PASS")
res["fails"] = [c for c in cmp if c["status"] == "FAIL"]
res["not_reported"] = [c for c in cmp if c["status"] == "NOT REPORTED"]
res["ece15_table"] = ece15_rows


def ser(d):
    return {"|".join(k) if isinstance(k, tuple) else k: v for k, v in d.items()}


res["recomputed"] = {"banking77": ser(R["banking77"]), "spam": ser(R["spam"]), "paired": paired,
                     "injection": ser(inj), "slice_core": ser(slice_core), "spam_redteam": ser(spam_rt),
                     "gibberish": gib, "score": ser(score), "order_shuffle": order, "clinc_zs3_from_banking": clinc,
                     "spam_excl_dups": spam_excl}
json.dump(res, open(OUT, "w"), indent=1, default=lambda o: list(o) if isinstance(o, (set, tuple)) else str(o))
print(f"coverage files: {res['coverage_summary']['files']}, ok: {res['coverage_summary']['ok']}")
print(f"compared: {res['n_compared']}, pass: {res['n_pass']}, fail: {len(res['fails'])}, not reported: {len(res['not_reported'])}")
for f in res["fails"]:
    print("FAIL", f)
for f in res["not_reported"]:
    print("NOT REPORTED", f["where"], f["what"], f["recomputed"])
