"""
Consistency check for the GPU speller variants: on every input the speller left
unchanged, <model>_spell must give the same prediction (and, up to float noise from
batch padding, the same confidence) as <model>, since the checkpoint is the same.
Uses runs/bema/spell_texts/<task>_<cond>.jsonl (the text the spell model read).

  python3 -I runs/audit/pass4/spell_consistency.py     (from the repo root)
"""
import json

BANK = ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]
SPAM = ["clean", "swap2", "keyboard2", "mixed3"]


def rj(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


out = {}
for base in ("bema_v2_full_gpu", "bema_v3"):
    for task, conds in (("banking77", BANK), ("spam", SPAM)):
        for c in conds:
            st = {r["idx"]: r for r in rj(f"runs/bema/spell_texts/{task}_{c}.jsonl")}
            inp = {r["idx"]: r["text"] for r in rj(f"runs/inputs/{task}_{c}.jsonl")}
            a = {r["idx"]: r for r in rj(f"runs/bema/{base}_{task}_{c}.jsonl")}
            b = {r["idx"]: r for r in rj(f"runs/bema/{base}_spell_{task}_{c}.jsonl")}
            unchanged = [i for i in a if st[i]["corrected"] == st[i]["original"]]
            orig_ok = all(st[i]["original"] == inp[i] for i in a)
            same_pred = sum(a[i]["pred"] == b[i]["pred"] for i in unchanged)
            maxd = max((abs(a[i]["conf"] - b[i]["conf"]) for i in unchanged), default=0.0)
            changed = len(a) - len(unchanged)
            out[f"{base}|{task}|{c}"] = {"n": len(a), "speller_changed": changed, "unchanged": len(unchanged),
                                        "same_pred_on_unchanged": same_pred, "max_conf_diff_on_unchanged": maxd,
                                        "spell_texts_original_matches_input": orig_ok}
json.dump(out, open("runs/audit/pass4/spell_consistency.json", "w"), indent=1)
bad = {k: v for k, v in out.items() if v["same_pred_on_unchanged"] != v["unchanged"] or v["max_conf_diff_on_unchanged"] > 1e-4
       or not v["spell_texts_original_matches_input"]}
print(f"{len(out)} files checked; inconsistent: {len(bad)}")
for k, v in out.items():
    print(k, v["speller_changed"], v["same_pred_on_unchanged"], "/", v["unchanged"], f"{v['max_conf_diff_on_unchanged']:.2e}")
