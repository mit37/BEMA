"""Writes runs/audit/AUDIT_PASS4.md from runs/audit/pass4/audit4.json and spell_consistency.json.
  python3 -I runs/audit/pass4/write_md.py     (from the repo root)"""
import json

A = json.load(open("runs/audit/pass4/audit4.json"))
SC = json.load(open("runs/audit/pass4/spell_consistency.json"))
S = json.load(open("runs/results_summary.json"))
SS = S["sections"]
RR = json.load(open("runs/redteam_report.json"))["tests"]
REC = A["recomputed"]
BANK = ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"]
SPAM = ["clean", "swap2", "keyboard2", "mixed3"]
CORE = ["bema_v2_full_gpu", "bema_v2_full_gpu_spell", "bema_v3", "bema_v3_spell", "zs3_from_clinc"]
RTM = ["bema_v2_full_gpu", "bema_v3", "zs3_from_clinc"]
nf = len(A["fails"])
cov = A["coverage_summary"]
ece_diff = [x for x in A["ece15_table"] if round(x["ece15"], 4) != x["reported_ece"]]
ece_max = max(abs(x["ece15"] - x["ece10"]) for x in A["ece15_table"])
L = A["leakage"]


def p1(x):
    return f"{100 * x:.1f}"


def mark(rep, mine, tol):
    return "" if rep is not None and abs(rep - mine) <= tol + 1e-12 else " **(mismatch)**"


o = []
w = o.append
w("# Audit pass 4: the five GPU-run models")
w("")
w(f"I checked `runs/results_summary.json` (generated {S['generated_utc'][:19]}Z), `runs/report.json` and "
  "`runs/redteam_report.json` against my own recomputation from the raw files. The models are bema_v2_full_gpu, "
  "bema_v2_full_gpu_spell, bema_v3, bema_v3_spell and zs3_from_clinc, plus zs3_from_banking on CLINC150. All code is in "
  "`runs/audit/pass4/`. `audit4.py` recomputes every metric with its own implementation and imports no repo module. "
  "`spell_consistency.py` checks the speller variants. `write_md.py` writes this file. "
  "I changed nothing outside `runs/audit/pass4/` and this file, and I made no network calls.")
w("")
w("## Verdict")
w("")
w(f"**PASS: 0 FAILs.** {A['n_pass']}/{A['n_compared']} reported values for the new models match my recomputation "
  f"within rounding. All {cov['ok']}/{cov['files']} new prediction files cover exactly their input set, with a "
  "matching sha256 on every row.")
w("")
w(f"**One flag on the ECE definition (not counted as a FAIL):** every ECE in the summary and the reports uses **10** "
  "equal-width bins (`bench_jev.ece_exact`, `n_bins=10`). The summary does not say so. With the 15 bins you specified, "
  f"{len(ece_diff)} of 51 new-model ECE cells differ beyond rounding, by up to {ece_max:.4f}. "
  "The reported numbers are correct for 10 bins, and I match all of them to 4 decimal places.")
w("")
w("| check | result |")
w("|---|---|")
w(f"| 1. coverage + per-row sha256: {cov['files']} files (51 core, 46 red-team) | {cov['ok']}/{cov['files']} exact |")
w(f"| 2-3. recomputed vs results_summary.json / report.json / redteam_report.json | {A['n_pass']}/{A['n_compared']} PASS, {nf} FAIL |")
w("| ECE at 15 bins vs reported (10-bin) values | " f"{len(ece_diff)}/51 cells differ, max {ece_max:.4f} (definition, see below) |")
w(f"| values not reported at all | 3 (`injection.clean_reference` lacks the new models) |")
w("| 4. training log: full runs, epochs and steps as claimed | yes |")
w("| 4. anything selected on test | no evidence in the code or the log (see caveats) |")
w(f"| 4. BANKING77 test texts also in training (normalised) | {L['test_in_train_normalised']} in train, "
  f"{L['test_in_val_normalised']} in val (0 exact) |")
w("| 4. BEMA v3 93.1% plausible | yes; at or just below published fine-tuned BERT-base |")
w("")

# ---------------- coverage
w("## 1. Coverage and sha256")
w("")
w("Every input row's `text_sha256` / `state_sha256` equals the sha256 of its text "
  f"({len(A['input_self_hash_mismatches'])} mismatches). Each prediction file has exactly the input's idx/key set, "
  "with no extras, gaps or duplicates, and the hash matches on every row. Values are well-formed: preds are in range, "
  "conf is in [0, 1], and for spam `pred == (p_yes > 0.5)` and `conf == max(p, 1-p)`.")
w("")
w("- Core files: 4 BEMA models x 11 (7 BANKING77 + 4 spam) + zs3_from_clinc x 7 = 51.")
w("- Red-team files: 16 each for bema_v2_full_gpu and bema_v3 (every test whose qset is banking, shuffled, defended, "
  "spam or stars), 11 for zs3_from_clinc (banking qsets), and 3 for zs3_from_banking (clinc150_clean, clinc150_swap2, "
  "injection_oos_clinc). That is 46 files, with none missing and none unexpected.")
w("- Spam label convention: label 1 is the raw CSV's `spam` on all 116 label-1 rows, and label 0 is `ham` on all 720 "
  "label-0 rows. So pred 1 = spam = label 1 is consistent. ood_spam_on_banking gold is 0 on every row, and "
  "evasion_spam gold is 1 on every row.")
w("")

# ---------------- banking table
w("## 2-3. Recomputed vs reported")
w("")
w("Cells show **recomputed** values. All of them equal the reported value after the report's rounding, and any "
  "exception would be marked. Accuracy is in %.")
w("")
w("### BANKING77 accuracy, n = 3,080 per condition")
w("")
w("| model | " + " | ".join(BANK) + " |")
w("|---|" + "---|" * len(BANK))
for m in CORE:
    cells = []
    for c in BANK:
        a = REC["banking77"][f"{m}|{c}"]["accuracy"]
        rep = SS["banking77_typos"]["rows"][c][m]["accuracy_pct"]
        cells.append(p1(a) + mark(rep, 100 * a, 0.05))
    w(f"| {m} | " + " | ".join(cells) + " |")
w("")
w("### BANKING77 ECE: reported (10 bins) / my 10-bin / my 15-bin")
w("")
w("| model | " + " | ".join(BANK) + " |")
w("|---|" + "---|" * len(BANK))
for m in CORE:
    cells = []
    for c in BANK:
        r = REC["banking77"][f"{m}|{c}"]
        rep = SS["banking77_typos"]["rows"][c][m]["ece"]
        cells.append(f"{rep:.4f} / {r['ece10']:.4f}{mark(rep, r['ece10'], 0.00005)} / {r['ece15']:.4f}")
    w(f"| {m} | " + " | ".join(cells) + " |")
w("")
w("### Spam (n = 836; 116 spam): accuracy % and ECE reported (10 bins) / my 15-bin")
w("")
w("| model | " + " | ".join(SPAM) + " |")
w("|---|" + "---|" * len(SPAM))
for m in CORE[:4]:
    cells = []
    for c in SPAM:
        r = REC["spam"][f"{m}|{c}"]
        rep = SS["spam"]["rows"][c][m]
        cells.append(f"{p1(r['accuracy'])}{mark(rep['accuracy_pct'], 100 * r['accuracy'], 0.05)}; "
                     f"{rep['ece']:.4f}{mark(rep['ece'], r['ece10'], 0.00005)} / {r['ece15']:.4f}")
    w(f"| {m} | " + " | ".join(cells) + " |")
w("")
ex = REC["spam_excl_dups"]
w(f"On spam clean, excluding the {A['spam_dups']['exact']} exact-text duplicates of training messages (88 after "
  f"case and whitespace normalisation), I get bema_v2_full_gpu {p1(ex['bema_v2_full_gpu'][0])}% and bema_v3 "
  f"{p1(ex['bema_v3'][0])}% (n {ex['bema_v3'][1]}). Both match the summary. Precision, recall, F1, false alarms and "
  "missed spam in report.json also match for every condition.")
w("")
w("### Paired accuracy difference vs Jev, clean BANKING77")
w("")
w(f"Jev has {A['jev_clean_ok_rows']}/3080 `status: ok` rows, and its accuracy is {p1(A['jev_clean_accuracy'])}% "
  "(using the `choice` field, which is in `probabilities` on every row). I used a percentile bootstrap over queries "
  "with 10,000 resamples and my own seed. The summary uses 2,000 resamples with seed 0, so I allow 0.2 points on the "
  "CI endpoints.")
w("")
w("| model | reported gap [CI] | recomputed gap [CI] | model-only right / Jev-only right |")
w("|---|---|---|---|")
for m in CORE:
    p = REC["paired"][m]
    s = SS["banking77_paired_vs_jev"]["rows"][m]
    w(f"| {m} | {s['minus_jev_points']:+.1f} [{s['ci95_points'][0]:+.1f}, {s['ci95_points'][1]:+.1f}] | "
      f"{100 * p['diff']:+.2f} [{100 * p['ci'][0]:+.2f}, {100 * p['ci'][1]:+.2f}] | {p['model_only_right']} / {p['jev_only_right']} |")
w("")
w("report.json's `jev_minus_<model>_accuracy` diffs match exactly, with the sign flipped. Its CIs match within 0.002.")
w("")

# ---------------- injection
w("### Injection: the 1,000-query sample and the 250-key slice")
w("")
w("I rebuilt the sample as `sorted(random.Random(7).sample(range(3080), 1000))`. It equals the key set and `meta.idx` "
  "of `runs/redteam/inputs/injection_banking.jsonl`. The slice is `random.Random(11).sample(sample, 250)`, which is "
  "the same construction as `llm_baseline.subsample_keys` (`random.Random(11).sample(redteam_jev.sample_idx(), n)`). "
  f"It covers {A['slice250_distinct_gold_intents']} distinct gold intents, and its first sorted keys are "
  f"{A['slice250_first10_sorted'][:6]}. 'Followed' means pred == `meta.target`.")
w("")
w("| test | model | acc % (1,000) | followed % (1,000) | mean conf | acc % (250) | followed % (250) |")
w("|---|---|---|---|---|---|---|")
for t in ("injection_banking", "injection_prefix_banking", "injection_casual_banking", "injection_control_banking"):
    for m in RTM:
        e = REC["injection"][f"{t}|{m}"]
        sl = (f"{p1(e['slice_acc'])}" if t != "injection_prefix_banking" else f"{p1(e['slice_acc'])} (not in summary)")
        fl = "" if e["followed"] is None else p1(e["followed"])
        sf = "" if e["slice_followed"] is None else (p1(e["slice_followed"]) + (" (not in summary)" if t == "injection_prefix_banking" else ""))
        w(f"| {t} | {m} | {p1(e['accuracy'])} | {fl} | {e['mean_confidence']:.3f} | {sl} | {sf} |")
w("")
w("All of these match `injection` and `slice250_all_models` in the summary and `followed_injected_label` / accuracy / "
  "mean_confidence / ECE / clean_accuracy_same_examples in redteam_report.json. The summary's slice has no prefix row, "
  "so those two slice cells are mine only. The summary shows `injection_defended_banking` and "
  "`injection_casual_defended_banking` as copies of the undefended rows for these models. That copying is legitimate: "
  "the defended input text is identical, and the predictions in the separately written defended files are identical "
  "(1000/1000, max conf difference 0.0) for all three models.")
w("")
w("Clean BANKING77 slice250: " + ", ".join(f"{m} {p1(REC['slice_core'][m + '|clean'][0])}" for m in CORE) +
  ". swap2: " + ", ".join(f"{m} {p1(REC['slice_core'][m + '|swap2'][0])}" for m in CORE) + ". All match.")
w("")

# ---------------- other red-team
w("### Other red-team tests")
w("")
w("| test | metric | bema_v2_full_gpu | bema_v3 | zs3_from_clinc |")
w("|---|---|---|---|---|")
sr = REC["spam_redteam"]
w(f"| ood_spam_on_banking (n 1,000, gold not-spam) | accuracy % | {p1(sr['ood_spam_on_banking|bema_v2_full_gpu']['accuracy'])} | "
  f"{p1(sr['ood_spam_on_banking|bema_v3']['accuracy'])} | n/a |")
w(f"| evasion_spam (n 116) | accuracy % | {p1(sr['evasion_spam|bema_v2_full_gpu']['accuracy'])} | {p1(sr['evasion_spam|bema_v3']['accuracy'])} | n/a |")
w(f"| injection_spam (n 116) | accuracy % | {p1(sr['injection_spam|bema_v2_full_gpu']['accuracy'])} | {p1(sr['injection_spam|bema_v3']['accuracy'])} | n/a |")
g = REC["gibberish"]
w(f"| gibberish_banking (n 100) | mean confidence, all | {g['bema_v2_full_gpu']['all']:.4f} | {g['bema_v3']['all']:.4f} | {g['zs3_from_clinc']['all']:.4f} |")
w(f"| gibberish_banking | mean conf, digits_symbols | {g['bema_v2_full_gpu']['digits_symbols']:.4f} | {g['bema_v3']['digits_symbols']:.4f} | {g['zs3_from_clinc']['digits_symbols']:.4f} |")
sc = REC["score"]
w(f"| score_amazon_clean (n 1,517) | Pearson r, expected stars vs gold | {sc['score_amazon_clean|bema_v2_full_gpu']['pearson']:.4f} | {sc['score_amazon_clean|bema_v3']['pearson']:.4f} | n/a |")
w(f"| score_amazon_swap2 | Pearson r | {sc['score_amazon_swap2|bema_v2_full_gpu']['pearson']:.4f} | {sc['score_amazon_swap2|bema_v3']['pearson']:.4f} | n/a |")
w(f"| score_amazon_clean | MAE stars | {sc['score_amazon_clean|bema_v2_full_gpu']['mae']:.4f} | {sc['score_amazon_clean|bema_v3']['mae']:.4f} | n/a |")
os_ = REC["order_shuffle"]
w(f"| order_shuffle_banking (n 1,000) | accuracy % | {p1(os_['bema_v2_full_gpu']['accuracy'])} | {p1(os_['bema_v3']['accuracy'])} | {p1(os_['zs3_from_clinc']['accuracy'])} |")
w("")
w("Every cell matches redteam_report.json and the copy in the summary's `redteam_other` at full precision. The checks "
  "also cover mean_p_spam, clean_recall_same_examples, the per-kind gibberish confidences, share >= 0.5 and >= 0.9, "
  "exact and within-one-star rates, and the ECEs. Amazon gold, `round(4*label)+1`, matches the pickle on all 1,517 rows.")
w("")
w("### CLINC150, zs3_from_banking")
w("")
w("| test | accuracy % | in-scope acc % | OOS recall % | false-OOS on in-scope % | said OOS % | ECE (10-bin) |")
w("|---|---|---|---|---|---|---|")
for t in ("clinc150_clean", "clinc150_swap2", "injection_oos_clinc"):
    e = REC["clinc_zs3_from_banking"][t]
    oos = "n/a (no OOS gold)" if e["oos_recall"] is None else p1(e["oos_recall"])
    w(f"| {t} | {p1(e['accuracy'])} | {p1(e['in_scope_acc'])} | {oos} | {p1(e['false_oos'])} | {p1(e['said_oos'])} | {e['ece10']:.4f} |")
w("")
ag = A["injection_oos_clinc_pred_agreement_with_other_models"]
w("All values match. On injection_oos_clinc, zs3_from_banking and bema_clinc150 both score exactly 39.6%. I checked "
  "whether one file was a copy of the other. It is not: they agree on only "
  f"{ag['injection_oos_clinc__bema_clinc150.jsonl']}/1000 predictions, so the tie is a coincidence.")
w("")

# ---------------- sanity
w("## 4. Sanity checks")
w("")
w("### Training log (`runs/gpu/gpu_run.log`)")
w("")
w("| stage | claimed | in the log |")
w("|---|---|---|")
w("| BEMA v2 full (MiniLM-L6) | 3 epochs, 266 steps/epoch | epochs 1-3, each logging steps 0..250 of /266; "
  "val choice acc 0.724, 0.835, 0.845; temperatures noul 1.071, choice 0.516 |")
w("| BEMA v3 (bge-base) | 4 epochs, 266 steps/epoch | epochs 1-4, each 0..250 of /266; val choice acc 0.840, 0.907, "
  "0.924, 0.927; temperatures noul 1.307, choice 0.742 |")
w("| zs3_from_clinc | 2 epochs | 2 x 471 steps. 471 = floor((15,000 train + 100 oos_train) / 32) |")
w("| zs3_from_banking | 2 epochs | 2 x 265 steps. 265 = floor(8,503 / 32) |")
w("")
w("- **Not a `--quick` run.** Quick mode sets `V2_MAX_STEPS=5, V2_EPOCHS=1` and `ZS_MAX_STEPS=5`. The log shows the "
  "full step counts. 266 = ceil(8,503 / 32), the BANKING77 training size. Every stage exits 0, and the input check "
  "passed ('All 32 input files match the cloud run exactly').")
w("- The trainable parameter counts (10.8M of 22.7M; 85.7M of 109.5M) are what V2_FREEZE=0 gives with the token and "
  "position embeddings frozen. So 'all layers' means all transformer layers. The embeddings stay frozen, as in "
  "`bema_v2.py`.")
w("- The speller-changed counts in the log (37, 2986, 3060, 2989, 2631, 3041, 3021 / 214, 775, 805, 817) equal what "
  "I count from `runs/bema/spell_texts`. On every text the speller left unchanged, each `_spell` file has the same "
  "prediction as its base model in all 22 files, with conf within 1.2e-6. So both come from the same checkpoint.")
w("- The red-team files that hold clean BANKING77 text (order_shuffle, latency_sequential, repeat_banking_spread) "
  "reproduce the core clean predictions 100% for all three models, with conf within 1.6e-6. That is GPU batch-padding "
  "noise. So the core and red-team files come from the same checkpoint.")
w("- Cross-check vs the cloud run: the cloud `bema_v2_full` (runs/bema_v2_full.log) was killed in epoch 3 (EXIT 143). "
  "Its epochs 1-2 track the GPU run closely: loss 3.6367 / 1.6794 vs 3.6379 / 1.6758, and val choice acc 0.709 / "
  "0.835 vs 0.724 / 0.835. That is consistent with the same code and seed on different hardware. There are no cloud "
  "test predictions for bema_v2_full to compare.")
w("")
w("### Selection on the test set")
w("")
w("I found none in the code paths that produced these files. `bema_v2.py train` uses the train split for gradients. "
  "It picks the best epoch by a validation score, which here was the last epoch for both models, and fits the "
  "temperatures on the clean validation split. `bema_zeroshot.py` trains on the source dataset's train split and fits "
  "temperatures on the source validation split, as the log says: 'clinc validation split' for zs3_from_clinc, "
  "'banking validation split' for zs3_from_banking. The speller's dictionaries come from training text only. "
  "`gpu_run.py` runs one fixed configuration per model, with no sweep.")
w("")
w("There are two things I cannot rule out from the repo:")
w("1. The hyperparameters (bge-base, CLS pooling for zero-shot, learning rates 5e-5 / 3e-5, 3 / 4 epochs) were "
  "chosen after the cloud runs' test results were visible.")
w("2. `gpu_run.py` truncates the log on every start (`open(LOG, 'w')`), so earlier attempts on the laptop would "
  "leave no trace.")
w("")
w("### Train/test overlap (BANKING77)")
w("")
w(f"`prepare_multitask.py` uses the official BANKING77 files. The test split is `banking_test.csv` (3,080 rows, "
  f"identical to the frozen inputs: {L['test_texts_matching_frozen_inputs']}). The training data is "
  "`banking_train.csv` (10,003 rows), shuffled with seed 42 and split into 15% val (1,500) and 8,503 train. My "
  "rebuilt train + val equals the raw train file as a multiset.")
w("")
w(f"- Exact text matches, test in train: {L['test_in_train_exact']}.")
w(f"- After lower-casing, stripping and collapsing whitespace: {L['test_in_train_normalised']} test texts are in "
  f"train and {L['test_in_val_normalised']} in val ({L['test_in_train_or_val_normalised']} in either). All "
  f"{L['leaked_with_same_label']} train matches carry the same label. Examples: "
  + "; ".join(f"`{t.strip()}`" for t in L["examples_in_train"][:5]) + ".")
w(f"- Impact is negligible. bema_v3 scores {p1(L['bema_v3_acc_excluding_leaked'])}% without those "
  f"{L['test_in_train_normalised']} rows (it gets all of them right), bema_v2_full_gpu "
  f"{p1(L['bema_v2_full_gpu_acc_excluding_leaked'])}%, and Jev {p1(L['jev_acc_excluding_leaked'])}%.")
w(f"- Zero-shot cross-dataset overlap: {L['banking_test_in_clinc_train_normalised']} BANKING77 test texts appear in "
  f"CLINC150 train, and {L['clinc_test_in_banking_train_normalised']} CLINC150 test texts appear in BANKING77 train.")
w("")
w("### Is 93.1% for BEMA v3 plausible?")
w("")
w("Yes. I am working from memory with no web access, so treat these figures as approximate. The BANKING77 paper "
  "(Casanueva et al., 2020, 'Efficient Intent Detection with Dual Sentence Encoders') reports about 93.7% for "
  "fine-tuned BERT-base on the full 10,003-example training set. In the same table, USE+ConveRT sentence-encoder "
  "classifiers are about 93.0-93.4% and frozen BERT is about 87%. Later fine-tuned base-size encoders (RoBERTa-base, "
  "contrastive pre-finetuning variants) usually land around 93-94.5%.")
w("")
w("bge-base-en-v1.5 is a BERT-base-sized encoder (109.5M). Here it was trained on 85% of the training set (8,503 "
  "rows), with inputs truncated to 64 tokens, typo augmentation on half the examples, and a multi-task loss, for 4 "
  "epochs. 93.1% sits right at, or slightly below, the published fine-tuned BERT-base figure. Its own validation "
  "accuracy is 92.7%, so there is no suspicious gap between validation and test. A number well above about 95% "
  "would have been a red flag. This is not.")
w("")

# ---------------- concerns
w("## Concerns (none change a reported number)")
w("")
w(f"1. **ECE bin count is undocumented, and the 15-bin values differ.** The summary and reports use 10 bins. At 15 "
  f"bins, {len(ece_diff)}/51 new-model cells change at 4 decimal places, by up to {ece_max:.4f}. The largest change "
  "is zs3_from_clinc clean, 0.0207 -> 0.0327. Some rankings flip. On clean BANKING77, bema_v2_full_gpu has the lowest "
  "ECE at 10 bins (0.0125 vs bema_v3 0.0138), but at 15 bins bema_v3 is lower (0.0147 vs 0.0170). State the bin "
  "count in the summary, and do not rank models on ECE differences of about 0.001-0.005. These are within "
  "binning noise at n = 3,080.")
w("2. **`injection.clean_reference` omits the new models.** It lists only jev, bema_baseline and bema_v2. On the same "
  "1,000 keys, my values are "
  + ", ".join(f"{m} {v:.1f}%" for m, v in A["clean_reference_new_models_pct"].items())
  + ". These are also what redteam_report.json's clean_accuracy_same_examples shows.")
w("3. **The GPU results can't be reproduced from the repo.** The checkpoints (`bema_v2_full_gpu.pt`, `bema_v3.pt`) "
  "and the `zs3_from_clinc/` and `zs3_from_banking/` encoders are not in the repo. I could only check the prediction "
  "files' internal consistency. That consistency is strong: hashes, same-checkpoint agreement across core, red-team "
  "and speller files, and log counts. Archive the checkpoints, or their sha256 plus the gpu_results.zip hash, if "
  "these numbers will be published.")
w("4. **MiniLM vs bge-base confounds model size with training budget.** bema_v2_full_gpu's validation accuracy was "
  "still rising at its last epoch (0.835 -> 0.845). It got 3 epochs at 5e-5, while v3 got 4 epochs at 3e-5. Its "
  "82.9% is probably below what a longer MiniLM-L6 fine-tune would reach. So the +10.2-point v3 gain should not be "
  "read as purely model size. The v3 temperature (choice T = 0.74 < 1) shows the typed heads are under-confident before "
  "scaling, which is consistent with short training.")
w("5. **Small documentation drift.**")
w("   - The `bema_zeroshot.py` docstring still says fine-tuning 'trains only the top 3 of 6 encoder layers' on "
  "2 CPU cores. The zs3 runs used bge-base (12 layers) with ZS_FREEZE=0.")
w("   - 'All layers' in the log titles means all transformer layers; the embeddings were frozen.")
w("   - The gpu_run.py docstring calls bema_v2_full_gpu a cross-check of the cloud run, but no completed cloud run "
  "exists (see above).")
w("6. **Test-set hygiene can't be fully verified.** See 'Selection on the test set' above: the hyperparameters may "
  "have been chosen after the cloud test results were visible, and the log is overwritten on each run. I found "
  "nothing in the code that touches test labels before scoring.")
w("")
w("## Files")
w("")
w("- `runs/audit/pass4/audit4.py`: coverage, the recomputation, the comparisons and the leakage check. Writes `audit4.json`.")
w("- `runs/audit/pass4/spell_consistency.py`: checks that each speller variant matches its base model. Writes `spell_consistency.json`.")
w("- `runs/audit/pass4/write_md.py`: writes this file.")
open("runs/audit/AUDIT_PASS4.md", "w").write("\n".join(o) + "\n")
print("wrote runs/audit/AUDIT_PASS4.md")
