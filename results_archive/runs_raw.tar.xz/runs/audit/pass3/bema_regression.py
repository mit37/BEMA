"""Check 1a: recompute every BEMA / zero-shot metric in runs/report.json and runs/redteam_report.json
from the raw prediction files, with this audit's own code. Also integrity of the prediction files."""
import glob
import json
import os
from collections import Counter

import numpy as np

from common import ROOT, P2, Cmp, boot, cats, mean, pearson, rj, sample_idx, sha, summ

CATS = cats()
rep = json.load(open(f"{ROOT}/runs/report.json"))
rrep = json.load(open(f"{ROOT}/runs/redteam_report.json"))
C = Cmp()
INTEG = {}
EXTRA = {}

TASKS = {"banking77": ["clean", "swap2", "swap4", "keyboard2", "delete2", "insert2", "mixed3"],
         "spam": ["clean", "swap2", "keyboard2", "mixed3"]}
inputs = {(t, c): {r["idx"]: r for r in rj(f"{ROOT}/runs/inputs/{t}_{c}.jsonl")} for t in TASKS for c in TASKS[t]}


def jev_correct(task, cond):
    I = inputs[(task, cond)]
    out = {}
    for r in rj(f"{ROOT}/runs/jev/{task}_{cond}.jsonl"):
        if r["status"] != "ok":
            continue
        a = r["response"]["answers"]
        if task == "banking77":
            out[r["idx"]] = float(a["intent"]["choice"] == CATS[I[r["idx"]]["label"]])
        else:
            out[r["idx"]] = float((1 if a["is_spam"]["noul"] > 0.5 else 0) == I[r["idx"]]["label"])
    return out


# ------------------------------------------------------------------ core files
model_files = sorted({os.path.basename(p)[:-6].rsplit("_", 2)[0] for p in glob.glob(f"{ROOT}/runs/bema/*_*_*.jsonl")})
models = sorted({p.split("/")[-1].replace(".jsonl", "") for p in glob.glob(f"{ROOT}/runs/bema/*.jsonl")})
core_models = sorted({m for m in [os.path.basename(p)[:-6] for p in glob.glob(f"{ROOT}/runs/bema/*.jsonl")]
                      for _ in [0]})
present = {}
for p in glob.glob(f"{ROOT}/runs/bema/*.jsonl"):
    b = os.path.basename(p)[:-6]
    for t in TASKS:
        for c in TASKS[t]:
            suf = f"_{t}_{c}"
            if b.endswith(suf):
                present.setdefault(b[: -len(suf)], []).append((t, c))
EXTRA["core_models_present"] = {m: sorted(f"{t}/{c}" for t, c in v) for m, v in present.items()}

core = {}   # (model, task, cond) -> idx -> (correct, conf, pred)
for m, tc in present.items():
    for t, c in tc:
        I = inputs[(t, c)]
        recs = rj(f"{ROOT}/runs/bema/{m}_{t}_{c}.jsonl")
        ids = Counter(r["idx"] for r in recs)
        bad_sha = sum(1 for r in recs if r["text_sha256"] != I[r["idx"]]["text_sha256"])
        bad_pred = sum(1 for r in recs if not (isinstance(r["pred"], int) and (0 <= r["pred"] < 77 if t == "banking77" else r["pred"] in (0, 1))))
        bad_conf = sum(1 for r in recs if not (0 <= r["conf"] <= 1))
        spam_conf_rule = None
        if t == "spam" and "p_yes" in recs[0]:
            spam_conf_rule = sum(1 for r in recs if abs(r["conf"] - max(r["p_yes"], 1 - r["p_yes"])) > 1e-6
                                 or r["pred"] != int(r["p_yes"] > 0.5))
        lowconf_banking = sum(1 for r in recs if t == "banking77" and r["conf"] < 1 / 77 - 1e-6)
        INTEG[f"{m}/{t}/{c}"] = {"n": len(recs), "dup_idx": sum(v - 1 for v in ids.values() if v > 1),
                                 "missing_idx": len(set(I) - set(ids)), "extra_idx": len(set(ids) - set(I)),
                                 "sha_mismatch": bad_sha, "bad_pred": bad_pred, "conf_out_of_range": bad_conf,
                                 "spam_conf_or_pred_inconsistent_with_p_yes": spam_conf_rule,
                                 "banking_conf_below_1_over_77": lowconf_banking}
        d = {}
        for r in recs:
            g = CATS[I[r["idx"]]["label"]] if t == "banking77" else I[r["idx"]]["label"]
            p = CATS[r["pred"]] if t == "banking77" else r["pred"]
            d[r["idx"]] = (float(p == g), float(r["conf"]), r["pred"])
        core[(m, t, c)] = d

jevc = {(t, c): jev_correct(t, c) for t in TASKS for c in TASKS[t]}
REPORTED_MODELS = set()
for t in TASKS:
    for c in TASKS[t]:
        res = rep["tasks"][t][c]
        for m, R in res.items():
            if m == "jev" or m.startswith("jev_minus_"):
                continue
            REPORTED_MODELS.add(m)
            sec = f"report {t}/{c}/{m}"
            d = core.get((m, t, c))
            if d is None:
                C.add(sec, "prediction file exists", True, False)
                continue
            ids = sorted(d)
            S = summ([d[i][0] for i in ids], [d[i][1] for i in ids])
            for k in ["n", "accuracy", "mean_confidence", "overconfidence"]:
                C.add(sec, k, R[k], S[k])
            C.add(sec, "ece (exact edges)", R["ece"], S["ece"], 1e-6)
            C.add(sec, "ece_repo_float32_edges", R["ece_repo_float32_edges"], S["ece_repo_float32_edges"], 1e-6)
            C.add(sec, "accuracy_ci95 (Wilson)", R["accuracy_ci95"], S["accuracy_ci95"], 1e-9)
            if t == "spam":
                preds = {i: d[i][2] for i in ids}
                lab = {i: inputs[(t, c)][i]["label"] for i in ids}
                tp = sum(1 for i in ids if preds[i] == 1 and lab[i] == 1)
                fp = sum(1 for i in ids if preds[i] == 1 and lab[i] == 0)
                fn = sum(1 for i in ids if preds[i] == 0 and lab[i] == 1)
                prec, recl = tp / (tp + fp), tp / (tp + fn)
                C.add(sec, "spam_precision", R["spam_precision"], prec)
                C.add(sec, "spam_recall", R["spam_recall"], recl)
                C.add(sec, "spam_f1", R["spam_f1"], 2 * prec * recl / (prec + recl))
                C.add(sec, "false_alarms_on_ham", R["false_alarms_on_ham"], fp)
                C.add(sec, "missed_spam", R["missed_spam"], fn)
            if c != "clean":
                d0 = core[(m, t, "clean")]
                C.add(sec, "accuracy_drop_from_clean", R["accuracy_drop_from_clean"],
                      mean(v[0] for v in d0.values()) - S["accuracy"])
                C.add(sec, "confidence_drop_from_clean", R["confidence_drop_from_clean"],
                      mean(v[1] for v in d0.values()) - S["mean_confidence"])
                diffs = [d0[i][0] - d[i][0] for i in ids]
                C.add(sec, "accuracy_drop_ci95_paired_bootstrap (own bootstrap, tol 0.005)",
                      R["accuracy_drop_ci95_paired_bootstrap"], boot(diffs), 0.005)
            J = res.get(f"jev_minus_{m}_accuracy")
            if J:
                jc = jevc[(t, c)]
                diffs = [jc[i] - d[i][0] for i in sorted(jc)]
                C.add(sec, "jev_minus_model diff", J["diff"], mean(diffs))
                C.add(sec, "jev_minus_model n", J["n"], len(diffs))
                C.add(sec, "jev_minus_model ci95 (own bootstrap, tol 0.005)", J["ci95"], boot(diffs), 0.005)
for m, tc in present.items():
    for t, c in tc:
        if m not in rep["tasks"][t][c]:
            EXTRA.setdefault("prediction_files_not_in_report", []).append(f"{m}/{t}/{c}")
C.add("report", "spam_majority_baseline_accuracy", rep["spam_majority_baseline_accuracy"],
      1 - mean(r["label"] for r in inputs[("spam", "clean")].values()))
EXTRA["timing_json"] = json.load(open(f"{ROOT}/runs/bema/timing_quiet.json"))
C.add("report", "bema_latency equals runs/bema/timing_quiet.json", json.dumps(rep.get("bema_latency"), sort_keys=True),
      json.dumps(EXTRA["timing_json"], sort_keys=True))

# ------------------------------------------------------------------ red-team files
rt_inputs = {os.path.basename(p)[:-6]: rj(p) for p in glob.glob(f"{ROOT}/runs/redteam/inputs/*.jsonl")}
rt_bema = {}
for p in glob.glob(f"{ROOT}/runs/redteam/bema/*.jsonl"):
    test, m = os.path.basename(p)[:-6].split("__")
    items = {it["key"]: it for it in rt_inputs[test]}
    recs = rj(p)
    keys = Counter(r["key"] for r in recs)
    qset = rt_inputs[test][0]["qset"]
    opts = None
    if qset in ("banking", "banking_defended", "banking_shuffled"):
        opts = set(CATS)
    elif qset == "clinc":
        raw = json.load(open(f"{ROOT}/data/raw/clinc150_data_full.json"))
        opts = set(sorted({l for _, l in raw["train"]}) + ["oos"])
    INTEG[f"redteam {test}__{m}"] = {
        "n": len(recs), "items": len(items), "dup_keys": sum(v - 1 for v in keys.values() if v > 1),
        "missing_keys": len(set(items) - set(keys)), "extra_keys": len(set(keys) - set(items)),
        "sha_mismatch": sum(1 for r in recs if r["key"] in items and r["state_sha256"] != items[r["key"]]["state_sha256"]),
        "input_sha_mismatch": sum(1 for it in items.values() if sha(it["state"]) != it["state_sha256"]),
        "pred_not_an_option": (sum(1 for r in recs if r["pred"] not in opts) if opts else None)}
    rt_bema[(test, m)] = {r["key"]: r for r in recs}

core_clean_by_idx = {m: core[(m, "banking77", "clean")] for m, tc in present.items() if ("banking77", "clean") in tc}
core_spam_by_idx = {m: core[(m, "spam", "clean")] for m, tc in present.items() if ("spam", "clean") in tc}

for test, T in rrep["tests"].items():
    items = rt_inputs[test]
    for m, R in T.items():
        if m in ("jev", "jev_calls", "note", "gold_distribution") or not isinstance(R, dict):
            continue
        sec = f"redteam {test}/{m}"
        recs = rt_bema.get((test, m))
        if recs is None:
            C.add(sec, "prediction file exists", True, False)
            continue
        rows = [(it, recs[it["key"]]) for it in items if it["key"] in recs]
        if test == "gibberish_banking":
            for kd, v in R.items():
                cf = [r["conf"] for it, r in rows if kd == "all" or it["meta"]["kind"] == kd]
                C.add(sec, f"{kd}: n", v["n"], len(cf))
                C.add(sec, f"{kd}: mean_confidence", v["mean_confidence"], mean(cf))
                C.add(sec, f"{kd}: share_confidence_ge_0.9", v["share_confidence_ge_0.9"], mean(float(c >= 0.9) for c in cf))
                C.add(sec, f"{kd}: share_confidence_ge_0.5", v["share_confidence_ge_0.5"], mean(float(c >= 0.5) for c in cf))
            continue
        if test.startswith("score_amazon"):
            g = [it["gold"] for it, _ in rows]
            e = [r["stars_expected"] for _, r in rows]
            C.add(sec, "n", R["n"], len(rows))
            C.add(sec, "pearson_r_expected_stars", R["pearson_r_expected_stars"], pearson(e, g), 1e-9)
            C.add(sec, "mae_stars_expected", R["mae_stars_expected"], mean(abs(a - b) for a, b in zip(e, g)))
            # Python round() is banker's rounding; check how many expectations sit exactly on .5
            C.add(sec, "exact_star_accuracy_rounded", R["exact_star_accuracy_rounded"],
                  mean(float(round(a) == b) for a, b in zip(e, g)))
            C.add(sec, "within_one_star_rounded", R["within_one_star_rounded"],
                  mean(float(abs(round(a) - b) <= 1) for a, b in zip(e, g)))
            EXTRA.setdefault("amazon_bema_baselines", {})[f"{test}/{m}"] = {
                "always_5_exact": mean(float(b == 5) for b in g), "always_5_mae": mean(abs(5 - b) for b in g),
                "predicted_mean_stars": mean(e), "share_expected_ge_4.5": mean(float(a >= 4.5) for a in e)}
            continue
        corr = [float(r["pred"] == it["gold"]) for it, r in rows]
        S = summ(corr, [r["conf"] for _, r in rows])
        for k in ["n", "accuracy", "mean_confidence", "overconfidence"]:
            if k in R:
                C.add(sec, k, R[k], S[k])
        C.add(sec, "ece", R["ece"], S["ece"], 1e-6)
        C.add(sec, "accuracy_ci95 (Wilson)", R["accuracy_ci95"], S["accuracy_ci95"])
        if "clean_accuracy_same_examples" in R:
            cc = core_clean_by_idx[m]
            C.add(sec, "clean_accuracy_same_examples", R["clean_accuracy_same_examples"],
                  mean(cc[it["meta"]["idx"]][0] for it, _ in rows))
        if "followed_injected_label" in R:
            C.add(sec, "followed_injected_label", R["followed_injected_label"],
                  mean(float(r["pred"] == it["meta"]["target"]) for it, r in rows))
        if "mean_p_spam" in R:
            C.add(sec, "mean_p_spam", R["mean_p_spam"], mean(r["p_yes"] for _, r in rows))
        if "clean_recall_same_examples" in R:
            cs = core_spam_by_idx[m]
            C.add(sec, "clean_recall_same_examples", R["clean_recall_same_examples"],
                  mean(float(cs[it["meta"]["idx"]][2] == 1) for it, _ in rows))
        if "in_scope_accuracy" in R:
            ins = [(it, r) for it, r in rows if it["gold"] != "oos"]
            oo = [(it, r) for it, r in rows if it["gold"] == "oos"]
            C.add(sec, "in_scope_accuracy", R["in_scope_accuracy"], mean(float(r["pred"] == it["gold"]) for it, r in ins))
            C.add(sec, "oos_recall", R["oos_recall"], mean(float(r["pred"] == "oos") for _, r in oo))
            C.add(sec, "false_oos_rate_on_in_scope", R["false_oos_rate_on_in_scope"], mean(float(r["pred"] == "oos") for _, r in ins))
            C.add(sec, "n_in_scope", R["n_in_scope"], len(ins))
            C.add(sec, "n_oos", R["n_oos"], len(oo))
        if "said_oos_with_note" in R:
            C.add(sec, "said_oos_with_note", R["said_oos_with_note"], mean(float(r["pred"] == "oos") for _, r in rows))
            base = rt_bema.get(("clinc150_clean", m))
            if base:
                EXTRA.setdefault("oos_injection_bema_baseline_without_note", {})[m] = mean(
                    float(base[str(it["meta"]["idx"])]["pred"] == "oos") for it, _ in rows)

# red-team BEMA files that exist but are NOT in the report
for (test, m) in rt_bema:
    if test not in rrep["tests"] or m not in rrep["tests"][test]:
        EXTRA.setdefault("redteam_bema_files_not_in_report", []).append(f"{test}__{m}")

# ------------------------------------------------------------------ extra facts used in the write-up
# defended vs undefended BEMA files identical?
ident = {}
for m in ["bema_baseline", "bema_v2", "zs_offshelf", "zs_from_clinc"]:
    for a, b in [("injection_banking", "injection_defended_banking"),
                 ("injection_casual_banking", "injection_casual_defended_banking")]:
        A, Bb = rt_bema.get((a, m)), rt_bema.get((b, m))
        if A and Bb:
            ident[f"{m}: {a} vs {b}"] = sum(1 for k in A if (A[k]["pred"], round(A[k]["conf"], 9)) != (Bb[k]["pred"], round(Bb[k]["conf"], 9)))
EXTRA["defended_vs_undefended_bema_differences"] = ident
# order shuffle: BEMA answers identical to its clean answers?
osh = {}
for m in ["bema_baseline", "bema_v2", "zs_offshelf", "zs_from_clinc"]:
    R_ = rt_bema.get(("order_shuffle_banking", m))
    if R_:
        cc = core[(m, "banking77", "clean")]
        osh[m] = sum(1 for k, r in R_.items() if CATS.index(r["pred"]) != cc[int(k)][2])
EXTRA["order_shuffle_bema_pred_differs_from_core_clean"] = osh
# repeat tests for BEMA: identical outputs across repeats?
rp = {}
for test in ["repeat_banking", "repeat_banking_spread", "latency_sequential_banking"]:
    for m in ["bema_baseline", "bema_v2", "zs_offshelf", "zs_from_clinc"]:
        R_ = rt_bema.get((test, m))
        if not R_:
            continue
        items = {it["key"]: it for it in rt_inputs[test]}
        cc = core[(m, "banking77", "clean")]
        rp[f"{test}/{m}"] = {"pred_differs_from_core_clean": sum(1 for k, r in R_.items() if CATS.index(r["pred"]) != cc[items[k]["meta"]["idx"]][2]),
                             "max_conf_diff_vs_core": max(abs(r["conf"] - cc[items[k]["meta"]["idx"]][1]) for k, r in R_.items())}
EXTRA["bema_repeat_consistency"] = rp
# BEMA spam: majority baseline, ood
EXTRA["spam_confusion_bema"] = {}
for m in present:
    for c in TASKS["spam"]:
        if (m, "spam", c) in core:
            d = core[(m, "spam", c)]
            lab = {i: inputs[("spam", c)][i]["label"] for i in d}
            EXTRA["spam_confusion_bema"][f"{m}/{c}"] = {
                "tp": sum(1 for i in d if d[i][2] == 1 and lab[i] == 1), "fp": sum(1 for i in d if d[i][2] == 1 and lab[i] == 0),
                "fn": sum(1 for i in d if d[i][2] == 0 and lab[i] == 1)}
# bge_base condition coverage
EXTRA["bge_base_conditions"] = present.get("zs_offshelf_bge_base")

json.dump({"rows": C.rows, "integrity": INTEG, "extra": EXTRA}, open(f"{P2}/bema_regression.json", "w"), indent=1, default=str)
fails = [r for r in C.rows if r["result"] == "FAIL"]
print(f"{len(C.rows)} rows, {len(fails)} FAIL")
for r in fails[:60]:
    print(r)
bad = {k: v for k, v in INTEG.items() if any((x or 0) for kk, x in v.items() if kk not in ("n", "items"))}
print("integrity problems:", json.dumps(bad, indent=0)[:3000])
print(json.dumps({k: v for k, v in EXTRA.items() if k not in ("core_models_present", "spam_confusion_bema")}, indent=0)[:4000])
