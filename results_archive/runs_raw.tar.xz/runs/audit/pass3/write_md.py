"""Writes runs/audit/AUDIT_PASS3.md from the pass-3 JSON outputs."""
import json

from common import ROOT, P2

j = lambda n: json.load(open(f"{P2}/{n}"))
llm, sm, br, jr, tp = j("check3_llm.json"), j("summary_check.json"), j("bema_regression.json"), j("jev_regression.json"), j("timing_plausibility.json")
nf = lambda rows: sum(r["result"] == "FAIL" for r in rows)


def f(v):
    if isinstance(v, bool) or v is None:
        return str(v)
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, float):
        return f"{v:.6g}"
    if isinstance(v, list):
        return "[" + ", ".join(f(a) for a in v) + "]"
    return str(v).replace("|", "\\|")


n = sm["notes"]
tq, tb = tp["timing_quiet"], tp["timing_busy"]
L = []
P = L.append
P("# Audit pass 3: regenerated results_summary.json, llm_report.json and the quiet BEMA timings")
P("")
P("This pass checks the files as they stand: `runs/results_summary.json` (generated 2026-10-27T21:38:53Z), `runs/llm_report.json` (21:38:20Z), "
  "and `runs/report.json` / `runs/redteam_report.json` (21:38:30Z / 21:38:46Z). The code is at commit d7aa954. All code is in "
  "`runs/audit/pass3/`, adapted from the pass-2 scripts. I did not rerun any report command, changed nothing outside `runs/audit/pass3/` "
  "and this file, made no network calls, and did not re-time anything.")
P("")
P("## Verdict")
P("")
tot = len(sm["rows"]) + len(llm["rows"]) + len(br["rows"]) + len(jr)
P(f"**PASS. All {tot:,} values I recomputed match, with 0 FAILs.**")
P("")
P("| check | values | result |")
P("|---|---|---|")
P(f"| 1. results_summary.json: banking77_typos, spam, slice250_all_models, injection, banking77_paired_vs_jev, speed_cost (+ spend, redteam_other) | {len(sm['rows'])} | {len(sm['rows']) - nf(sm['rows'])}/{len(sm['rows'])} PASS |")
P(f"| 2. llm_report.json vs my last-object parser, every model and test, including the new strict_json_reply_rate | {len(llm['rows'])} | {len(llm['rows']) - nf(llm['rows'])}/{len(llm['rows'])} PASS; 0 replies parse differently |")
P(f"| Regression: BEMA and zero-shot values in report.json / redteam_report.json (pass-2 code), incl. `bema_latency` = timing_quiet.json | {len(br['rows'])} | {len(br['rows']) - nf(br['rows'])}/{len(br['rows'])} PASS |")
P(f"| Regression: Jev rows after the pass-1 fixes | {len(jr)} | {len(jr) - nf(jr)}/{len(jr)} PASS |")
P(f"| 3. runs/bema/timing_quiet.json plausibility | | plausible, with 3 caveats (below) |")
P("")
P("All pass-2 FAILs are fixed:")
P("- The spend is now split by provider: OpenRouter $3.115 and Anthropic $110.575, which match my sums.")
P("- Sonnet, Opus, Fable and zs_offshelf_bge_base now appear in every relevant section. No model with raw files is missing.")
P("- The slice250 section now notes that BEMA's defended answers are its undefended ones. The predictions are identical, and the state text of the two input files is identical.")
P("- llm_report now matches my parser on all rows. For example, Sonnet banking77_clean has 0 invalid outputs and accuracy 0.8458; Haiku banking77_clean ECE is 0.0857.")
P("")
P("## 1. results_summary.json")
P("")
P("Every accuracy_pct, n, ECE (4 dp), mean confidence and followed-injection value matches my own recomputation from raw files. So do the clean references, the "
  "majority baseline, Jev cost per 1,000 decisions, all latency medians and LLM cost per 1,000 calls, and the spend figures. The `redteam_other` block equals the current redteam_report.json. "
  "slice250 uses the identical 250 keys for every model and row.")
P("")
P("**Spam duplicates, 83 vs 88.** Your 83 is an exact-text match, and I confirm it (exact match: 83). My pass-2 figure of 88 matched after lower-casing and collapsing "
  "whitespace. The 5 extra messages differ from a training message only by one trailing space, so they are duplicates in substance:")
for r in n["spam_dup_extra_rows_under_normalisation"]:
    P(f"- idx {r['idx']}: \"{r['text'][:70]}...\"")
P("")
P("The definition barely matters. Excluding all 88 instead of 83 changes only Qwen at one decimal place (81.3% to 81.1%; n 753 to 748). The rest are unchanged: "
  + ", ".join(f"{m} {v['accuracy_pct']}" for m, v in n["spam_excl_dup_under_normalised_definition"].items()) + ". "
  "I suggest the summary say 'exact text match', and optionally 'plus 5 that differ only by a trailing space'.")
P("")
P("**banking77_paired_vs_jev.** Every n and every point gap (1 dp) matches. The CIs match my own 10,000-resample bootstrap within the 0.2-point tolerance; "
  "they differ by at most 0.1 point because the seeds differ:")
P("")
P("| model | reported gap [CI] | audit gap [CI] |")
P("|---|---|---|")
rep_rows = json.load(open(f"{ROOT}/runs/results_summary.json"))["sections"]["banking77_paired_vs_jev"]["rows"]
for m, (g, ci) in n["paired_bootstrap_ours"].items():
    r = rep_rows[m]
    P(f"| {m} | {r['minus_jev_points']:+.1f} [{r['ci95_points'][0]:+.1f}, {r['ci95_points'][1]:+.1f}] | {g:+.2f} [{ci[0]:+.2f}, {ci[1]:+.2f}] |")
P("")
P("Not errors, but worth fixing:")
P("1. The paired section leaves out the zero-shot models, which are the fairest comparison with Jev. From pass 2: zs_offshelf_bge_base -11.1 points [-12.6, -9.6], "
  "zs_from_clinc -17.5 [-19.1, -16.0], zs_offshelf -18.4 [-19.9, -16.8].")
P("2. The `injection` section's `source` string still reads 'runs/llm (Haiku, Qwen)', but its rows now include Sonnet and Opus. The numbers are right; the label is stale.")
P("")
P("## 2. llm_report.json")
P("")
P(f"Using my pass-2 parser (last JSON object holding the key; exact 77-label match; confidence a number in [0, 1]) and my own item sets, all {len(llm['rows'])} values match. "
  "They cover accuracy, invalid count and rate, n_with_confidence, mean stated confidence, ECE, overconfidence, followed_injected_label, latency median/p90, "
  "cost and cost per 1,000 calls, tokens, thinking tokens, providers, Qwen's token probability, and the new `strict_json_reply_rate`. "
  "The repo's new `parse()` and mine agree on every reply (0 disagreements).")
P("")
P("`strict_json_reply_rate` means the whole reply parses as JSON. A ```json fence or any surrounding prose counts as not strict. On that definition the lowest "
  "rates are Opus banking77_mixed3 at 0.988 (37 of 3,080) and Haiku injection_casual_defended at 0.970. My recomputation matches.")
P("")
P("## 3. runs/bema/timing_quiet.json: plausible, with caveats")
P("")
P("I checked this against `measure_latency.py` (unchanged since commit e5af50f, 11:53 local) without re-timing anything:")
P("")
P("| model | quiet median (p90) | busy timing.json median (p90) | tokenize (excluded) |")
P("|---|---|---|---|")
P(f"| bema_baseline | {tq['bema_baseline']['median_ms']:.2f} ms ({tq['bema_baseline']['p90_ms']:.2f}) | {tb['bema_baseline']['median_ms']:.1f} ms ({tb['bema_baseline']['p90_ms']:.1f}) | {tq['bema_baseline']['tokenize_median_ms']:.2f} ms |")
P(f"| bema_v2 | {tq['bema_v2']['median_ms']:.2f} ms ({tq['bema_v2']['p90_ms']:.2f}) | {tb['bema_v2']['median_ms']:.2f} ms ({tb['bema_v2']['p90_ms']:.2f}) | {tq['bema_v2']['tokenize_median_ms']:.2f} ms |")
P(f"| bema_v2_spell | {tq['bema_v2_spell']['median_ms']:.2f} ms (speller {tq['bema_v2_spell']['speller_median_ms']:.3f} ms) | | |")
P("")
P("**Consistent with the code:**")
P("- The protocol (first 300 clean BANKING77 queries, 20 warm-up passes, batch 1, tokenisation timed separately and excluded, all 3 heads, 2 torch threads on 2 cores) is "
  "what `measure_latency.py` does, and every field in the JSON is one the script writes.")
s = tp["spell_median_vs_sum_of_medians"]
P(f"- bema_v2_spell's median is computed as median(forward + speller): {s['reported_bema_v2_spell_median']:.3f} ms vs {s['bema_v2_median_plus_speller_median']:.3f} ms for bema_v2 plus the speller median, as expected.")
P(f"- The magnitudes are plausible. v1 is a 3-layer, 96-dimension encoder fed 64 padded positions (about {tp['approx_MACs_per_query']['bema_baseline'] / 1e6:.0f}M MACs, at most). "
  f"v2 is a 6-layer, 384-dimension MiniLM on about {tp['v2_sequence_length_processed_median']} tokens (about {tp['approx_MACs_per_query']['bema_v2'] / 1e6:.0f}M MACs). "
  f"The measured ratio is {tp['measured_ratio_v2_over_v1_quiet']:.1f}x and the implied throughput is about 10-14 GMAC/s on 2 cores. Both are reasonable for batch-1 CPU inference with per-op overhead.")
P(f"- The quiet tails are tight (p90/median {tp['p90_over_median']['bema_baseline']:.2f} and {tp['p90_over_median']['bema_v2']:.2f}). The busy v1 figure ({tb['bema_baseline']['median_ms']:.0f} ms, p90/median "
  f"{tp['p90_over_median_busy']['bema_baseline']:.1f}) made the small model slower than the large one, which is impossible without contention. The quiet file resolves that.")
P("- `report.json` `bema_latency` and the BEMA rows of results_summary `speed_cost` equal timing_quiet.json exactly. The contended timing.json is no longer quoted anywhere I checked.")
P("")
P("**Caveats a skeptical reader could raise:**")
P(f"1. **The machine was not provably idle.** The 1-minute load average at start was {tp['load_avg_at_start'][0]:.2f} on 2 cores, with 5- and 15-minute averages of "
  f"{tp['load_avg_at_start'][1]:.2f} and {tp['load_avg_at_start'][2]:.2f}. Training was terminated at 13:44:01 local and the file was written at 13:44:26. "
  f"If training held about 2 runnable threads and the machine then went idle, a 1-minute load of 1.71 is what you would see about "
  f"{tp['seconds_after_kill_implied_if_load_was_2_and_machine_then_idle']:.0f} s after the kill. So the reading is consistent with the job's lag, but it does not prove the machine was idle, "
  "and the load was not recorded at the end. The docstring's 'nothing else running' is plausible but unverified. "
  "My own audit scripts were not running in that window: my next heavy script wrote its output at 13:45:15, and it takes about 11 s. (That output file's mtime is now 14:35 because I re-ran it to time it.)")
P(f"2. **bema_v2's quiet figure is slower than its busy one** ({tq['bema_v2']['median_ms']:.1f} vs {tb['bema_v2']['median_ms']:.1f} ms, +{tp['quiet_minus_busy_ms']['bema_v2']:.1f} ms). "
  "So contention only clearly inflated bema_v1. A possible cause is that the quiet loop runs the speller and tokeniser between each forward pass. Quote bema_v2 as roughly 12-14 ms, not 14.0 ms precisely.")
P(f"3. **The speller was timed on clean text only.** In the first 300 clean queries the speller changes {tp['speller_texts_changed_first300_clean']} texts, against "
  f"{tp['speller_texts_changed_first300_swap2']} on swap2 and {tp['speller_texts_changed_first300_mixed3']} on mixed3. Nearly every clean token takes the fast exact-lookup path, "
  f"so the {tq['bema_v2_spell']['speller_median_ms'] * 1000:.0f} µs speller cost (and the 14.07 ms total) is unmeasured on the typo'd inputs where the speller matters.")
P("")
P("All BEMA latencies are single-run, local CPU forward passes that exclude tokenisation. Jev's and the LLMs' latencies include the network round trip. "
  "The speed_cost `source` field says this, and it needs to stay attached wherever the numbers are quoted.")
P("")
P("## Appendix: every value checked")
for title, rows in (("results_summary.json", sm["rows"]), ("llm_report.json (my parser)", llm["rows"]),
                    ("report.json / redteam_report.json: BEMA and zero-shot", br["rows"]), ("Jev rows after the pass-1 fixes", jr)):
    P("")
    P(f"### {title} ({len(rows) - nf(rows)}/{len(rows)} PASS)")
    P("")
    P("| section | metric | reported | recomputed | result |")
    P("|---|---|---|---|---|")
    for r in rows:
        P(f"| {f(r['section'])} | {f(r['metric'])} | {f(r['reported'])} | {f(r['ours'])} | {r['result']} |")
open(f"{ROOT}/runs/audit/AUDIT_PASS3.md", "w").write("\n".join(L) + "\n")
print("wrote", tot, "rows")
