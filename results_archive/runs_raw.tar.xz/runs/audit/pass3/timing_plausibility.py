"""Pass 3, check 3: plausibility of runs/bema/timing_quiet.json against measure_latency.py (no re-timing).
Static facts only: input sizes, rough compute, internal consistency, and the timeline."""
import json
import math
import os
import pickle
import re
import subprocess
import sys

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
from common import ROOT, P2, rj

TQ = json.load(open(f"{ROOT}/runs/bema/timing_quiet.json"))
TB = json.load(open(f"{ROOT}/runs/bema/timing.json"))
OUT = {"timing_quiet": TQ, "timing_busy": TB}
rows = rj(f"{ROOT}/runs/inputs/banking77_clean.jsonl")[:300]
texts = [r["text"] for r in rows]

# ---- input sizes as each model sees them
from tokenizers import Tokenizer
d = pickle.load(open(f"{ROOT}/data/prepared_multitask.pkl", "rb"))
t1 = Tokenizer.from_file(f"{ROOT}/data/tokenizer_multitask.json")
v1_len = [min(len(t1.encode(t).ids), d["max_len"]) for t in texts]
import glob
from transformers import AutoTokenizer
ml = glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/*"))[0]
t2 = AutoTokenizer.from_pretrained(ml)
v2_len = [len(t2(t, truncation=True, max_length=64)["input_ids"]) for t in texts]
med = lambda xs: sorted(xs)[len(xs) // 2]
OUT["v1_sequence_length_processed"] = {"note": "measure_latency.enc1 pads every query to max_len", "value": d["max_len"],
                                       "real_tokens_median": med(v1_len)}
OUT["v2_sequence_length_processed_median"] = med(v2_len)


# ---- rough multiply-accumulate counts per query (encoder only)
def tf_macs(L, dm, dff, n):
    per = 4 * L * dm * dm + 2 * L * dm * dff + 2 * L * L * dm
    return n * per


v1 = tf_macs(d["max_len"], 96, 384, 3)
v2 = tf_macs(med(v2_len), 384, 1536, 6)
OUT["approx_MACs_per_query"] = {"bema_baseline": v1, "bema_v2": v2, "ratio_v2_over_v1": v2 / v1}
OUT["measured_ratio_v2_over_v1_quiet"] = TQ["bema_v2"]["median_ms"] / TQ["bema_baseline"]["median_ms"]
OUT["measured_ratio_v2_over_v1_busy"] = TB["bema_v2"]["median_ms"] / TB["bema_baseline"]["median_ms"]
OUT["implied_GMAC_per_s_quiet"] = {"bema_baseline": v1 / (TQ["bema_baseline"]["median_ms"] / 1e3) / 1e9,
                                   "bema_v2": v2 / (TQ["bema_v2"]["median_ms"] / 1e3) / 1e9}

# ---- internal consistency
OUT["spell_median_vs_sum_of_medians"] = {"reported_bema_v2_spell_median": TQ["bema_v2_spell"]["median_ms"],
                                         "bema_v2_median_plus_speller_median": TQ["bema_v2"]["median_ms"] + TQ["bema_v2_spell"]["speller_median_ms"]}
OUT["p90_over_median"] = {m: TQ[m]["p90_ms"] / TQ[m]["median_ms"] for m in ("bema_baseline", "bema_v2")}
OUT["p90_over_median_busy"] = {m: TB[m]["p90_ms"] / TB[m]["median_ms"] for m in ("bema_baseline", "bema_v2")}
OUT["quiet_minus_busy_ms"] = {m: TQ[m]["median_ms"] - TB[m]["median_ms"] for m in ("bema_baseline", "bema_v2")}

# ---- speller path: the 300 timed texts are CLEAN, where almost no token needs an edit-distance search
for cond in ("clean", "swap2", "mixed3"):
    st = rj(f"{ROOT}/runs/bema/spell_texts/banking77_{cond}.jsonl")[:300]
    OUT[f"speller_texts_changed_first300_{cond}"] = sum(r["original"] != r["corrected"] for r in st)

# ---- timeline and load average
def mtime(p):
    return subprocess.run(["stat", "-c", "%y", p], capture_output=True, text=True).stdout.strip()


OUT["timeline_local"] = {"bema_v2_full training terminated (log mtime)": mtime(f"{ROOT}/runs/bema_v2_full.log"),
                         "timing_quiet.json written": mtime(f"{ROOT}/runs/bema/timing_quiet.json"),
                         "pass-2 audit check1_bema_metrics.json written (11-25 s script)": mtime(f"{ROOT}/runs/audit/pass2/check1_bema_metrics.json"),
                         "measure_latency.py last modified": mtime(f"{ROOT}/measure_latency.py")}
la = TQ["_machine"]["load_avg_at_start"]
# Linux 1-min load average decays by exp(-dt/60) once runnable threads drop to 0. If the training job held ~2
# runnable threads until it was killed, the observed 1.71 implies dt = -60 ln(1.71/2) seconds after the kill.
OUT["load_avg_at_start"] = la
OUT["seconds_after_kill_implied_if_load_was_2_and_machine_then_idle"] = -60 * math.log(la[0] / 2.0)
json.dump(OUT, open(f"{P2}/timing_plausibility.json", "w"), indent=1, default=str)
print(json.dumps(OUT, indent=1, default=str))
