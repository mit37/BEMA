"""Writes runs/audit/AUDIT_JEV.md from comparison.json + audit_*.json (all produced by this audit's own code)."""
import json

ROOT = "/home/claude/mit37/bema"
A = f"{ROOT}/runs/audit"
rows = json.load(open(f"{A}/comparison.json"))
abc = json.load(open(f"{A}/abc_results.json"))
m = json.load(open(f"{A}/audit_metrics.json"))
x = json.load(open(f"{A}/audit_extra.json"))
x2 = json.load(open(f"{A}/audit_extra2.json"))


def f(v):
    if isinstance(v, bool) or v is None:
        return str(v)
    if isinstance(v, int):
        return f"{v:,}"
    if isinstance(v, float):
        return f"{v:.6g}" if abs(v) >= 1e-4 or v == 0 else f"{v:.3e}"
    if isinstance(v, list):
        return "[" + ", ".join(f(a) for a in v) + "]"
    return str(v).replace("|", "\\|")


NOTE = {
    ("core spam/clean", "ece (spec: exact decimal bin edges)"):
        "FAIL: float32 bin edges (see F1)",
    ("redteam injection_oos_clinc", "ece"): "FAIL: float32 bin edges (see F1)",
    ("redteam score_amazon_clean", "pearson_r_expected_stars"): "FAIL (definition, tiny; see F2)",
    ("redteam score_amazon_clean", "mae_stars_expected"): "FAIL (definition, tiny; see F2)",
    ("redteam score_amazon_swap2", "pearson_r_expected_stars"): "FAIL (definition, tiny; see F2)",
    ("redteam score_amazon_swap2", "mae_stars_expected"): "FAIL (definition, tiny; see F2)",
}
n_fail = sum(r["result"] == "FAIL" for r in rows)
sc = m["redteam"]
L = []
P = L.append
P("# Independent audit of the Jev benchmark numbers")
P("")
P("Auditor's own code, written from scratch (it does not import `bench_jev.py`, `redteam_jev.py` or `calib_utils.py`): "
  "`runs/audit/audit_abc.py` (checks A-C; imports `noise.py` only for check B, as instructed), `audit_metrics.py` (D, E, F), "
  "`audit_extra.py` and `audit_extra2.py` (F), `compare.py` (reported vs recomputed), `write_md.py` (this file). Raw outputs are in "
  "`abc_results.json`, `audit_metrics.json`, `audit_extra*.json` and `comparison.json`. No network calls were made.")
P("")
P("Scope: Jev entries only, real runs only (`runs/mock/` ignored). Reports were regenerated first with `python3 bench_jev.py report` "
  "and `python3 redteam_jev.py report` (copies from before regeneration: `runs/audit/*_before_regen.json`).")
P("")
P("## Verdict")
P("")
P(f"**{len(rows) - n_fail} of {len(rows)} reported Jev numbers reproduce exactly from the raw files. {n_fail} do not, and none of the {n_fail} changes a conclusion.** "
  "The inputs, labels, typo generation, hashes and record counts are all clean. The two biggest problems are in how some numbers are framed, not in "
  "their arithmetic (see the list at the end).")
P("")
P("| FAIL | reported | recomputed (spec) | difference | cause |")
P("|---|---|---|---|---|")
for r in rows:
    if r["result"] == "FAIL":
        d = r["ours"] - r["reported"]
        P(f"| {r['section'].replace('core ', '').replace('redteam ', '')} `{r['metric'].split(' (')[0]}` | {r['reported']:.5f} | {r['ours']:.5f} | {d:+.5f} | "
          f"{'float32 bin edge: confidence values of exactly 0.9 and 0.7 are put in the bin above' if 'ece' in r['metric'] else 'the report divides expected stars by sum(probabilities), which is 0.99 on some rows; the spec does not'} |")
P("")
P("## Checks A-F")
P("")
A_ = abc["A"]
P("### A. Ground truth: PASS")
P(f"- `categories.json` has {A_['categories_len']} unique names and is identical to `data/raw/banking_categories.json`.")
P(f"- BANKING77 clean ({A_['banking_clean_rows']:,} rows) vs `data/raw/banking_test.csv` ({A_['banking_csv_rows']:,} rows): "
  f"**{A_['positional_label_mismatches']} label mismatches** by position and **{A_['text_keyed_label_mismatches']}** when matched by exact text; "
  f"{A_['positional_text_mismatches']} text mismatches; 0 texts with two categories. 77 intents, exactly 40 rows each.")
P(f"- Spam ({A_['spam_clean_rows']} rows, {A_['spam_n_spam_in_test']} spam) vs `data/spam.csv` matched by exact text: **0 label mismatches**. One row (idx 23) only matches "
  f"after normalising `\\r` to `\\n`. That row is a malformed CSV line in the source, and its label (ham) still agrees. After normalising, 0 rows are missing and 0 disagree.")
P(f"- Note: the spam test set holds {A_['spam_test_duplicate_texts']} duplicate texts ({A_['spam_test_distinct_texts']} distinct). Removing them moves Jev's clean accuracy from 0.9605 to "
  f"{m['core']['spam_clean_dedup']['accuracy']:.4f}, which is immaterial.")
P("")
P("### B. Typo inputs regenerated from noise.py: PASS")
P("| condition | n | text mismatches | label changes vs clean | texts left unchanged by the noise |")
P("|---|---|---|---|---|")
for k, v in abc["B"].items():
    P(f"| {k} | {v['n']:,} | {v['text_mismatches']} | {v['label_mismatches_vs_clean']} | {v['texts_identical_to_clean']} |")
P("")
P("(Swaps of two identical adjacent characters, or keyboard substitutions undone by a later operation, leave some texts unchanged, e.g. 62 of 3,080 for swap2. They still count in the typo condition, so the drops are very slightly understated.)")
P("")
P("### C. Integrity: PASS")
tot_core = sum(v["records"] for v in abc["C"]["core"].values())
tot_rt = sum(v["records"] for v in abc["C"]["redteam"].values())
P(f"- Core: {tot_core:,} Jev records in 11 files; red team: {tot_rt:,} records in 19 files. Every record has status `ok` and took 1 attempt. Each idx/key has exactly one ok record "
  "(0 duplicates, 0 missing, 0 extra). **0 sha256 mismatches** between records and the sha256 of the input text; 0 input files whose stored hash differs from their text.")
P(f"- `response.model` values seen: {abc['C']['response_model_values']} (= 24,904 core + 24,766 red-team). No `mock-jev-0.0` record appears in any real file, and `mock` is false in both reports.")
P("- Record timestamps (16:48-17:19 UTC, 27 Oct 2026) agree with the file mtimes and the run logs (`runs/jev_core.log`, `jev_redteam*.log`: 0 errors).")
P("")
P(f"### D. Recompute every Jev metric: {len(rows) - n_fail}/{len(rows)} PASS")
P("Tolerances: 1e-9 for counts, means, rates, latencies and tokens; 0.001 for ECE (per the brief); 0.005 for bootstrap CI endpoints. The full table is at the end.")
P("")
P("### E. Bootstrap CI, BANKING77 clean accuracy: PASS")
e = x2["E"]
P(f"- Reported {f(e['reported'])}. Own numpy bootstrap (10k resamples, seed 2026): {f(e['numpy_bootstrap_10k_seed2026'])}. Own pure-Python bootstrap (4k, seed 12345): "
  f"{f(e['python_bootstrap_4k_seed12345'])}. Wilson interval: {f(e['wilson'])}. All within 0.0005 of the reported values.")
P("")
P("### F. Things that are misleading or fragile")
P("")
P("**F1. ECE depends on float32 bin edges (this causes 2 FAILs).** The ECE code builds bin edges with float32 `torch.linspace`, so the 0.7 edge is 0.69999999 and the 0.9 edge is 0.89999998. "
  "Jev rounds probabilities to 2 decimals, so many confidences land exactly on an edge: 36 banking-clean answers sit at exactly 0.90, and in spam/clean 34 answers at 0.90 and 5 at 0.70 "
  "move up a bin. On spam/clean this lowers the reported ECE from 0.0658 (spec) to 0.0638. On injection_oos_clinc it goes from 0.0614 to 0.0602. Elsewhere the effect is under 0.001, "
  "and on every BANKING77 condition the two edge conventions agree to 5 decimals. The fix is to quote the spec values or say 'float32 edges'.")
P("")
P("**F2. Amazon expected stars are renormalised (4 tiny FAILs).** The report divides by sum(probabilities). Jev's rounded probabilities sum to 0.99 on 22 of 1,517 clean rows and 9 of 1,517 swap2 rows. "
  f"Using the definition in the brief (no renormalisation): clean r = {sc['score_amazon_clean']['jev']['pearson_r_expected_stars']:.5f} (reported 0.92044), MAE = "
  f"{sc['score_amazon_clean']['jev']['mae_stars_expected']:.4f} (reported 0.3543); swap2 r = {sc['score_amazon_swap2']['jev']['pearson_r_expected_stars']:.5f}, MAE = "
  f"{sc['score_amazon_swap2']['jev']['mae_stars_expected']:.4f}. With renormalisation my code reproduces the reported values exactly. This is a matter of definition, and the effect is under 0.0003.")
P("")
cf = x2["spam_confusion"]["clean"]
P(f"**F3. Spam accuracy hides poor precision.** The test set is {A_['spam_n_spam_in_test']}/836 spam, so always answering 'ham' scores {cf['majority_class_baseline_accuracy']:.3f}. Jev scores 0.961 on clean with "
  f"recall {cf['recall']:.3f} (1 miss) but **precision {cf['precision']:.3f}**: {cf['fp']} of 720 real messages are flagged as spam. Precision falls to "
  f"{x2['spam_confusion']['mixed3']['precision']:.3f} on mixed3. Spam 'overconfidence' is negative (Jev is underconfident), so its ECE measures underconfidence.")
P("")
pd = x["paired_drop_cis"]
P("**F4. Spam typo drops are not statistically distinguishable from zero.** Paired bootstrap 95% CIs (clean minus condition, same idx): "
  + ", ".join(f"{k.replace('spam_', '')} {pd[k]['acc_drop']:+.4f} [{pd[k]['acc_drop_ci95'][0]:+.4f}, {pd[k]['acc_drop_ci95'][1]:+.4f}]" for k in ["spam_swap2", "spam_keyboard2", "spam_mixed3"])
  + ". All BANKING77 drops are significant, but insert2's is borderline: "
  f"{pd['banking77_insert2']['acc_drop']:+.4f} [{pd['banking77_insert2']['acc_drop_ci95'][0]:+.4f}, {pd['banking77_insert2']['acc_drop_ci95'][1]:+.4f}]. "
  "Every confidence drop is significant. The report gives CIs for levels but not for drops, so a statement like 'spam accuracy drops under typos' is unsupported.")
P("")
rn = x["repeat_noise_floor"]
P(f"**F5. Jev is not deterministic, and the repeat test covers a narrow slice.** Sending an identical request again changes the answer on 3% of queries, and the probabilities are identical in only 48.5% of queries. "
  f"Accuracy on the same 200 queries ranged {min(x2['repeat_accuracy_per_round_200q'].values()):.3f}-{max(x2['repeat_accuracy_per_round_200q'].values()):.3f} across the 5 rounds. "
  f"The 200 repeat queries are the first 200 of the sorted sample (idx 0-598), so they cover only **{rn['n_distinct_intents_covered']} of 77 intents**. "
  "'97% same answer' should not be read as the figure for all of BANKING77.")
P("")
os_ = x["order_shuffle_vs_noise"]
P(f"**F6. Order-shuffle sensitivity should be read against that noise floor.** Shuffled options change the answer on {os_['shuffle_vs_core_disagreement_all_1000']:.3f} of the 1,000 queries. "
  f"On the 200 queries that were also repeated, shuffling disagrees with the core run {os_['shuffle_vs_core_disagreement_on_200_repeat_queries']:.3f} of the time, against "
  f"{os_['plain_repeat_vs_core_disagreement_same_200']:.3f} for a plain resend. So roughly 3 of the 5 points come from option order. (The response key order matched the expected shuffle in 1000/1000 cases, so the shuffle really was sent.)")
P("")
ct = x["core_tokens"]
P(f"**F7. The cost figure depends on output tokens being free.** Core: {ct['input']:,} input tokens give ${ct['usd_input_only']:.4f}. Jev also returned {ct['output']:,} output tokens "
  f"(48% of input volume). If output were billed at the input rate, the core run would cost ${ct['usd_if_output_billed_at_input_rate']:.2f}. "
  "The price (an OpenRouter page 'checked 2026-10-27') cannot be checked offline, and the $ figures are tokens times a posted price, not an invoice. "
  f"Total across core and red team: 83,621,901 input tokens, ${83621901 / 1e6 * 0.042:.2f}.")
P("")
lt = x["core_latency_by_task"]
P(f"**F8. What the latency numbers measure.** The core median of 104 ms is client-side wall clock at the default concurrency of 8 from a cloud workspace, including the network. It pools BANKING77 "
  f"(median {lt['banking77']['median']:.0f} ms, max {lt['banking77']['max']:.0f} ms) and spam ({lt['spam']['median']:.0f} ms). "
  f"The 'latency stays flat with more questions' result rests on 60 calls per level, short SMS texts and yes/no questions only: the ratio of medians is 1.09 and the paired per-message median ratio is "
  f"{x2['question_count_paired_ratio_16_vs_1']:.2f}. Input tokens rise from 302 to 533, so cost is not flat. CLINC150 calls (151 options) have a median of about 190 ms.")
P("")
P("**F9. A degenerate CI.** evasion_spam reports accuracy 1.0 with a bootstrap CI of [1.0, 1.0] (116/116). A percentile bootstrap cannot produce an interval at 100%. The Wilson interval is "
  f"{f(x['wilson_small_tests']['evasion_spam']['wilson'])}. The same applies, more mildly, to injection_spam (n = 116) and ood_spam_on_banking (4 false alarms in 1,000).")
P("")
cfx = x["confidence_field_vs_p_choice"]
P(f"**F10. The response shape, as observed.** Every `choice` is a valid option. The probability keys equal the option list in every response, and BANKING77 probabilities sum to {m['banking_prob_sums']['min']:.2f}-{m['banking_prob_sums']['max']:.2f} "
  f"(2-decimal rounding). Jev's own `confidence` field differs from probabilities[choice] in {cfx['n_differ']} of 3,080 clean answers, always by exactly -0.01. "
  "The report uses probabilities[choice], the higher of the two, so Jev's overconfidence is overstated by about 0.001, which is conservative. In one clean case (idx 2481) `choice` is not the argmax "
  "(0.47 vs 0.48, and the argmax was the gold answer). There are 5 exact ties. Scoring by argmax instead of `choice` would give 0.8065 instead of 0.8058. "
  f"36% of clean answers have confidence 1.00 ({x2['banking_clean_high_conf']['1.0']['accuracy']:.3f} of them correct).")
P("")
P("**F11. Subsets.** Every injection, order and OOD test uses the same 1,000-query sample (seed 7). Jev's clean accuracy on that sample is 0.800, against 0.806 on the full set, and the report "
  "correctly compares against `clean_accuracy_same_examples`. The injection_* banking tests share identical targets (0 differences), and `picked_target_without_injection` = 0.005 (5/1000) is "
  "computed from the core clean run on the same idx, as claimed. CLINC150 `in_scope_accuracy`, `oos_recall` and `false_oos_rate` use the correct subsets (4,500 in-scope / 1,000 oos). "
  f"OOS precision, which is not reported, is {x2['clinc150_clean_oos_precision']:.3f} clean and {x2['clinc150_swap2_oos_precision']:.3f} swap2.")
P("")
P("**F12. Stale report before regeneration.** The `runs/redteam_report.json` on disk before this audit lacked `latency_sequential_banking`, and its red-team cost (45,987,872 tokens, $1.9315) was out of date. "
  "After regeneration it reads 46,156,750 tokens, $1.9386. `runs/report.json` changed only in its timestamp. Cite only the regenerated files.")
P("")
P("**F13. No mixing with mock data.** The report code reads only `runs/jev` and `runs/redteam/jev`. Every model string is `jev-1.14.0`, and the token totals equal the sum over the real files.")
P("")
P("## What a skeptical interviewer could attack")
P("")
P("1. **'Jev 80.6% vs BEMA' is apples to oranges.** Jev is zero-shot from category names, while BEMA is trained on 8.5k in-domain examples. The repo says so itself. Lead with the drops, not the levels.")
P("2. **Spam '96% accuracy'** is only 10 points above always answering ham. Precision is 0.78 (32 false positives on 720 ham). Quote recall and precision.")
P("3. **'Jev degrades under typos'** is true for BANKING77 (1-4 points, significant) and not shown for spam (all CIs include 0). The drop CIs are not in the report.")
P("4. **Non-determinism:** a resend changes 3% of answers, and the run-to-run accuracy spread on 200 queries is about 1.5 points. Single-run differences under about 1 point (e.g. insert2's 0.8-point drop) are close to that noise.")
P("5. **ECE is fragile** with 2-decimal probabilities. Bin-edge handling moves spam ECE by 0.002. Quote ECE to 2 decimals, or use overconfidence, which here is nearly identical and has no binning.")
P("6. **'Latency is flat in number of questions'** rests on n = 60 per level, short texts, yes/no questions only, and client-side timing at concurrency 1. The paired ratio is 1.12x, not 1.0x.")
P("7. **Cost** assumes output tokens cost $0 (17.9M output tokens in the core run) and comes from a price page, not a bill.")
P("8. **The red-team repeat/consistency test** covers 15 of 77 intents. **evasion_spam's CI [1.0, 1.0]** is a bootstrap artefact. Use Wilson [0.968, 1.0].")
P("9. **Single provider snapshot:** one model version (jev-1.14.0), one day, one ~30-minute window. A different day or version may differ.")
P("")
P("## Full metric table (reported vs recomputed)")
P("")
P("| section | metric | reported | recomputed | tol | result |")
P("|---|---|---|---|---|---|")
for r in rows:
    res = NOTE.get((r["section"], r["metric"]), r["result"])
    P(f"| {r['section']} | {f(r['metric'])} | {f(r['reported'])} | {f(r['ours'])} | {f(r['tol'])} | {res} |")
P("")
P("Extra recomputations, not in the reports but used above: spam confusion matrices, paired drop CIs, the repeat noise floor, Wilson intervals, "
  "Amazon renormalised vs raw expected stars, and ECE under exact / float32 / float64 edges are all in `runs/audit/audit_metrics.json` and `audit_extra*.json`.")
txt = "\n".join(l for l in L if l is not None)
open(f"{A}/AUDIT_JEV.md", "w").write(txt + "\n")
print("wrote", len(rows), "rows")
