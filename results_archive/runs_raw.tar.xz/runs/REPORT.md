# Jev vs BEMA: generated results

Generated 2026-10-27T21:50:29.164304+00:00 by `python3 bench_jev.py report` from the raw files in `runs/`. Nothing in this file is typed by hand.

Jev model version(s) reported by the API: {'jev-1.14.0': 24904}

## banking77

| condition | model | n | accuracy (95% CI) | mean conf | overconf | ECE | acc drop | conf drop |
|---|---|---|---|---|---|---|---|---|
| clean | jev | 3080 | 0.806 (0.791-0.819) | 0.879 | +0.073 | 0.0731 |  |  |
| clean | bema_baseline | 3080 | 0.819 (0.805-0.832) | 0.790 | -0.028 | 0.0399 |  |  |
| clean | bema_v2 | 3080 | 0.824 (0.810-0.837) | 0.844 | +0.020 | 0.0250 |  |  |
| clean | bema_v2_spell | 3080 | 0.824 (0.810-0.837) | 0.844 | +0.020 | 0.0245 |  |  |
| clean | zs_offshelf | 3080 | 0.622 (0.605-0.639) | 0.665 | +0.043 | 0.0433 |  |  |
| clean | zs_from_clinc | 3080 | 0.631 (0.614-0.648) | 0.722 | +0.091 | 0.0907 |  |  |
| clean | zs_offshelf_bge_base | 3080 | 0.695 (0.679-0.711) | 0.718 | +0.023 | 0.0254 |  |  |
| swap2 | jev | 3080 | 0.790 (0.776-0.804) | 0.857 | +0.067 | 0.0672 | +0.016 | +0.021 |
| swap2 | bema_baseline | 3080 | 0.508 (0.491-0.526) | 0.611 | +0.103 | 0.1027 | +0.310 | +0.179 |
| swap2 | bema_v2 | 3080 | 0.673 (0.656-0.689) | 0.739 | +0.066 | 0.0660 | +0.151 | +0.105 |
| swap2 | bema_v2_spell | 3080 | 0.794 (0.780-0.808) | 0.821 | +0.027 | 0.0283 | +0.030 | +0.022 |
| swap2 | zs_offshelf | 3080 | 0.473 (0.456-0.491) | 0.496 | +0.022 | 0.0287 | +0.149 | +0.170 |
| swap2 | zs_from_clinc | 3080 | 0.474 (0.456-0.492) | 0.589 | +0.115 | 0.1147 | +0.157 | +0.133 |
| swap2 | zs_offshelf_bge_base | 3080 | 0.544 (0.526-0.561) | 0.545 | +0.002 | 0.0210 | +0.152 | +0.173 |
| swap4 | jev | 3080 | 0.770 (0.755-0.785) | 0.835 | +0.065 | 0.0663 | +0.036 | +0.044 |
| swap4 | bema_baseline | 3080 | 0.327 (0.311-0.344) | 0.528 | +0.201 | 0.2005 | +0.491 | +0.263 |
| swap4 | bema_v2 | 3080 | 0.536 (0.519-0.554) | 0.644 | +0.108 | 0.1081 | +0.288 | +0.199 |
| swap4 | bema_v2_spell | 3080 | 0.746 (0.731-0.761) | 0.793 | +0.046 | 0.0463 | +0.078 | +0.051 |
| swap4 | zs_offshelf | 3080 | 0.364 (0.347-0.381) | 0.389 | +0.025 | 0.0301 | +0.258 | +0.276 |
| swap4 | zs_from_clinc | 3080 | 0.354 (0.337-0.371) | 0.497 | +0.143 | 0.1434 | +0.277 | +0.225 |
| keyboard2 (held out) | jev | 3080 | 0.775 (0.760-0.790) | 0.842 | +0.067 | 0.0680 | +0.031 | +0.036 |
| keyboard2 (held out) | bema_baseline | 3080 | 0.532 (0.515-0.550) | 0.619 | +0.087 | 0.0870 | +0.286 | +0.171 |
| keyboard2 (held out) | bema_v2 | 3080 | 0.691 (0.675-0.707) | 0.742 | +0.050 | 0.0505 | +0.133 | +0.102 |
| keyboard2 (held out) | bema_v2_spell | 3080 | 0.804 (0.790-0.818) | 0.828 | +0.024 | 0.0297 | +0.020 | +0.015 |
| keyboard2 (held out) | zs_offshelf | 3080 | 0.487 (0.469-0.505) | 0.504 | +0.017 | 0.0329 | +0.135 | +0.161 |
| keyboard2 (held out) | zs_from_clinc | 3080 | 0.470 (0.453-0.488) | 0.598 | +0.128 | 0.1278 | +0.160 | +0.123 |
| delete2 (held out) | jev | 3080 | 0.787 (0.772-0.801) | 0.851 | +0.063 | 0.0649 | +0.019 | +0.028 |
| delete2 (held out) | bema_baseline | 3080 | 0.551 (0.533-0.568) | 0.635 | +0.084 | 0.0900 | +0.268 | +0.156 |
| delete2 (held out) | bema_v2 | 3080 | 0.701 (0.685-0.717) | 0.753 | +0.052 | 0.0525 | +0.123 | +0.090 |
| delete2 (held out) | bema_v2_spell | 3080 | 0.768 (0.753-0.783) | 0.811 | +0.043 | 0.0444 | +0.056 | +0.033 |
| delete2 (held out) | zs_offshelf | 3080 | 0.493 (0.475-0.511) | 0.526 | +0.033 | 0.0370 | +0.129 | +0.139 |
| delete2 (held out) | zs_from_clinc | 3080 | 0.491 (0.474-0.509) | 0.612 | +0.121 | 0.1209 | +0.140 | +0.109 |
| insert2 (held out) | jev | 3080 | 0.798 (0.784-0.812) | 0.867 | +0.069 | 0.0689 | +0.008 | +0.012 |
| insert2 (held out) | bema_baseline | 3080 | 0.587 (0.570-0.605) | 0.651 | +0.064 | 0.0652 | +0.231 | +0.139 |
| insert2 (held out) | bema_v2 | 3080 | 0.721 (0.705-0.737) | 0.770 | +0.048 | 0.0484 | +0.103 | +0.074 |
| insert2 (held out) | bema_v2_spell | 3080 | 0.821 (0.807-0.834) | 0.842 | +0.022 | 0.0248 | +0.003 | +0.001 |
| insert2 (held out) | zs_offshelf | 3080 | 0.531 (0.513-0.548) | 0.541 | +0.010 | 0.0168 | +0.092 | +0.125 |
| insert2 (held out) | zs_from_clinc | 3080 | 0.519 (0.501-0.536) | 0.627 | +0.108 | 0.1079 | +0.112 | +0.095 |
| mixed3 (held out) | jev | 3080 | 0.774 (0.759-0.788) | 0.838 | +0.064 | 0.0636 | +0.032 | +0.041 |
| mixed3 (held out) | bema_baseline | 3080 | 0.447 (0.430-0.465) | 0.584 | +0.136 | 0.1365 | +0.371 | +0.207 |
| mixed3 (held out) | bema_v2 | 3080 | 0.644 (0.627-0.661) | 0.712 | +0.068 | 0.0678 | +0.180 | +0.131 |
| mixed3 (held out) | bema_v2_spell | 3080 | 0.787 (0.773-0.801) | 0.816 | +0.028 | 0.0295 | +0.037 | +0.028 |
| mixed3 (held out) | zs_offshelf | 3080 | 0.437 (0.420-0.455) | 0.468 | +0.031 | 0.0319 | +0.185 | +0.198 |
| mixed3 (held out) | zs_from_clinc | 3080 | 0.442 (0.424-0.459) | 0.565 | +0.123 | 0.1234 | +0.189 | +0.156 |

## spam

| condition | model | n | accuracy (95% CI) | mean conf | overconf | ECE | acc drop | conf drop |
|---|---|---|---|---|---|---|---|---|
| clean | jev | 836 | 0.961 (0.945-0.972) | 0.897 | -0.064 | 0.0658 |  |  |
| clean | bema_baseline | 836 | 0.978 (0.966-0.986) | 0.980 | +0.001 | 0.0060 |  |  |
| clean | bema_v2 | 836 | 0.987 (0.977-0.993) | 0.988 | +0.001 | 0.0052 |  |  |
| clean | bema_v2_spell | 836 | 0.987 (0.977-0.993) | 0.988 | +0.001 | 0.0071 |  |  |
| swap2 | jev | 836 | 0.956 (0.940-0.968) | 0.882 | -0.073 | 0.0734 | +0.005 | +0.014 |
| swap2 | bema_baseline | 836 | 0.972 (0.959-0.982) | 0.976 | +0.004 | 0.0066 | +0.006 | +0.003 |
| swap2 | bema_v2 | 836 | 0.984 (0.974-0.991) | 0.987 | +0.002 | 0.0059 | +0.002 | +0.001 |
| swap2 | bema_v2_spell | 836 | 0.986 (0.975-0.992) | 0.988 | +0.002 | 0.0068 | +0.001 | -0.000 |
| keyboard2 (held out) | jev | 836 | 0.955 (0.938-0.967) | 0.880 | -0.075 | 0.0746 | +0.006 | +0.017 |
| keyboard2 (held out) | bema_baseline | 836 | 0.971 (0.958-0.981) | 0.977 | +0.006 | 0.0067 | +0.007 | +0.002 |
| keyboard2 (held out) | bema_v2 | 836 | 0.984 (0.974-0.991) | 0.987 | +0.002 | 0.0081 | +0.002 | +0.001 |
| keyboard2 (held out) | bema_v2_spell | 836 | 0.986 (0.975-0.992) | 0.988 | +0.002 | 0.0054 | +0.001 | -0.000 |
| mixed3 (held out) | jev | 836 | 0.953 (0.937-0.966) | 0.878 | -0.075 | 0.0750 | +0.007 | +0.018 |
| mixed3 (held out) | bema_baseline | 836 | 0.976 (0.963-0.984) | 0.983 | +0.007 | 0.0075 | +0.002 | -0.003 |
| mixed3 (held out) | bema_v2 | 836 | 0.983 (0.972-0.990) | 0.986 | +0.003 | 0.0040 | +0.004 | +0.002 |
| mixed3 (held out) | bema_v2_spell | 836 | 0.987 (0.977-0.993) | 0.987 | +0.001 | 0.0060 | +0.000 | +0.000 |

**jev_latency_ms**: `{"n": 24904, "median": 104.01020300002983, "p90": 138.65548300009323, "p99": 192.21290600012253}`

**jev_cost**: `{"input_tokens": 37465151, "usd": 1.5735363420000001, "price_source": "OpenRouter model page for ~typesafe/jev-latest, checked 2026-10-27: $0.042/M input, $0/M output (same figure as TypeSafe's launch pricing)"}`

**bema_latency**: `{"_machine": {"cpu_count": 2, "torch_threads": 2, "load_avg_at_start": [0.69140625, 0.40625, 0.32080078125], "load_avg_at_end": [0.77197265625, 0.4365234375, 0.33203125]}, "bema_baseline": {"median_ms": 2.5679770005808678, "p90_ms": 2.849853000952862, "tokenize_median_ms": 0.17104949802160263, "note": "BEMA v1 forward pass, all 3 heads, batch 1, CPU"}, "bema_v2": {"median_ms": 12.553524000395555, "p90_ms": 18.027011999947717, "tokenize_median_ms": 0.36850850119662937, "note": "BEMA v2 forward pass (MiniLM-L6 + 3 heads), batch 1, CPU"}, "bema_v2_spell": {"median_ms": 12.598158999026055, "speller_median_ms": 0.04658350007957779, "note": "BEMA v2 forward pass plus the spelling correction step"}, "bema_spell_on_swap2": {"speller_median_ms": 0.058344998251413926, "p90_ms": 0.09649799903854728, "queries_changed": 294, "n": 300, "note": "spelling step alone on the first 300 swap2 queries (2 swapped letters each)"}}`

Held out = a typo type the typo-augmented BEMA never saw in training (it was trained on swap2 only).
Jev answers zero-shot from category names; BEMA was trained on this task. Compare each model's drop from clean, not raw accuracy across models.
